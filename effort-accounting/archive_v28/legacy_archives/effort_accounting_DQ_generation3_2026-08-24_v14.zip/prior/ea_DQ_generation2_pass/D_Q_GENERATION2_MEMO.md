# D-Q generation 2: PCE → direct KLEMS cost structure

Date: 2026-08-24

## Main advance

The project now has a second empirical layer in the production recursion.

For 1997–2016, each PCE Bridge producer commodity is mapped to the matching BEA-BLS KLEMS production-account industry wherever the production-account codes align. Transportation, wholesale, and retail margins are treated as separate producing-service branches.

The historical PCE Bridge dollars are **not** used as controls. Within each broad PCE family, bridge rows are rescaled to the current-vintage NIPA family total before the KLEMS cost shares are applied.

The current KLEMS source is the April 2026 production account covering 1997–2024.

## What the direct KLEMS accounting means

KLEMS gross output is decomposed into:
- college and non-college labor compensation;
- capital compensation for IT, software, R&D, artistic originals, and other capital;
- intermediate energy;
- intermediate materials;
- intermediate purchased services.

These nominal cost components close to gross output to a maximum residual of **$0.003000B** across the extracted industry-year cells.

Applied to PCE, this yields a **direct** decomposition, not a total-requirements decomposition.

### 2016, share of total PCE

- direct domestic labor compensation: **29.55%**
- direct KLEMS capital compensation: **24.06%**
- intermediate energy: **1.76%**
- intermediate materials: **13.10%**
- intermediate purchased services: **27.06%**
- unresolved producer mapping + NPISH: **4.47%**

The direct labor number is best read as a **floor on domestic labor content** at this generation. Labor embodied upstream in materials, energy, and purchased services has not yet been counted.

Likewise the KLEMS capital component is **not yet the project's produced-capital terminal category**. In particular, real-estate/housing capital compensation can still contain returns that must be separated between structures, land/site scarcity, depreciation, financing/time, and other components.

## Mapping quality

The scaled producer-value mapping coverage, excluding NPISH, is **98.10%**.

The remaining unmatched producer-value entries are intentionally left unresolved, primarily used/secondary goods and noncomparable/rest-of-world adjustments.

The current-PCE allocation closes at the family level to a maximum residual of **$0.012471B** and at the total level to **$0.021407B**.

## Why this is a real step toward the paper's recursion

Before this pass, a PCE dollar reached a producer commodity but stopped there.

Now a mapped producer dollar resolves immediately into:

`direct labor + direct capital compensation + energy + materials + purchased services`

The last three terms are exactly the inputs that the next Leontief step must recurse through.

This gives a measurable distinction between:
- value that terminates at direct labor/capital in the first producing node; and
- value still sitting inside intermediate-input claims.

## What remains before a terminal factor decomposition

1. **Total requirements / use recursion:** trace energy, materials, and purchased services through upstream industries.
2. **Imports:** separate foreign content rather than treating all producer mapping as domestic.
3. **Capital/scarcity split:** KLEMS capital compensation must be decomposed into produced-asset service cost, land/site scarcity, interest/time, and unresolved rents where possible.
4. **Government/NPISH treatment:** NPISH remains explicit unresolved here; government-enterprise producer nodes are mapped, but final government/nonmarket accounting needs separate care.

## Source

BEA-BLS Integrated Industry-Level Production Account, Production Account Tables, 1997–2024, released April 2026.


## One interpretation warning from the family table

Some family-level `unresolved_or_npish` cells are slightly negative. That is not a negative unknown factor share: the PCE Bridge contains signed secondary-goods and noncomparable/rest-of-world adjustments. They are retained algebraically so the family totals reconcile. The aggregate unresolved/NPISH share remains positive.
