# Effort accounting — canonical status

**Date:** 2026-08-23

This file supersedes the accretive `README_CURRENT_PROGRESS.md` files as the canonical project-status document. Older READMEs remain research logs and contain some deliberately retained superseded statements.

## Original empirical target

The work is still aimed at the paper's central empirical question: whether the economy's price recursion is becoming less wage-linked and more scarcity-linked.

The consolidation adds one crucial distinction:

- **D-F:** where the purchasing power financing PCE comes from;
- **D-Q:** what the consumed goods and services themselves resolve into through production.

Those are different recursions and must remain separate.

## Canonical architecture

- **A:** household resource claims by economic origin.
- **B:** accrual/current-resource timing bridge.
- **C1:** 100% PCE product/use spine.
- **C2:** 100% PCE immediate delivery/payment route.
- **C-T:** current-DPI sufficiency lower bound (auxiliary).
- **D-F:** ultimate financing origin of PCE.
- **D-Q:** recursive production/factor content of PCE.

## Current headline status

- **A:** partial — legal-form 1960–2025; conservative origin anchors 2005–2025.
- **B:** strong — annual identity backbone plus detailed 2024 bridge; one minor recent-vintage warning remains.
- **C1:** strong/frozen data — exact 1950–2025 product spine.
- **C2:** partial — 40.99% of 2023 PCE is route-classified in the latest modern ledger; the long-run hard-form backbone spans 1950–2025.
- **C-T:** strong auxiliary — 2000–2023; 2023 hard lower bound 10.62%.
- **D-F:** open — legacy pro-rata financing accounting exists, but the canonical replacement has not been built.
- **D-Q:** main substantive frontier — housing/health are advanced; purchaser-price → producer/input bridge is next.

## QA result

**18 PASS, 1 WARN, 0 FAIL** across the consolidation checks.

The one warning is not a broken accounting identity: several B0 component series for 2021–2024 carry tiny cross-vintage differences, with a maximum 2024 residual of $3.5B (~0.016% of DPI). Before publication those series should be re-pulled from one common NIPA vintage.

## Files to use

- `CANONICAL_ONTOLOGY.md`
- `MASTER_MODULE_LEDGER.csv`
- `SUPERSESSION_REGISTER.csv`
- `QA_CHECKS.csv`
- `FINAL_FIGURE_REGISTRY.csv`
- `CONSOLIDATION_REPORT.md`
- `PROJECT_STATUS_OVERVIEW.png`

Do not use an old exploratory C*/D* graph number as a paper-facing identifier without checking the supersession register.
