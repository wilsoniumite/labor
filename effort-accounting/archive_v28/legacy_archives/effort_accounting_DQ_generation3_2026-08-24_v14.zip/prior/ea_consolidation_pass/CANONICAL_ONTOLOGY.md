# Canonical accounting ontology

Date: 2026-08-23

The consolidation pass freezes five different questions that had begun to overlap in the exploratory graph numbering.

## P — Product/use: what is consumed?
A mutually exclusive 100%-of-PCE partition. NIPA Table 2.3.5 is the current canonical product spine.

## R — Immediate delivery/payment route: how is it delivered or paid?
Also intended to become a mutually exclusive 100%-of-PCE partition, but it answers a different question from product. Examples: direct household payment, owner self-service/imputation, private insurance, public in-kind, NPISH, and implicit financial services.

## T — Timing/current-resource sufficiency
Orthogonal to P and R. The 2024 accrual routing ledger and the 2000–2023 PCE>DPI sharp bound live here. A timing shortfall must never be stacked on top of payer routes.

## F — Consumption financing origin
This is the demand/claims side: which household resource, transfer-funding source, borrowing flow, or asset drawdown supplies current purchasing power. It is the object closest to the paper's legacy wage-linked consumption-financing share. Because money is fungible, this layer requires either an explicit allocation rule or bounds. Pro-rata attribution is accounting, not incidence.

## Q — Production/factor content
This is the supply/price-recursion side: trace purchaser-price PCE through imports, trade margins, taxes, producing industries and intermediate inputs until it resolves into human effort, produced-capital services/cost, terminal scarcity rents, time/interest, foreign content, or an explicit unresolved residual.

## Critical separation

**F and Q are not the same recursion.**

A household can finance a gasoline purchase with wages while the gasoline's production value contains extraction rent, refining labor/capital, distribution margins and taxes. Conversely, property income can finance a labor-intensive service.

The paper needs both objects:
- financing linkage for the fiscal-transition question;
- production/factor content for the price-recursion question.

The purchaser-price → producer/input bridge therefore belongs to **Q**, not to the same ledger as the legacy financing-share figure.
