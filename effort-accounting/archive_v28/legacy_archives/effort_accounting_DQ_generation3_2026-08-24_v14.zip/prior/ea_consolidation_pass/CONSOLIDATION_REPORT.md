# Effort-accounting consolidation report

Date: 2026-08-23

## Executive conclusion

The project is still aligned with the paper's original empirical question, but the consolidation reveals one important architectural correction:

**there are two different "ultimate origin" problems.**

1. **Financing origin (F):** what source of purchasing power finances household consumption?
2. **Production/factor content (Q):** what does the price of the consumed good/service resolve into through the production recursion?

The paper needs both. The legacy consumption-financing figure belongs to F; the purchaser-price → producer/input bridge belongs to Q. They must not be merged into one graph.

## Where the project now stands

- **A / resource-claim origin:** partial. The legal-form ledger is annual 1960–2025, but the conservative economic-origin classification is only measured at 2005/2010/2015/2020/2025. The 2025 central classified effort share is **59.03%** of the resource denominator, not a PCE-financing share.
- **B / timing bridge:** strong. The annual DPI identity closes over 1960–2025, and the 2024 accrual/current-resource waterfall is explicit and reconciled.
- **C1 / product spine:** strong and essentially done. The 16-category PCE ledger is continuous 1950–2025 and closes to rounding.
- **C2 / immediate route:** partial. The latest 2023 ledger classifies **40.99%** of PCE by immediate route, leaves **2.38%** named but route-unresolved, and **56.63%** fully unresolved. The long-run hard-form ledger reaches **34.46%** in 2025 under its deliberately narrower rule.
- **C-T / timing lower bound:** strong auxiliary. The corrected 2017 hard floor is **9.58%**, and 2023 is **10.62%**.
- **D-F / consumption financing origin:** not yet rebuilt canonically. The paper's old pro-rata financing measure remains a legacy diagnostic, not the finished replacement.
- **D-Q / production-factor content:** main substantive frontier. In the 2025 product-family readiness map, **35.1%** of PCE sits in advanced product branches, **21.8%** in partial branches, and **43.1%** in open branches. Those are project-readiness shares, not factor-origin estimates.

## High-level QA

The consolidation ran **19 checks: 18 PASS, 1 WARN, 0 FAIL**.

The passed checks cover the accounting partitions, corporate identities, health and PCE ledgers, the 1950–2025 product spine and source join, housing stock/flow identities, public-medical funding, readiness coverage, the corrected sharp bound, and the conceptual dimension/unit checks.

**One warning remains:** the B0 annual DPI-disposition file has tiny recent cross-vintage residuals in 2021–2024 (maximum $3.5B in 2024, about 0.016% of DPI). The 2025 row closes again. This is small enough for the research-stage graph, but the publication build should re-pull those components from one common NIPA vintage.

## Consolidation decisions

1. **Freeze the five-layer ontology:** P, R, T, F, Q.
2. **Retire exploratory graph numbering** as paper-facing IDs. Old C1–C29/D1–D6 filenames remain diagnostics only.
3. **Treat the latest README files as research logs, not canonical status documents.**
4. **Use the final-figure registry for paper-facing work.**
5. **Do not revive the 20.72% C8/C9 additive interpretation.**
6. **Do not compare the 34.46% long-run hard-form share with the 40.99% modern route-classified share as if they used the same resolution rule.**
7. **Do not convert the owner-housing site-value stock residual to a rent flow without an explicit capitalization/user-cost band.**
8. **Do not multiply product PCE directly by industry compensation shares.** The purchaser-price bridge is required first.
9. **Keep financing origin (F) and production content (Q) as separate final empirical objects.**

## Recommended order after this consolidation

### First substantive task: D-Q purchaser-price bridge
Build the bridge from PCE purchaser prices to:
- domestic producer receipts/value added,
- imports,
- wholesale/retail and transport margins,
- product taxes/subsidies,
- then input-output recursion.

This unlocks the product families in the Q registry without corrupting the denominator.

### In parallel / next: A and D-F discipline
Before claiming a replacement for the paper's wage-linked financing share, decide whether the canonical F figure will be:
- sharp bounds only;
- a transparent pro-rata allocation grid;
- or a combination, with point estimates clearly labeled as accounting conventions.

And extend A only where the extension materially improves that financing-origin figure.

## Canonical files from this pass

- `CANONICAL_ONTOLOGY.md/.csv`
- `MASTER_MODULE_LEDGER.csv`
- `SUPERSESSION_REGISTER.csv`
- `QA_CHECKS.csv`
- `FINAL_FIGURE_REGISTRY.csv`
- `PROJECT_STATUS_OVERVIEW.png`
- this report
