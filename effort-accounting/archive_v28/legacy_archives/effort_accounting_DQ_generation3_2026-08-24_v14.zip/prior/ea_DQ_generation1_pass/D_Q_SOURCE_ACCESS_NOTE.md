# D-Q source/access note

Current BEA Input-Output tables are available through the interactive application and the BEA Data API. The API's `InputOutput` dataset contains Make/Use and Direct/Total Requirements tables; current annual summary Supply/Use tables are also documented by BEA.

The API requires a registered BEA key. No key was supplied in this conversation, so this pass deliberately stops short of inventing current matrix values. The existing BEA PCE Bridge workbook is used for generation-1 purchaser/producer mapping, and its age is handled as a calibration-vintage uncertainty issue.
