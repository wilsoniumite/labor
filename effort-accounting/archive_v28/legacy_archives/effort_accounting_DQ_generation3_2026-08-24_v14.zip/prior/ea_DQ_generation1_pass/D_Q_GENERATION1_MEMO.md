# D-Q generation-1 recursion pass

Date: 2026-08-24

## What changed

The purchaser-price bridge is now turned into an explicit **first-generation D-Q recursion** rather than remaining a diagnostic.

A household purchaser-price dollar is first expanded into:

`producer commodity value + transportation margin + wholesale margin + retail margin`

The producer commodity itself is then assigned to a broad direct producer-node class using its BEA I-O commodity code.

This is still only generation 1. It does **not** yet trace intermediate inputs or imports.

## 2016 direct producer nodes

The largest direct producer-value nodes in PCE are:

- Health / education / social: $2625.3B (24.8% of producer value)
- Housing services: $2017.8B (19.1% of producer value)
- Manufacturing: $1941.7B (18.4% of producer value)
- Consumer / recreation / other services: $1548.4B (14.6% of producer value)
- Finance / insurance: $984.6B (9.3% of producer value)
- Information: $514.4B (4.9% of producer value)

This is a useful map of where the Leontief recursion has to start, not a factor-origin result.

For example, `Housing services` is a direct producer node, but its own production account must still be decomposed into structures, interest, inputs and site/scarcity rent. Likewise `Manufacturing` must still be traced through upstream materials, energy, capital and labor.

## Long-run distribution-margin band

The 1997–2016 PCE Bridge is an older-vintage calibration window. Rather than allowing that window to truncate D-Q, this pass uses its **family-specific margin ratios** as follows:

- 1997–2016: annual observed bridge ratios, rescaled to the current NIPA product-family dollar controls;
- 1950–1996 and 2017–2025: the observed 1997–2016 min–max ratio for each family becomes an uncertainty band;
- current NIPA dollars remain the authoritative expenditure controls.

This produces a first-generation distribution-layer band over the full 1950–2025 axis.

- 1950: distribution-margin layer = **24.72%–30.21% of PCE**
- 1997 observed/rescaled: **16.30%**
- 2016 observed/rescaled: **14.49%**
- 2025 calibration band: **12.59%–15.15%**

The long-run movement is driven partly by product composition: household goods have very large distribution margins, while services generally do not. As consumption shifts toward services, the economy-wide first-generation trade-margin layer tends to shrink even if within-goods margin ratios are held inside the observed historical range.

## Why this helps

This gives D-Q a 1950–2025 object before the full I-O recursion is available.

The next exact data object needed is no longer vague:

`I-O commodity -> domestic producing industries + imports -> total requirements -> value added`

BEA's current Supply/Use and Total Requirements system is the correct source. The official API requires a BEA API key, so this pass does not fabricate current matrices from partial search results. Historical benchmark tables and the current interactive/API system will be used as benchmark/calibration inputs once retrieved in a machine-readable form.

## Interpretation guardrails

1. Direct producer-node classes are **not** terminal factor classes.
2. `Manufacturing` is a node to recurse through, not synonymous with produced capital.
3. Agriculture, mining, utilities, and housing are resource-relevant nodes, but their gross output is **not** pure scarcity rent.
4. Distribution margins are service outputs plus taxes embedded in the BEA bridge definitions; they also require their own production look-through.
5. Outside 1997–2016, D-Q6 is a calibration **band**, not an observed time series.

## Files

- `D_Q5_direct_producer_nodes_2016.csv/.png`
- `D_Q5_direct_producer_node_summary_2016.csv`
- `D_Q5_product_family_to_direct_node_matrix_2016.csv`
- `D_Q6_longrun_distribution_margin_band_1950_2025.csv/.png`
- `D_Q6_margin_calibration_ranges_by_family.csv`
- `D_Q6_goods_first_generation_split_2016.png`
