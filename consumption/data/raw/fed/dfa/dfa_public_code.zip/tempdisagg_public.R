
## Load required packages

library(tempdisagg)
library(tis)
library(stats)
library(zoo)
library(readxl)
library(tidyverse)

## Set DFA grouping
group <- "networth" #### Options: networth, race, education, income, generation, age

## Set directory

home_directory<-"/fof/dfa/"
directory <- file.path(home_directory, "projects/dev/public_version/data/output")
setwd(directory)

## Set date
lastqtr<-as.Date("2023-09-30")

#-------------------------------------------------------------------------------
## Setting parameters and reading in files


interpqtrs <- as.yearqtr(seq.Date(as.Date("1989-09-30"),as.Date(lastqtr), by = "quarter"))

indicators<-read_csv(paste0(directory, "/indicators.csv"))%>%
  mutate(date = as.yearqtr(date))
agg<-read_csv(paste0(directory, "/fof_aggs.csv"))%>%
  mutate(date = as.yearqtr(date))

hhcount<-read_csv(paste0(directory, "/hhcount_", group, "_default.csv"))%>%
  mutate(date = as.yearqtr(date))

if (group == "networth") {
  groupnames <- c("TopPt1", "RemainingTop1", "Next9", "Next40", "Bottom50")
  scf.recode <- c(`1` = "Bottom50", `2` = "Bottom50", `3` = "Bottom50", `4` = "Bottom50", `5` = "Bottom50",
                  `6` = "Next40", `7` = "Next40", `8` = "Next40", `9` = "Next40", `10` = "Next9",
                  `11` = "Next9", `12` = "RemainingTop1", `13` = "TopPt1")
  input.file <- "dfa_scf_fa_nw_detail"
  tag <- "scf_fa_nw"
  agg_vec <- c(.1,.9, 9, 40, 50)
}else if(group == "income"){
  groupnames <- c("pct99to100","pct80to99", "pct60to80","pct40to60","pct20to40","pct00to20")
  scf.recode <- c(`1` = "pct00to20", `2` = "pct00to20", `3` = "pct20to40", `4` = "pct20to40", `5` = "pct40to60",
                  `6` = "pct40to60", `7` = "pct60to80", `8` = "pct60to80", `9` = "pct80to99", `10` = "pct80to99",
                  `11` = "pct80to99", `12` = "pct99to100")
  agg_vec <- c(1,19,20,20,20,20)
}else if (group == "education") {
  groupnames <- c("College","SomeCollege","HS","NoHS")
  scf.recode <- c(`1` = "NoHS", `2` = "HS", `3` = "SomeCollege", `4` = "College")
  input.file <- "dfa_educ_detail"
  tag <- "educ"
} else if (group == "race") {
  groupnames <- c("White","Black","Hispanic","Other")
  scf.recode <- c(`1` = "White", `2` = "Black", `3` = "Hispanic", `4` = "Other")
  input.file <- "dfa_racecl4_detail"
  tag <- "racecl4"
} else if (group == "generation") {
  groupnames <- c("Silent","BabyBoom","GenX","Millennial")
  scf.recode <- c(`1` = "Millennial", `2` = "GenX", `3` = "BabyBoom", `4` = "Silent")
  input.file <- "dfa_cohort_detail"
  tag <- "cohort"
} else if (group == "age") {
  groupnames <- c("age70plus","age55to69","age40to54","ageunder40")
  scf.recode <- c(`1` = "ageunder40", `2` = "age40to54", `3` = "age55to69", `4` = "age70plus")
  input.file <- "dfa_agecl4_detail"
  tag <- "agecl4"}


# Read in and clean SCF data ---------------------------------------------- 

## Identify file path to Excel files
print("Reading in SCF data")

filepath <- file.path(directory, paste0(input.file, "public.xlsx"))
scf_balance_sheet <- function(excel, hh = FALSE, income = FALSE){
  
  sheet_names <- excel_sheets(excel)
  sheet_names <- sapply(strsplit(sheet_names," "), `[`, 1)
  
  ## Read in the excel files. The format must be consistent (check DFA_reconciliation). 4 sheets: Nonfinancial Assets, Financial Assets, Other Assets, and Liabilites. 
  ###!!! Need more extensive documentation on how the SCF inputs need to be formated 
  non_fin_sheet <- read_excel(excel, sheet = which(sheet_names == "nonfin"), trim_ws = TRUE, col_types = "numeric") %>%
    drop_na(2)
  fin_sheet <- read_excel(excel, sheet = which(sheet_names == "fin"), trim_ws = TRUE, col_types = "numeric") %>%
    drop_na(2)
  other_sheet <- read_excel(excel, sheet = which(sheet_names == "othassets"), trim_ws = TRUE, col_types = "numeric") %>%
    drop_na(2)
  liabilities_sheet <- read_excel(excel, sheet = which(sheet_names == "liab"), trim_ws = TRUE, col_types = "numeric") %>%
    drop_na(2)
  
  if (hh == TRUE) {
    aux_sheet <- read_excel(excel, sheet = which(sheet_names == "households"), trim_ws = TRUE, col_types = c("numeric", "numeric", "numeric", "skip", "skip", "skip", "skip"), .name_repair = "minimal") %>%
      drop_na(2)
  }
  
  balance_sheet <- list()
  
  balance_sheet[["real_estate"]] <- non_fin_sheet$scf_fa_real_estate
  balance_sheet[["con_durables"]] <- non_fin_sheet$scf_fa_consumer_durables
  
  balance_sheet[["check_curr"]] <- fin_sheet$scf_fa_check_fgn_dep_curr
  balance_sheet[["time_dep"]] <- fin_sheet$scf_fa_time_dep
  balance_sheet[["mmfs"]] <- fin_sheet$scf_fa_mmmf_shares
  
  balance_sheet[["us_gov_muni"]] <- fin_sheet$scf_fa_gov_muni_bnds
  balance_sheet[["corp_for_bonds"]] <- fin_sheet$scf_fa_corp_for_bnds
  
  balance_sheet[["oth_loans"]] <- other_sheet$scf_fa_othln_owed
  balance_sheet[["morts_owed"]] <- other_sheet$scf_fa_mort_owed
  
  balance_sheet[["corp_equ_mfs"]] <- other_sheet$scf_fa_corpeq_mut
  balance_sheet[["life_ins"]] <- other_sheet$scf_fa_life_ins
  balance_sheet[["annuities"]] <- other_sheet$annuities
  balance_sheet[["db_pension"]] <- other_sheet$scf_fa_db_assets
  balance_sheet[["dc_pension"]] <- other_sheet$scf_fa_dc_assets
  balance_sheet[["non_corp_eq"]] <- other_sheet$scf_fa_equity_non_corp
  balance_sheet[["misc_assets"]] <- other_sheet$scf_fa_misc_assets
  
  balance_sheet[["morts"]] <- liabilities_sheet$scf_fa_mort_debt
  balance_sheet[["cons_cred"]] <- liabilities_sheet$scf_fa_consumer_credit
  balance_sheet[["dep_loans"]] <- liabilities_sheet$scf_fa_dep_inst_loans
  balance_sheet[["oth_loans_adv"]] <- liabilities_sheet$scf_fa_oth_loans
  
  balance_sheet[["unpaid_life_ins"]] <- liabilities_sheet$scf_fa_life_ins_unpaid
  
  if (hh == TRUE) {
    balance_sheet[["hhcount"]] <- aux_sheet$hhcount
  }
  
  if (income == TRUE) {
    
    # use whichever income data are available -- varies by split
    
    if ("inc" %in% sheet_names) {
      
      inc_sheet <- read_excel(excel, paste0(sheet = "inc by ", tag), col_types = "numeric") %>%
        drop_na()
      balance_sheet[["inc"]] <- inc_sheet[["income"]]
    }
    
    if ("nipainc" %in% sheet_names) {
      nipainc_sheet <- read_excel(excel, sheet = paste0("nipainc by ", tag), col_types = "numeric") %>%
        drop_na()
      balance_sheet[["nipainc"]] <- nipainc_sheet[["nipa_equiv_income"]]
    }
    
    if ("norminc" %in% sheet_names) {
      norminc_sheet <- read_excel(excel, sheet = paste0("norminc by ", tag), col_types = "numeric") %>%
        drop_na()
      balance_sheet[["norminc"]] <- norminc_sheet[["norminc"]]
    }
  }
  
  balance_sheet <- bind_cols(balance_sheet)
  
  ## Now construct the balance sheet in the format of the B101h table. The series labels are done manually to look as much like the fame tables as possible.
  
  ids <- non_fin_sheet[,1:2] %>%
    mutate(date = as.yearqtr(year + .5)) %>%
    setNames(c("year", "cat", "date")) %>%
    select(date, cat)
  
  
  scf_data <- bind_cols(ids, balance_sheet)
  
  return(scf_data)
}

## Make SCF data frame using the function created
scf_data <- scf_balance_sheet(excel = filepath, hh = TRUE, income = FALSE)

sheet_names <- excel_sheets(filepath)
sheet_names <- sapply(strsplit(sheet_names," "), `[`, 1)


scf_data <- scf_data %>%
  dplyr::filter(date <= as.yearqtr(lastqtr)) %>% # filter out SCF observations that are after the last quarter you want to forecast 
  mutate(cat = recode(cat, !!!scf.recode)) %>% # relabel groups from MEcS files
  mutate(cat = factor(cat, levels = groupnames)) %>% # make the groups a factor instead of character for better organization
  group_by(date,cat) %>%
  dplyr::summarise_all(sum) %>% # add up all the groups within each group we are looking to distribute (e.g. Bottom50 = 1 through 5 in the wealth file)
  arrange(date,cat) %>%
  ungroup() %>%
  mutate(check_time_dep = check_curr + time_dep)


scf_data <- scf_data %>%
  mutate_at(vars(-date, -cat, -hhcount), ~./hhcount) %>% 
  select(-hhcount)%>%
  mutate(date = as.yearqtr(date))


#---------------------------------------------------
## Matching FOF series mnemonics with their corresponding names in the DFAs

series <- c(real_estate = "LM155035015.Q", 
            con_durables = "LM155111005.Q", 
            check_time_dep = "FL193020005.Q + FL193030205.Q",
            mmfs = "FL193034005.Q",  
            us_gov_muni = "FL193061005.Q",
            corp_for_bonds = "FL193063005.Q", 
            oth_loans = "FL193069005.Q", 
            morts_owed = "FL193065005.Q", 
            corp_equ_mfs = "LM193064005.Q", 
            life_ins = "FL153040005.Q", 
            annuities = "FL543150205.Q",
            db_pension = "FL574190043.Q + FL344190045.Q + FL224190043.Q + FL543150005.Q + FL263150005.Q - FL543050005.Q - FL543151905.Q - FL543150205.Q",
            dc_pension = "FL574090055.Q + FL344090055.Q + FL224090055.Q", 
            non_corp_eq = "LM153081115.Q", 
            misc_assets = "FL153090005.Q", 
            morts = "FL153165105.Q", 
            cons_cred = "FL153166000.Q", 
            dep_loans = "FL193168005.Q", 
            oth_loans_adv = "FL193169005.Q", 
            unpaid_life_ins = "FL543077073.Q")

assets <- names(series)

## Setting indicator choices for each asset/liability

indicator_choices <- list(
  real_estate = c("homeown"),
  con_durables =  c("homeown"),
  check_time_dep = c(),
  mmfs = c(),
  us_gov_muni = c(),
  corp_for_bonds = c(),
  oth_loans = c(),
  morts_owed = c(),
  corp_equ_mfs = c(),
  life_ins = c(),
  annuities = c(),
  db_pension = c(),
  dc_pension = c(),
  non_corp_eq = c(),
  misc_assets = c(),
  morts = c("dpi3"),
  cons_cred = c("dpi3", "stuloans"),
  dep_loans = c(),
  oth_loans_adv = c(),
  unpaid_life_ins = c(),
  inc = c("realff"),
  nipainc = c("realff"),
  norminc = c("realff")
)

totalhh <- hhcount %>%
  pivot_longer(-date, names_to = "cat", values_to = "hhcount") %>%
  dplyr::group_by(date) %>%
  dplyr::summarise(hhcount = sum(hhcount))

## Setting FOF aggregates and some indicator series to be on a per-hh basis
agg_perhh <- agg %>%
  left_join(totalhh, by = "date") %>%
  mutate_at(vars(all_of(names(series))), ~. * 1e6/hhcount) %>%
  select(date, all_of(names(series)), hhcount)%>%
  drop_na(real_estate)

indicators <- left_join(indicators, agg_perhh, by = "date") %>%
  mutate_at(vars(stuloans), ~(. * 1e6)/hhcount)

scf_data_list <- split(scf_data, f = scf_data$cat)
indicators_list <- list()
scale2one <- function(vec) {return(vec/max(na.omit(vec)))}


## Scaling indicator series to one, matching indicators with the relevant FOF series, and 
## filtering out dates not included in the group (only needed for Millennials in the generation split)
## Adding group specific db pension and real estate indicators
names_series <- names(series)[!names(series) %in% c("db_pension", "real_estate")]
for (gr in names(scf_data_list)) {
  for (line in names_series) {
    indicators_list[[gr]][[line]] <- select(indicators, date, all_of(c(indicator_choices[[line]], line))) %>%
      mutate_if(is.numeric, scale2one) %>%
      filter(date >= min(scf_data_list[[gr]][["date"]])) 
  }
  for (line in c("db_pension", "real_estate")){
    indicators_list[[gr]][[line]] <- select(indicators, date, all_of(c(indicator_choices[[line]], line)), contains(!! gr)) %>%
      mutate_if(is.numeric, scale2one) %>%
      filter(date >= min(scf_data_list[[gr]][["date"]])) 
  }
}

## Revising indicator selection for consumer credit to be group specific
if (group == 'networth'){
  indicators_list[["TopPt1"]][["cons_cred"]] <- indicators_list[["TopPt1"]][["cons_cred"]] %>% select(-stuloans)
  indicators_list[["RemainingTop1"]][["cons_cred"]] <- indicators_list[["RemainingTop1"]][["cons_cred"]] %>% select(-stuloans)
} else if (group == 'income'){
  indicators_list[["pct99to100"]][["cons_cred"]] <- indicators_list[["pct99to100"]][["cons_cred"]] %>% select(-stuloans)
} else if (group == 'generation'){
  indicators_list[["Silent"]][["cons_cred"]] <- indicators_list[["Silent"]][["cons_cred"]] %>% select(-stuloans)
} else if (group == 'age'){
  indicators_list[["age70plus"]][["cons_cred"]] <- indicators_list[["age70plus"]][["cons_cred"]] %>% select(-stuloans)
  indicators_list[["age55to69"]][["cons_cred"]] <- indicators_list[["age55to69"]][["cons_cred"]] %>% select(-stuloans)
} else if (group == 'education'){
  indicators_list[["HS"]][["cons_cred"]] <- indicators_list[["HS"]][["cons_cred"]] %>% select(-stuloans)
  indicators_list[["NoHS"]][["cons_cred"]] <- indicators_list[["NoHS"]][["cons_cred"]] %>% select(-stuloans)
}


# Temporal disaggregation  --------------------------------------------------------------
print("Applying temporal disaggregation")


indicators_list <- lapply(indicators_list, function(gr) lapply(gr, function(line) lapply(unlist(group_split(line), recursive = FALSE), function (ind)
  stats::ts(c(ind, rep(0,10)), start = c(year(min(line[["date"]])), 1), frequency = 4))))


scf_data_list <- lapply(scf_data_list, function(gr) lapply(unlist(group_split(gr), recursive = FALSE), function(line)
  zoo::na.trim(ts(line, start = year(as.Date(min(gr[["date"]]))), deltat = 3))))


scf_data_disagg <- list()

for (gr in names(scf_data_list)) {
  for (line in names(series)) {
    group_start <- min(indicators_list[[gr]][[line]][["date"]])
    assign("y", scf_data_list[[gr]][[line]])
    for (ind in 1:length(indicators_list[[gr]][[line]])) {
      assign(paste0("x_", ind), indicators_list[[gr]][[line]][[ind]])
    }
    scf_data_disagg[[gr]][[line]] <- td(formula(paste0("y ~ ", paste0("x_", seq(2, length(indicators_list[[gr]][[line]])),collapse = "+"))),
                                        conversion = "first", to = "quarterly", method = "fernandez", truncated.rho = trunc.rho
    )
  }
}

scf_data_imputed <- lapply(scf_data_disagg, function(gr) lapply(gr, function(asset) predict(asset)))

# Convert away from time series and add the date back in
join_by_date <- function(x,y) left_join(x,y,by = "date")

for (gr in names(scf_data_imputed)) {
  for (line in names(series)) {
    date_col <- data.frame(date = time(scf_data_imputed[[gr]][[line]]))
    scf_data_imputed[[gr]][[line]] <- data.frame(cbind(date_col, as.numeric(scf_data_imputed[[gr]][[line]]))) %>%
      setNames(c("date", line))
  }
  scf_data_imputed[[gr]] <- Reduce(join_by_date, scf_data_imputed[[gr]])
}




# Create DFA levels and shares --------------------------------------------
print("Creating DFA levels and shares.")
scf_levels <- bind_rows(scf_data_imputed, .id = "cat") 

scf_levels <- scf_levels %>% 
  mutate(date = as.yearqtr(date + .5)) 

neg_to_zero <- function(x) ifelse(x < 0, 0, x)

scf_levels <- scf_levels %>%
  mutate(date = as.yearqtr(date))%>%
  mutate_if(is.numeric, neg_to_zero) %>% 
  complete(date, cat) %>% 
  mutate(cat = factor(cat, levels = groupnames)) %>%
  arrange(date, cat) %>%
  replace(is.na(.), 0) %>% 
  filter(date <= as.yearqtr(lastqtr))  

## Bring extrapolated hhcounts back in to scale up to the group's aggregate 

hhcount <- hhcount %>%
  pivot_longer(-date, names_to = "cat", values_to = "hhcount") 

scf_levels <- left_join(scf_levels, hhcount, by = c("date", "cat")) %>%
  mutate_at(vars(all_of(names(series))), ~.* hhcount) %>%
  select(-hhcount)

# Determine implied shares for each group from imputed level and implied aggregates 

scf_shares <- scf_levels %>%
  group_by(date) %>%
  mutate_if(is.numeric, ~./sum(.))

# Apply shares to b101h aggregates

dfa_levels <- left_join(
  pivot_longer(scf_shares, -c(date,cat), names_to = "asset", values_to = "share"),
  pivot_longer(agg, -date, names_to = "asset", values_to = "b101h"),
  by = c("date", "asset")
) %>%
  mutate(b101h = b101h * 1e6,
         level = share * b101h) %>%
  select(date, cat, asset, level) %>%
  pivot_wider(id_cols = c(date, cat), names_from = asset, values_from = level) %>%
  ## Create composite b101h variables
  mutate(non_fin = real_estate+con_durables, 
         debt_sec=us_gov_muni+corp_for_bonds,
         ass_loans=oth_loans+morts_owed,
         liab_loans = morts+cons_cred+dep_loans+oth_loans_adv) %>%
  mutate(fin = check_time_dep+mmfs+debt_sec+ass_loans+corp_equ_mfs+life_ins+annuities+db_pension+dc_pension+non_corp_eq+misc_assets) %>%
  mutate(assets = non_fin+fin,
         liab = liab_loans+unpaid_life_ins) %>%
  mutate(networth = assets - liab) %>%
  select(date, cat, assets, non_fin, real_estate, con_durables, fin, check_time_dep, mmfs, debt_sec, us_gov_muni,
         corp_for_bonds, ass_loans, oth_loans, morts_owed, corp_equ_mfs, life_ins, annuities, db_pension, dc_pension, non_corp_eq, misc_assets,
         liab, liab_loans, morts, cons_cred, dep_loans, oth_loans_adv, unpaid_life_ins, networth)

# Calculate DFA shares based on DFA levels 
dfa_shares <- dfa_levels %>%
  group_by(date) %>%
  mutate_if(is.numeric, ~./sum(.))



# Output results ----------------------------------------------------------
print(paste("Saving results to", directory))


setwd(directory)
write_csv(dfa_levels, paste('dfa', group, 'levels.csv', sep = '_'))
write_csv(dfa_shares, paste('dfa', group, 'shares.csv', sep = '_'))
write_csv(scf_levels, paste('scf', group, 'levels.csv', sep = '_'))