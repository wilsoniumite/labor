This .zip file contains graphic files (in .png format) of each chart and graph in the Economic Research Service report 
"International Evidence on Food Consumption Patterns: An Update Using 2005 International Comparison Program Data" (TB-1929), published in March 2011. The content and context 
of these files is as of the publication date of the report. After time, the material may not reflect the current ERS program 
of work, may be outdated, and/or superseded, so please visit the website to obtain the latest information: www.ers.usda.gov.

Any reuse of these images should include attribution to "Economic Research Service/USDA."

The following inventory lists each of the files in this folder.



File name		Description

(fig.1.png)		Figure 1-Countries covered by the 2005 International Comparison Program
(fig.2.pgn)		Figure 2-Distribution of an additional $1 of income across 144 countries,broad categories
(fig.3.png)		Figure 3-Own-price elasticity for food by per capita income
(fig.4.pgn)		Figure 4-Distribution of an additional $1 of income across 144 countries.food subcategories
