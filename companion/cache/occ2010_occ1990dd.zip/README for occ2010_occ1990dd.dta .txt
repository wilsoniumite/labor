README for data file occ2010_occ1990dd.dta
David Dorn


Please cite as source for this file:
David Autor. "Why Are There Still So Many Jobs? The History and Future of Workplace Automation." Journal of Economic Perspectives, 29(3), 3-30, 2015.