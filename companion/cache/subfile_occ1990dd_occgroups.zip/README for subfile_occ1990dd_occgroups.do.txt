README for crosswalk subfile_occ1990dd_occgroups.do
David Dorn

Please cite as source for this file:
David Autor and David Dorn. "The Growth of Low Skill Service Jobs and the Polarization of the U.S. Labor Market." American Economic Review, 103(5), 1553-1597, 2013.