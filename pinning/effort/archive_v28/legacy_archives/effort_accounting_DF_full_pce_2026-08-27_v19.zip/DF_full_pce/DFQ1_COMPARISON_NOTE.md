# D-F versus D-Q comparison note

This figure is deliberately a comparison, not a combined decomposition.

- **D-F labor origin** asks where the household financing/current-resource claim originates.
- **D-Q human effort** asks how much of the consumed output's full production chain resolves into labor compensation.

A wage-financed purchase can have low labor content in production, and property-income financing can buy a labor-intensive service.

The modern central estimates diverge: D-F labor-origin financing is around the mid-60s percent of PCE under the weak allocation convention, while the BEA full-chain D-Q labor benchmark is around the high-40s percent. That difference is economically meaningful but not a wedge that can be added to another category.

The D-F line remains much less identified: the conditional capacity range is broad. The D-Q 1997–2023 line has the stronger source benchmark.
