# D-F full-PCE prototype: strong timing, weak source attribution

Date: 2026-08-27

## Main advance

The project now has the first **exclusive 100%-of-PCE D-F ledger**.

It is intentionally not presented as fully measured source tracing. The ledger combines:

1. a **minimum intertemporal financing slice**;
2. an accrual-consistent current-resource origin decomposition;
3. an explicit weak allocation rule for assigning the remaining PCE across current resource origins.

The identity is:

`current labor origin + current ownership/property origin + fiscal nonlabor/unresolved current origin + minimum intertemporal = 100% of PCE`

The maximum numerical identity residual is 2.22e-16.

## Where the evidence is strong

### Timing, 2000–2023

The intertemporal slice is the BEA distributional hard lower bound:

`sum_d max(0, PCE_d - DPI_d) / PCE`

It requires no assumption about which current income source households spend first.

In 2023 the hard minimum is **10.62% of PCE**.

Outside 2000–2023, the timing floor is explicitly weak. Four aggregate models are fitted only to the strong 2000–2023 window using PCE/DPI, saving, loan incurrence, and net lending. Their spread plus fit error gives the weak extension band.

## Where the evidence is weak

### Source origin within current resources

Legal-form household resources are observed annually from 1960 onward.

Economic origin requires two look-throughs:

- proprietor income: labor share is proxied from the project's self-employment-hours/wage benchmark;
- transfers: wage exposure is recursively traced through program financing scenarios.

The current-resource origin categories are therefore:
- labor-origin: employee compensation + proprietor labor + wage-exposed transfer funding;
- ownership/property-origin: residual proprietor income + rental + interest + dividends;
- fiscal nonlabor/unresolved: the non-wage-exposed remainder of transfer funding.

To connect these accrual resources to DPI, the prototype applies **common proportional netting** of taxes/social contributions across resource origins. That is an accounting convention, not tax-incidence estimation.

### Allocation of current resources to PCE

After assigning the minimum intertemporal slice, the remaining PCE is allocated pro rata across current resource origins.

This is a weak fungibility convention.

The project therefore also reports a **conditional feasible labor-financing range**:

given the classified amount of labor-origin current resources, nonlabor current resources, DPI, PCE, and the minimum-intertemporal slice, labor's contribution can vary from the amount that is mathematically forced after exhausting nonlabor resources to the lesser of available labor resources and the current-financed PCE block.

This range is much more honest than presenting the pro-rata central line as identified.

## Headline anchors

### 1950 — fully weak extension
- central labor-origin financing: **72.2%**
- conditional labor range: **62.8–92.2%**
- ownership/property central: **18.4%**
- fiscal nonlabor/unresolved: **0.7%**
- minimum intertemporal estimate: **8.7%**

### 2000 — strong timing, weak source allocation
- labor central: **67.0%**
- labor feasible range: **59.9–84.7%**
- hard intertemporal floor: **11.5%**

### 2023 — strongest full-ledger year
- labor central: **63.9%**
- labor feasible range: **54.7–82.1%**
- ownership/property central: **21.3%**
- fiscal nonlabor/unresolved: **4.2%**
- hard intertemporal floor: **10.6%**

### 2025 — weak timing extension
- labor central: **64.2%**
- labor feasible range: **54.1–81.3%**
- estimated intertemporal minimum: **10.1%**

## Why this differs from the old 72.6% result

The old series asks:

`what share of Wnet + social benefits arrives directly as labor claims?`

This new prototype asks:

`given all major household current resource claims, recursive transfer funding, and a minimum intertemporal slice, how could 100% of PCE be attributed by financing origin?`

The denominators and questions are different.

The new labor-origin central share is therefore much lower than the 92% recursive exposure of the old restricted flow pool because the full ledger now includes rental, interest, dividends, residual proprietor income, and an intertemporal slice.

## Important interpretation

This is now a real 100%-PCE accounting **prototype**, but not a final identified causal decomposition.

The strongest statements are:

- the ledger sums to 100% without double-counting timing and payer routes;
- 2000–2023 has a hard minimum intertemporal share;
- legal current-resource totals are observed from 1960;
- source attribution within the remaining fungible current-resource block is only partially identified.

The paper should therefore show the central weak allocation together with the labor-financing capacity band, not the central line alone.

## Next improvement

The highest-value next D-F improvement is source-specific netting rather than more elaborate pro-rata allocation:

- isolate employee/social-insurance contributions from labor resources;
- identify taxes on benefits where possible;
- separate cash from imputed property income where the financing interpretation requires cash;
- use distributional income/PCE data to tighten the allocation bounds by decile rather than only at the aggregate household-sector level.
