# D-F strong/weak pass: looking through the old direct-wage financing trend

Date: 2026-08-26

## Why this pass

The consolidation separated:
- D-F: source of purchasing power / institutional financing;
- D-Q: production-factor content.

D-Q now has a long-run strong/weak architecture. This pass applies the same discipline to the paper's older fiscal/consumption-financing logic.

The starting series is the project's recovered legacy identity:

`direct labor share = Wnet / (Wnet + government social benefits)`

This is an accounting object inside the old current-flow financing pool. It is **not a complete 100%-of-PCE source-tagging identity** because property income, asset drawdown, borrowing, and timing remain outside it.

## Strong accounting result

The legacy direct-labor claim share falls:
- 1960: **92.0%**
- 2025: **72.6%**

But transfers are not terminal funding sources. Looking through only **dedicated payroll financing** changes the result materially:

- 1960 dedicated-payroll re-look-through: **96.6%**
- 2025: **83.6%**

So even before making assumptions about general revenue, a large part of what the old graph colors as "non-wage transfer" is financed by dedicated labor taxes.

## Weak recursive funding band

General-revenue transfers require an allocation convention because current taxes, deficits, property/corporate tax bases, premiums, and asset income are fungible.

Three explicit scenarios are carried:

- weak low: 50% of general revenue treated as current-tax financed × 45% wage-exposed tax base;
- weak central: 75% × 68%;
- weak high: 100% × 80%.

Beneficiary premiums and taxes on benefits receive parallel 40% / 60% / 80% wage-exposure assumptions.

Under these conventions, 2025 recursive wage exposure of the legacy flow pool is:

- **low: 87.6%**
- **central: 92.1%**
- **high: 96.7%**

The central convention falls only from **98.3% in 1960 to 92.1% in 2025**, much less than the raw direct-claim decline.

This matters for interpretation: the old 72–73% direct-wage line is largely a statement about **institutional routing through transfer programs**, not a demonstrated collapse of ultimate wage exposure.

## Program funding strength

### Social Security
Strong funding anchors show that the program remains overwhelmingly payroll-tax financed. Historical years between published anchors are interpolated and therefore weaker than the anchor years.

### Medicare
The funding mix shifts strongly away from payroll taxes toward general government contributions and beneficiary premiums. The 1966–1969 years hold the 1970 mix and are explicitly weak.

### Medicaid and residual other benefits
This pass treats them as general-revenue funded for the recursive sensitivity. The wage exposure of that general revenue is weak by construction.

### Unemployment insurance
The recursive convention treats UI as payroll-tax financed.

## 1950–1959 extension

The old accounting series begins in 1960. To keep the headline horizon at 1950, the preceding decade is explicitly weak.

The 1950 direct-labor share is backcast from an ensemble of logit trends estimated over 1960–1969, 1960–1974, and 1960–1979.

The weak 1950 central estimate is **94.8%**. The pre-1960 transfer composition is held at its 1960 mix and Social Security funding at the 1970 payroll share.

No causal inference should be attached to that pre-1960 segment.

## What this does and does not say

### It does say
The old direct-wage financing trend substantially overstates the decline in **institutional wage exposure** if transfer programs are treated as terminal non-wage sources.

### It does not say
- that 92.1% of 2025 PCE is actually financed by wages;
- that payroll taxes are economically borne entirely by workers;
- that general-revenue incidence is known;
- that debt is wage-financed;
- or that D-F is finished.

The correct interpretation is narrower:

> Within the legacy current-flow financing framework, recursive funding makes wage exposure materially higher than the direct-claim classification suggests.

## Next D-F step

Move from the legacy `Wnet + transfers` pool to a true 100%-of-PCE financing ledger with:
- current labor-origin disposable resources;
- property-income resources;
- transfers recursively funded;
- borrowing;
- asset drawdown / dissaving;
- explicit unresolved allocation;
- the C-T current-DPI shortfall retained as an orthogonal bound.

That final step requires an explicit fungibility rule or a family of allocation bounds; it should not be hidden inside a single point estimate.
