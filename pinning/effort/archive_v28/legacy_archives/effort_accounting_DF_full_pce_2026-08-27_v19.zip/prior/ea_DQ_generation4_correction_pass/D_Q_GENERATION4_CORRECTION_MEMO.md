# D-Q generation 4 correction: filter selection, balanced-panel trend, and rent concept

Date: 2026-08-26

## Bottom line

The external review is substantively right on all four points.

The generation-4 land work remains useful, but its interpretation changes materially:

- the cross-system quality filter is **selective against land-intensive industries**;
- the largest BLS/KLEMS gaps are **concept/scope/methodology gaps, not merely release-vintage gaps**;
- the rolling filtered trend is **not a valid trend statistic** because industry coverage changes;
- BLS land capital cost is an **endogenous user-cost allocation**, not a measured terminal-rent series.

Accordingly, the previous language calling the strict filtered line a robust lower-bound trend is retired.

## 1. The filter is strongly non-neutral with respect to land

In 2016 the 10% BLS-vs-KLEMS capital-agreement filter:
- passes **39** industries;
- fails **20**;
- excludes **54.7% of all BLS business land capital cost**.

The industries that fail have a weighted land share of capital of **16.2%**, versus only **6.2%** among industries that pass.

The three largest excluded land-cost industries are exactly the ones flagged in the review:
- Real estate: 23.0% land share of capital;
- Farms: 60.1%;
- Construction: 22.9%.

So the 0.95% identified 2016 PCE share under the 10% filter is not a neutral estimate with tighter measurement error. It is a **highly conservative coverage floor that systematically excludes land-heavy nodes**.

The prior 10%/25%/50% lines are also not an uncertainty interval. In 2016 they cover only 45.3% / 54.9% / 56.5% of BLS business land cost. Their narrow 0.95–1.00 PCE range reflects the fact that the largest land-heavy mismatches fail even loose filters.

## 2. The big discrepancies are concept/scope gaps

### Real estate

In 2016:
- KLEMS real-estate capital compensation: $2091.3B
- BLS private-business real-estate capital cost: $558.6B
- raw gap: -73.3%

But BLS separately reports $1384.1B of owner-occupied structures+land capital cost. Adding that separate branch gives $1942.7B, reducing the 2016 gap to **-7.1%**.

That does not create a perfect reconciliation across every year because the rental-price systems still differ, but it demonstrates that the raw real-estate gap is largely a **scope problem**: BEA industry accounts place owner-occupied housing inside real estate, while BLS private-business capital excludes owner-occupied residential structures.

### Farms and construction

The project cannot yet provide an exact arithmetic reconciliation for Farms or Construction.

However, the review is right that calling their discrepancies "vintage" is too weak:
- Farms have a 2016 BLS/KLEMS capital gap of 113.6% and a 60.1% land share of capital.
- Construction has a -23.6% gap and 22.9% land share.

BLS farm land uses a distinct USDA source, and BLS productivity accounting explicitly imputes the capital/labor split of proprietors' mixed income. These are methodology/concept differences that can matter far more than release timing.

## 3. The filtered trend fails a balanced-panel check

The number of industries passing the 10% rule varies from **35 to 42** over 1997–2016.

Only **23 of 59** industries pass in every single year.

The implications for the trend are decisive:

- unfiltered cross-system allocation:
  - 1997: **1.66% of PCE**
  - 2016: **1.72%**
- rolling 10% filter:
  - 1997: **0.52%**
  - 2016: **0.95%**
- balanced 23-industry panel:
  - 1997: **0.46%**
  - 2016: **0.38%**

So the rise in the rolling strict-filter line is not evidence that PCE production became more land-linked. A large portion is coverage churn. The balanced panel is not representative of total land either — it contains only about 24.1% of 2016 BLS business land cost — but it is the correct diagnostic for whether the rolling-filter trend was mechanically induced by changing sample composition.

**Canonical decision:** no trend claim will be based on the filtered direct-business land series.

## 4. BLS land cost is not terminal rent

BLS capital costs are constructed from productive stocks and estimated asset rental prices. Those rental prices use industry rates of return (internal when acceptable, otherwise external), depreciation/revaluation for depreciable assets, and tax parameters.

This is not an observed land-rent transaction.

It follows that BLS land capital cost has ambiguous relation to the paper's terminal scarcity-rent concept:
- it can **over-allocate** monopoly profits or quasi-rents to measured land because the industry return is embedded in the rental price;
- it can **understate** scarcity by omitting unmeasured assets/bottlenecks and by excluding upstream/foreign land from the direct mapping.

Therefore BLS land cost is permanently reclassified as a **user-cost sensitivity / allocation object**, not as *the* rent series and not as a clean lower bound on pure terminal rent.

## Revised scarcity-measurement hierarchy

The project now keeps four objects separate:

1. **Owner-housing land/site stock residual** — balance-sheet stock evidence.
2. **BLS measured-land capital-cost allocation** — user-cost/sensitivity evidence.
3. **Direct mapped PCE land allocation** — coverage-limited first-stage exposure measure.
4. **Terminal scarcity rent** — the latent theoretical target, to be bounded from multiple objects rather than identified with any one series.

## What this means for the paper's claim

This correction weakens one possible empirical shortcut but improves the project.

The generation-4 business-land series should **not** be used to support a rising 1997–2016 scarcity trend.

The stronger empirical scarcity evidence remains:
- the long-run owner-housing land/site **stock** residual;
- the paper's own capitalization-rate sensitivity for site-rent flow;
- shelter's rising PCE weight;
- and, eventually, a multi-object scarcity band that does not depend on BLS user-cost allocation alone.

The next research task should diagnose and recover the large land-intensive scope gaps where possible — especially real estate and farms — rather than filtering those industries away.
