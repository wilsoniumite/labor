# D-Q generation 3: full upstream benchmark and capital refinement

Date: 2026-08-24

## The main breakthrough

A January 2026 BEA working paper, **Samuels and Senel, "A Value Chain Approach to Measuring the U.S. Production Structure,"** performs almost exactly the total-requirements/KLEMS operation required by canonical D-Q.

For PCE it computes domestic factor contributions through the full upstream chain using BEA domestic requirements, market-share, import-use, and KLEMS factor data.

Its consumption summary statistics for 1997–2023 imply mean gross-PCE shares of approximately:

- **Human effort: 48.0%**
- **Identified IT/R&D/software/art capital: 6.9%**
- **Other capital: 34.3%**
- **Foreign content: 10.9%** (5.6% imported intermediates + 5.3% direct imports)

The published rounded components sum to 100.1%.

This is not the paper project's final scarcity decomposition, because BEA's `other capital` is explicitly mixed.

## Why `other capital` is the key remaining node

The BEA paper defines other capital to include:
- instruments,
- structures,
- **land**,
- inventories,
- transportation equipment,
- other equipment.

So its 34.3% mean share cannot be called produced capital and cannot be called scarcity rent. It is exactly the mixed node that must be opened next.

## Annual full-chain benchmark

Figure 9 of the BEA paper was digitized only at the robust grouped level:
- college + non-college labor;
- direct + indirect imports;
- total domestic capital as the residual to 100%;
- the directly visible `other capital` line.

The digitized sample means differ from the paper's published grouped means by at most **0.15 percentage points**, which is sufficient for a supporting trajectory but not a substitute for the authors' underlying data.

For 2016, the digitized full-chain benchmark is approximately:
- human effort: **47.2%**
- domestic capital: **42.2%**
- foreign content: **10.6%**

Compare this with the project's direct 2016 producer-stage result:
- direct labor: **29.6%**
- direct domestic capital: **24.1%**
- intermediate inputs still requiring recursion: **41.9%**

This is exactly the expected effect of the Leontief recursion: upstream labor and capital embedded in intermediate inputs move into the terminal factor shares.

## Current 2026 capital detail

BEA/BLS now publishes an experimental expanded-capital workbook for 1997–2024.

It splits:
- IT capital into computer hardware and communications equipment;
- other capital into instruments/office equipment, structures+land+inventories, transportation equipment, and other equipment.

The expanded categories reconcile to the coarse KLEMS IT/other-capital aggregates to a maximum gap of:
- IT: **$0.001000B**
- other capital: **$0.002000B**

Applied to the project's direct PCE mapping, 2016 PCE contains:
- direct identified produced capital: **7.22%**
- direct structures+land+inventories: **16.84%**

The latter is now a much narrower scarcity-relevant node than generic KLEMS capital, but it still mixes produced structures and inventories with land.

## Important vintage/concept caveat

The BEA working paper uses an earlier ILPA implementation and notes that its version implicitly assigns net taxes on products to capital. The current April-2026 KLEMS release has been updated. Therefore:

- use the working paper as an **official full-chain benchmark and methodological validation**;
- use current 2026 KLEMS for the project's direct and asset-detail calculations;
- do not claim the digitized full-chain series and current direct series are one perfectly harmonized vintage.

## Implication for the original research question

This benchmark is substantive, not merely technical.

Total **production labor content of consumption remains around one-half** on average over 1997–2023, even as non-college labor's share declines and college labor rises.

That does not contradict a decline in **wage-financed consumption** (D-F), because financing origin and production factor content are separate objects.

For D-Q, however, it means the evidence should not be summarized as "PCE production is becoming mostly non-labor." The stronger empirical statement is that the composition of labor and capital changes, while a very large mixed `other capital` node — containing land — remains to be decomposed.

## Next step

The highest-value next move is now the **structures + land + inventories split**, not another generic I-O pass.

For housing, the project already has a matched structure/site decomposition. For non-housing industries, the current KLEMS detailed asset category still groups land with structures and inventories, so the next task is to identify asset-level sources that separate those three components or bound the land share.
