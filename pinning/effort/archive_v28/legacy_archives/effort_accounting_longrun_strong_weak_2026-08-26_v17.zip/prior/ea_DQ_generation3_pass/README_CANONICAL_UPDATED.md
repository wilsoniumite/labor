# Effort accounting — canonical status

**Date:** 2026-08-23

This file supersedes the accretive `README_CURRENT_PROGRESS.md` files as the canonical project-status document. Older READMEs remain research logs and contain some deliberately retained superseded statements.

## Original empirical target

The work is still aimed at the paper's central empirical question: whether the economy's price recursion is becoming less wage-linked and more scarcity-linked.

The consolidation adds one crucial distinction:

- **D-F:** where the purchasing power financing PCE comes from;
- **D-Q:** what the consumed goods and services themselves resolve into through production.

Those are different recursions and must remain separate.

## Canonical architecture

- **A:** household resource claims by economic origin.
- **B:** accrual/current-resource timing bridge.
- **C1:** 100% PCE product/use spine.
- **C2:** 100% PCE immediate delivery/payment route.
- **C-T:** current-DPI sufficiency lower bound (auxiliary).
- **D-F:** ultimate financing origin of PCE.
- **D-Q:** recursive production/factor content of PCE.

## Current headline status

- **A:** partial — legal-form 1960–2025; conservative origin anchors 2005–2025.
- **B:** strong — annual identity backbone plus detailed 2024 bridge; one minor recent-vintage warning remains.
- **C1:** strong/frozen data — exact 1950–2025 product spine.
- **C2:** partial — 40.99% of 2023 PCE is route-classified in the latest modern ledger; the long-run hard-form backbone spans 1950–2025.
- **C-T:** strong auxiliary — 2000–2023; 2023 hard lower bound 10.62%.
- **D-F:** open — legacy pro-rata financing accounting exists, but the canonical replacement has not been built.
- **D-Q:** main substantive frontier — housing/health are advanced; purchaser-price → producer/input bridge is next.

## QA result

**18 PASS, 1 WARN, 0 FAIL** across the consolidation checks.

The one warning is not a broken accounting identity: several B0 component series for 2021–2024 carry tiny cross-vintage differences, with a maximum 2024 residual of $3.5B (~0.016% of DPI). Before publication those series should be re-pulled from one common NIPA vintage.

## Files to use

- `CANONICAL_ONTOLOGY.md`
- `MASTER_MODULE_LEDGER.csv`
- `SUPERSESSION_REGISTER.csv`
- `QA_CHECKS.csv`
- `FINAL_FIGURE_REGISTRY.csv`
- `CONSOLIDATION_REPORT.md`
- `PROJECT_STATUS_OVERVIEW.png`

Do not use an old exploratory C*/D* graph number as a paper-facing identifier without checking the supersession register.


---

## 2026-08-24 — D-Q purchaser-price bridge

The first D-Q accounting layer is operational.

BEA's annual PCE Bridge maps NIPA PCE categories to I-O commodities and decomposes purchaser value into producer value plus transportation, wholesale, and retail margins for 1997–2016.

In 2016 the distribution-margin share is about 44% of durable-goods purchaser value, 44% for food-at-home, 57% for clothing, 46% for gasoline/energy goods, and 45% for other nondurables. Most service families have little or no trade-margin layer.

Cross-account validation against the canonical C28 PCE families has a maximum 1997–2016 family-level discrepancy of 9.748% (excluding NPISH, which is not represented in the bridge on the same basis).

Next D-Q step: I-O commodity → producing industry and imported supply, then direct/total requirements.


### Vintage caution for the D-Q bridge

The 1997–2016 downloadable PCE Bridge is not on the same vintage as the current 2026 NIPA spine. Comparable-family totals differ by at most 1.00% in aggregate, but individual family gaps reach 9.75%.

Accordingly, its margin and commodity shares are **calibration weights**, not current-dollar controls. Current NIPA levels remain authoritative. A later pass should pull the newer Input-Output Underlying Detail PCE Bridge/benchmark information before publication.


---

## 2026-08-24 — D-Q generation 1

The purchaser-price bridge is now integrated into a first-generation D-Q recursion.

- 2016 PCE producer values are mapped into broad direct producer nodes from BEA I-O commodity codes.
- Distribution margins are carried as separate transport/wholesale/retail service nodes rather than being attributed to the goods producer.
- The 1997–2016 bridge ratios are rescaled to current NIPA family controls.
- Outside the bridge window, family-specific observed min–max ratios create a 1950–2025 calibration band rather than truncating the graph.

This is still pre-Leontief: imports, producing-industry shares, indirect requirements and terminal value added remain the next layer.


---

## 2026-08-24 — D-Q generation 2

Current 2026-vintage BEA-BLS KLEMS data now decompose the first producing nodes into direct labor, direct capital compensation, energy, materials, and purchased services for 1997–2016 PCE.

2016 direct shares of PCE:
- labor: 29.55%
- KLEMS capital: 24.06%
- energy: 1.76%
- materials: 13.10%
- purchased services: 27.06%
- unresolved/NPISH: 4.47%

This is still a **direct** cost decomposition, not the total-requirements result. Energy, materials, and purchased services must be recursively traced upstream. Direct labor is therefore a lower bound on total embodied domestic labor content.


---

## 2026-08-24 — D-Q generation 3

BEA WP2026-01 provides an official full-upstream benchmark using domestic requirements + KLEMS, essentially validating the canonical D-Q method.

For consumption over 1997–2023, its published mean shares are about:
- 48.0% human effort,
- 6.9% identified IT/R&D/software/art capital,
- 34.3% `other capital`,
- 10.9% foreign content.

The key unresolved node is therefore not generic intermediate input anymore: it is BEA's **other capital**, which explicitly includes structures, land, inventories, transportation equipment, instruments, and other equipment.

Current 2026 experimental KLEMS detail further splits this node. The direct PCE calculation now isolates a structures+land+inventories component, but land itself remains mixed with produced structures and inventories.
