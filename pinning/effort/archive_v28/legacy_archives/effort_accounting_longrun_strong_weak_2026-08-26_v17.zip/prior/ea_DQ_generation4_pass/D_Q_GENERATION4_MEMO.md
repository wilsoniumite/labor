# D-Q generation 4: land-service split and owner-housing capital-service benchmark

Date: 2026-08-24

## Main advance

BLS's current capital-details workbook exposes **current-dollar capital costs by asset type and industry**. That means the project's mixed KLEMS capital node can now be split using official capital-income weights rather than inferred from stocks.

For each mapped KLEMS industry, BLS reports:
- equipment;
- structures;
- intellectual-property products;
- rental residential capital;
- inventories;
- **land**;
- total capital costs.

BLS defines capital cost as the asset rental price times the productive stock, with rental prices reflecting the industry's rate of return, depreciation/revaluation where applicable, and tax treatment.

## Cross-vintage QA

The BLS capital-details release and the April-2026 BEA-BLS integrated production account are adjacent but not perfectly identical vintages.

Across matched industry-years 1997–2024:
- median absolute gap between BLS `All assets` capital cost and current KLEMS capital compensation: **3.139%**
- 90th percentile absolute gap: **57.262%**
- maximum gap: **11344.44%**
- BLS asset categories themselves sum to `All assets` to a maximum residual of **$0.002000B**

Therefore the canonical calculation keeps current KLEMS total capital as the dollar control and uses BLS **asset shares** to split it.

## Direct business land-service floor in PCE

This pass corrects an important conceptual issue from the previous generation.

The PCE Bridge's owner-occupied housing lines were previously proxied with the business real-estate industry's KLEMS structure. BLS explicitly excludes owner-occupied residential structures from private-business capital measures, so that shortcut is not valid.

Generation 4 therefore:
- identifies business land-service cost for mapped market-production nodes;
- treats transport/wholesale/retail margins as their own producing branches;
- **removes owner-occupied housing and farm-dwelling imputation from the business-industry proxy** and carries them as a separate special-production branch.

For 2016:
- direct business land-service cost = **1.72% of total PCE**
- owner-housing special branch = **11.46% of PCE**
- direct labor = **29.05%**
- direct produced-capital service cost = **14.86%**
- intermediates still requiring upstream recursion = **38.45%**

The direct business land number is a **lower bound on domestic land-service content** because it excludes:
1. land embodied upstream in intermediate inputs;
2. owner-occupied housing land services;
3. foreign land/resource content.

Largest 2016 direct business-land shares by product family:
- Housing & utilities: 3.43% of that family's PCE
- Food & beverages (off-premises): 1.92% of that family's PCE
- Clothing & footwear: 1.79% of that family's PCE
- Other nondurable goods: 1.70% of that family's PCE
- Other household services: 1.53% of that family's PCE

## Owner-occupied housing: an official flow-like benchmark, but not NIPA site rent

BLS also publishes a separate total-economy capital file that explicitly reports **Owner-Occupied structures** and **Owner-Occupied land** capital costs.

This is valuable because it produces a flow-like land-service measure without inventing a capitalization rate.

However, it is **not the same concept as NIPA imputed owner-housing PCE**. In 2024:
- BLS owner-occupied land capital cost: **$557.6B**
- BLS owner-occupied structures capital cost: **$2639.2B**
- BLS land share of owner structures+land capital cost: **17.4%**
- Fed/BEA matched land residual share of owner property **stock**: **38.0%**
- BLS structures+land capital cost / NIPA imputed housing PCE: **134.6%**

The last ratio is far from one, confirming that BLS capital-service costs must **not** simply replace or be added to the NIPA housing production account.

The cross-system ratio `BLS owner-land capital cost / Fed matched land-stock residual` is **3.26% in 2024**. It is useful as a user-cost diagnostic, but it is not a matched capitalization rate because the numerator and denominator come from different capital-stock/rental-price systems.

## Why this materially improves the scarcity accounting

The project now has three increasingly strong land objects:

1. **Stock evidence:** matched owner-property market value minus matched structure current cost.
2. **Direct business flow evidence:** BLS land capital-service cost embedded in first-stage PCE production.
3. **Owner-housing flow-like benchmark:** BLS owner-occupied land capital cost, kept separate from NIPA PCE because the concepts do not reconcile one-for-one.

This is much better than multiplying a land stock by an arbitrary 4–6% capitalization rate.

## Remaining blocker

The main remaining D-Q scarcity problem is now upstream, not direct:

- recursively trace land capital-service content embodied in materials, energy, and purchased services;
- decide whether BLS land capital cost is sufficiently close to the paper's `terminal rent` concept or should remain a lower-bound/sensitivity measure;
- keep mineral/resource rents and temporary bottlenecks separate from permanent land.

## Sources

BLS capital details for major sectors and industries, December 19 2025.
BLS total-economy nonprofit/owner-occupied capital measures, April 29 2026.
Current BEA-BLS integrated production account, April 27 2026.


## Robustness correction: cross-system capital-quality filter

The raw BLS/KLEMS comparison contains a small number of very large industry-level discrepancies even though the median gap is small. I therefore do **not** treat the unfiltered 1.72% 2016 land figure as canonical.

A quality sensitivity now identifies land only when BLS `All assets` capital cost and current KLEMS capital compensation agree within a stated tolerance; otherwise the entire capital portion remains `capital mix unresolved`.

For 2016, identified direct business land-service cost is:
- **0.95% of PCE** with a 10% agreement filter;
- **0.98%** with a 25% filter;
- **1.00%** with a 50% filter.

The difference between these lines is **measurement-system sensitivity**, not economic uncertainty. The strict line is the safer lower-bound presentation; capital from failed mappings stays unresolved rather than being forced into land or produced capital.
