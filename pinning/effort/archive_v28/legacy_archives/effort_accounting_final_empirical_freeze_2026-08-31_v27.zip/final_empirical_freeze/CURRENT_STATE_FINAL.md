# Final empirical state — 2026-08-31

The uploaded BEA national distribution file removes the last major data-ingestion blocker.

## Main figures
- Figure 3 real-wage fork — FINAL / retained.
- C1 PCE composition — FINAL.
- D-Q production labor content — FINAL strong/weak.
- S1 owner-land/site stock share — FINAL stock evidence.
- D-F financing origin — FINAL partial-identification architecture; annual source distributions now observed for 2004–2023.
- D-F/Q synthesis — FINAL synthesis candidate.

## Key validation
The former fixed-2018 source-profile calibration was surprisingly accurate:
- mean absolute change in the modern D-F central estimate after replacing it with actual annual profiles: **0.13 percentage points**;
- maximum absolute central change: **0.50 percentage points**.

So the annual-data ingestion strengthens provenance without overturning the substantive D-F result.

The uploaded national DPI decile profile and the joint PCE/DPI DPI profile agree closely; the maximum single-decile difference over 2004–2023 is **0.40 percentage points**.

## What remains
No major data branch is open.

Remaining work is final-output work:
1. caption/claim audit against the manuscript;
2. source/provenance formatting;
3. optional editable rebuild of the retained Figure 3;
4. assembly of the final empirical package / manuscript insertion materials.
