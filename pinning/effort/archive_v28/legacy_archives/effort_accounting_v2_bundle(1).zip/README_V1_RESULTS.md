# Effort accounting — v1 status

## What has actually been built

### Graph A: legal-form household resource audit, 1960–2025

This is intentionally the *pre-model* picture.

Denominator:
- employee compensation (private + government wages + supplements)
- proprietors' income
- rental income
- personal interest income
- personal dividend income
- government social benefits

The six shares sum to exactly 100% in every year.

Selected endpoints:

| Component | 1960 | 2025 |
|---|---:|---:|
| Employee compensation | 68.9% | 56.1% |
| Proprietors' income | 11.6% | 7.5% |
| Rental income | 3.8% | 4.0% |
| Interest income | 7.1% | 7.0% |
| Dividends | 3.1% | 8.0% |
| Social benefits | 5.6% | 17.3% |

The important fact at this stage is not an automation claim. It is that the receipt-side composition has shifted substantially before any effort-content assumptions are imposed.

### Graph B1: saving and retained earnings

Plotted as a percentage of PCE:
- BEA personal saving
- Federal Reserve / corporate undistributed profits

This separates household saving from corporate retention/reinvestment.

### Graph B2: household financial bridge

Plotted as a percentage of PCE:
- household loan incurrence
- household financial-account net lending (+) / borrowing (-)

The two should not be forced to reconcile with NIPA personal saving without accounting for conceptual differences and capital-account adjustments.

### Equity effort proxies

Observed:
- index share of long-term fund assets: 19% (2010) -> 52% (2025)
- active equity mutual-fund expense ratio: 1.06% (2000) -> 0.64% (2025)
- index equity mutual-fund expense ratio: 0.27% -> 0.05%
- NAICS 5239 total human hours: ~432m (1987) -> ~1,287m (2025)

Interpretation:
- passive strategy share rises sharply;
- management price per dollar falls;
- total sector hours still rise.
Therefore the crucial next denominator is AUM/output: delegation/passivization is established more clearly than economy-wide human-hours shedding.

### Credit effort proxy

Commercial-banking output per labor hour implies an inverse labor-requirement index:
- 1987 = 100
- 2024 = ~39

This is a strong decline in system labor per unit of measured banking output, concentrated especially before the 2010s.

## Rental module

`rhfs_management_module_v0.py` is ready for RHFS PUF files.

It measures, by survey wave:
- property share managed by owner/unpaid agent
- property share managed by directly employed agent
- property share managed by management company
- other
- mean/median owner monthly management hours among owner-managed properties
- weighted aggregate owner-management property-hours

Important limitation:
the current public-use file does not give a clean exact-unit count suitable for the desired unit-weighted historical series. V0 therefore reports property-weighted results only. Unit-weighting must be added from Census Table Creator or another explicitly documented size measure.

## What has *not* been done yet

No final effort/capital/scarcity split has been imposed.

That is intentional.

Still missing:
1. RHFS wave microdata staged locally and run through the rental module.
2. AUM-matched investment-management labor intensity.
3. Time-varying proprietor labor/effort share from microdata.
4. Look-through split of rental income into management effort, structure return, and site rent.
5. Look-through split of interest/dividends into effort, reproducible-capital return, scarcity, and unresolved.
6. Full 100%-PCE immediate-financing identity.
7. Recursive ultimate-origin consumption graph.

## Main empirical discipline

The final graph will be allowed to contain an `unresolved` share.

It will not be forced to 100% by assuming uncertain income is labor or capital.
The accounting identity will still hold:

    effort
  + produced-capital return
  + scarcity rent
  + intertemporal claim
  + unresolved
  = 100% of consumption
