# Dividend-weighted industry look-through — 2024 pilot

## Goal

The previous industry pilot showed that sectors differ enormously in the share of
value added paid as current employee compensation.

This module now weights those production environments by an actual corporate-claim
flow: **net corporate dividends by domestic industry**.

It is a production-side look-through, not yet a household-incidence decomposition.

## Coverage

Total domestic net corporate dividends in 2024:
    $1,880.0B

The six already-decomposed industries pay:
    $1,105.4B
    = 58.8% of the domestic total.

They also account for:
    $1,522.6B
    = 50.1% of domestic corporate profits after tax.

The uncovered domestic remainder remains explicitly unresolved.

## Six-sector claim-flow composition

The covered industries span underlying 2024 employee-compensation shares of value
added from about 5.5% (real estate/rental/leasing) to about 80.2%
(health care/social assistance).

The dividend-weighted mean of those industry compensation shares is about:
    48.6%

The profit-weighted mean is about:
    49.4%

These are NOT estimates that 48.6% of dividends are
"labor income."

They mean:

> among the six covered sectors, the average production environment backing one
> dollar of 2024 dividend flow has an industry value-added account in which about
> 48.6% is paid as employee compensation.

That is a very different statement.

## Why the distinction matters

A shareholder can receive a passive dividend from:
- a highly labor-intensive health-care corporation;
- a software/information corporation with a much larger operating-surplus share;
- a real-estate corporation whose value added is overwhelmingly non-compensation.

Legal receipt form alone therefore contains very little information about the
recursive human-effort content of the underlying production network.

## Payout ratio

The graph also reports:

    net dividends / current corporate profits after tax

by industry.

This is an accounting ratio, not a behavioral dividend-payout policy parameter.

Ratios above 100% can occur. In 2024, real estate/rental/leasing is slightly above
100%. That does not violate an identity: current distributions can draw on prior
retained earnings, financing, intra-sector balance-sheet positions, and timing
differences.

This is precisely why retained earnings and financial intermediation belong between
production and household consumption.

## Production-side versus household-side dividends

Domestic-industry net dividends are NOT equal to personal dividend income.

The household receives claims through:
- directly held domestic equities;
- mutual funds and ETFs;
- retirement/pension accounts;
- foreign corporations and other cross-border positions;
- financial intermediaries.

So this module solves the **production-origin side** of the dividend problem only.

A later bridge must map domestic/foreign corporate distributions through the
financial accounts to households.

## Next steps

1. Expand the industry coverage from six sectors toward the full domestic dividend
   total.
2. For each sector, split the non-compensation residual into:
   - production taxes,
   - consumption of fixed capital,
   - net operating surplus.
3. Within NOS, isolate measurable land/resource rents and leave the remainder
   unresolved.
4. Add the household financial-ownership bridge so the industry production weights
   can be mapped to personal dividend income.
