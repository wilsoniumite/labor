# Effort accounting — current progress

## Built and audited

### A. Legal-form household resource audit
1960–2025:
- employee compensation
- proprietors' income
- rental income
- interest
- dividends
- government social benefits

### A1. Conservative economic-origin graph
Measured anchor years 2005/2010/2015/2020/2025:
- employee compensation -> effort
- imputed proprietor labor -> effort
- all other primary claims -> unresolved
- transfers remain separate

Central classified/imputed effort share:
- 2005: 66.2%
- 2010: 62.3%
- 2015: 61.6%
- 2020: 58.0%
- 2025: 59.0%

This is deliberately a lower-layer estimate, not the final origin decomposition.

### Proprietors
BEA proprietors' income is mixed income.
First aggregate labor-value proxy:

| year | wage-only effort | total-comp effort |
|---|---:|---:|
| 2005 | 43.9% | 54.5% |
| 2010 | 38.4% | 47.7% |
| 2015 | 35.7% | 44.1% |
| 2020 | 33.9% | 41.6% |
| 2025 | 34.6% | 42.0% |

Residual remains unresolved, not automatically capital.

### B0. Disposable-income disposition identity
DPI = PCE + personal saving + personal interest payments + personal transfers.

### B1/B2. Saving and financial bridge
- personal saving
- household loan incurrence
- household net lending
- corporate retained earnings

### B3. Corporate payout / retention
Exact identity:
profits after tax = net dividends + undistributed profits.

This prevents corporate earnings generated today from being confused with household
income distributed today.

### Equity claim-management effort
- index/passive share rises sharply
- asset-management hours per ICI long-term-fund dollar proxy falls strongly

Important:
this measures claim-selection/intermediation effort, NOT the production effort inside
the corporations generating dividends.

### Credit
Commercial-banking inverse labor productivity provides a system-effort proxy.

### Rental system effort
Two aggregate diagnostics:
- NAICS 5311 lessor hours per renter household falls
- NAICS 5313 related-real-estate-service hours per renter household rises

Interpretation: substantial delegation/outsourcing; lessor-side labor decline alone
cannot be called automation.

### Rental-income composition
BEA rental income of persons is not synonymous with cash landlord rent.

By 2024 approximately:
- 78% owner-occupied nonfarm housing imputation
- 15% tenant-occupied housing
- 7% other/residual

Thus RHFS landlord-management effort cannot be applied to the entire rental-income
series.

## Still open

1. Stage and run RHFS public-use microdata.
2. Industry/occupation-matched proprietor labor imputation.
3. Housing production-account split:
   management/intermediate labor vs structure return vs site rent.
4. Corporate production look-through:
   labor / produced-capital / scarcity content of profits.
5. Interest look-through by borrower / intermediary.
6. After-tax origin decomposition.
7. Sharp accounting bounds for which income sources finance PCE versus saving/outlays.
8. Final 100%-of-PCE immediate-financing graph.
9. Recursive ultimate-origin graph.


---

## New pass: corporate production look-through

Added `corporate_production_lookthrough_1960_2025.csv`.

Exact BEA identities:

    gross corporate value added
      = employee compensation
      + consumption of fixed capital
      + production taxes less subsidies
      + net operating surplus

and:

    net operating surplus
      = corporate profits with IVA + CCAdj
      + net interest & miscellaneous payments
      + business current transfers.

2025 gross corporate value-added shares:
- employee compensation: 55.3%
- consumption of fixed capital: 15.3%
- production taxes less subsidies: 7.9%
- net operating surplus: 21.5%

This is the correct first look-through for dividends:
passive ownership says little about the human labor involved in producing the
corporate cash flow.

---

## New pass: transfer composition

Added `transfer_composition_1960_2025.csv`.

The aggregate social-benefit line is now split into:
- Social Security
- Medicare
- Medicaid
- unemployment insurance
- other

2025:
- Social Security: 32.5%
- Medicare: 25.2%
- Medicaid: 20.9%
- unemployment insurance: 0.8%
- other: 20.7%

Social Security + Medicare + Medicaid = 78.5% of benefits in 2025.

Of the nominal increase in total social benefits from 1965 to 2025:
- Social Security accounts for ~32.3%
- Medicare ~25.4%
- Medicaid ~21.0%
- UI only ~0.7%
- other ~20.6%

Thus ~78.7% of the long-run nominal transfer increase is accounted for by
Social Security + Medicare + Medicaid.

Interpretation:
the smooth secular transfer expansion in the old fiscal graph has a powerful
aging/health-program explanation; unemployment insurance mainly generates crisis
excursions.

Next sharp test:
construct a working-age/non-health financing view rather than reading the aggregate
transfer trend as a technology proxy.


---

## New pass: health-transfer and retirement drivers

See `TRANSFER_RETIREMENT_DRIVER_SUMMARY.md`.

Main update: health-transfer growth has material relative-price and real-intensity components; recent aggregate retirement data show later rather than earlier claiming; and mechanically excluding SS+Medicare+Medicaid reduces the old 1960–2025 direct-wage share decline from about 19.4pp to about 3.0pp. These programs therefore carry the accounting trend, but their own causal drivers remain the object to explain.


---

## Latest pass: health financing socialization and conditional retirement test

See `LATEST_PASS_SUMMARY.md`, `HEALTH_SOCIALIZATION_PRICE_VOLUME_MEMO.md`, `MEDICARE_HOSPITAL_DECOMPOSITION_MEMO.md`, and `RETIREMENT_EXIT_TEST_DESIGN.md`.


---

## New pass: sharp PCE financing bound and dividend-weighted industry look-through

Graph C now has a 2017 assumption-free hard lower bound: at least 8.08% of total PCE exceeds the current DPI of the income decile doing the consuming. The first dividend-weighted production look-through covers 58.8% of 2024 domestic net corporate dividends across six sectors and keeps the remainder explicitly unresolved.


---

## New pass: property-income timing correction

BEA personal property income is an accrual concept: in 2024 about 53% of personal interest income and about 80% of rental income are imputed rather than monetary, while personal dividends include pension-plan dividends and mutual-fund pass-throughs. Graph A therefore needs separate accrual-income and cash/current-resource versions before it can feed Graph C.


---

## New pass: employee-compensation timing split

2024 employee compensation is about 82% wage/salary disbursements, 11.8% employer pension/insurance contributions, and 5.8% employer government-social-insurance contributions. Labor origin and current-cash availability must therefore be separate dimensions in Graphs A–C.


---

## New pass: measured pension floor inside personal dividends

2024 IMA pension funds receive about $204B of dividends, roughly 9.2% of the scale of NIPA personal dividend income. This is a measured lower bound on the importance of pension intermediation; the remainder is not assumed to be current cash because mutual-fund and other pass-through routes remain.


---

## New pass: exact 2024 accrual-to-route bridge

A 2024 route ledger now separates current disbursements, insurance/in-kind claims, deferred/imputed accruals, and timing-unresolved claims before walking exactly through social contributions, personal taxes, DPI, PCE, other outlays, and personal saving. Economic origin and cash timing are now formally separate dimensions.


---

## New pass: public medical benefits directly on the PCE denominator

Medicare+Medicaid benefit flows now have a direct PCE-normalized series: 2.0% of PCE in 1970 versus 10.3% in 2024. This is a directly identified non-wage/in-kind consumption route, not a causal origin estimate.


---

## New pass: program-specific Medicare/Social Security funding look-through

2025 Social Security non-interest income is overwhelmingly payroll-tax financed, while combined Medicare is only about one-third dedicated payroll tax and nearly one-half federal/state general revenue, with beneficiary premiums also material. A single transfer-linkage coefficient is inappropriate.
