# Industry production look-through pilot

## Purpose

The aggregate corporate look-through left `net operating surplus` unresolved.
Before splitting profits into produced-capital return, scarcity rent, monopoly rent,
etc., this pilot asks a simpler upstream question:

> How much of each industry's nominal value added is paid as current employee
> compensation, and how much remains in the non-compensation residual?

For each industry/year:

    compensation share
      = employee compensation / nominal value added

    non-compensation residual
      = 1 - compensation share

BEA defines value added as:

    compensation of employees
    + taxes on production and imports less subsidies
    + gross operating surplus.

Therefore the residual is **taxes + gross operating surplus**.

It is NOT "profit", NOT "capital", and NOT "scarcity rent."

## 2024 result

The sectors are radically different.

Approximate compensation shares of nominal value added:
- health care & social assistance: ~80%
- professional/scientific/technical: ~68%
- finance & insurance: ~50%
- manufacturing: ~47%
- information: ~37%
- real estate/rental/leasing: ~6%

This is exactly why legal household income labels are too coarse.

A dollar of ownership claim backed by a health-care enterprise is attached to an
underlying production sector that is highly compensation-intensive. A dollar backed
by real-estate activity sits on a production account dominated by non-compensation
value added.

## Time patterns in the first four fully extracted sectors

2005 -> 2024, approximate compensation share:
- manufacturing: declines from roughly 53% to 47%
- finance & insurance: roughly 55% to 50%, with large cyclical movement
- professional/scientific/technical: roughly 65% to 68%
- health care & social assistance: roughly 82% to 80%

So there is no single economy-wide "automation = labor share falls everywhere"
pattern.

The model-facing empirical object needs sectoral composition.

## Important real-estate caveat

The real-estate/rental/leasing industry includes housing-service production and is
structurally unusual. Its tiny compensation share does not mean 94% is pure land
rent. The residual contains:
- depreciation/consumption of fixed capital,
- interest and other property-income flows within GOS,
- taxes,
- structure return,
- owner-occupied housing imputation,
- land/site rents,
- other operating surplus.

This sector needs its own land-versus-structure decomposition, which is already being
built elsewhere in the project.

## Data construction

Value added:
- quarterly BEA GDP-by-industry nominal value added, $B SAAR;
- annual value = mean of four quarters.

Compensation:
- BEA annual compensation of employees by domestic private industry, $M converted
  to $B.

Health care & social assistance nominal value added is derived as:
    (Educational Services + Health Care + Social Assistance)
    - Educational Services,
using two additive current-dollar BEA industry series.

For Information and Real Estate/Rental/Leasing, this pass extracts compensation for
2020 and 2024 only; they are therefore displayed as a short comparison rather than
silently interpolated backward.

## Next step: profit weighting

The correct next bridge to household dividends is not to apply these sector labor
shares directly to dividends.

Instead:

1. obtain corporate profits by industry;
2. estimate each industry's share of the corporate profit pool;
3. use industry production accounts to characterize the production environment
   underlying those profit claims;
4. separately decompose GOS into depreciation/produced-capital services, land/resource
   rents, and unresolved surplus.

That creates a profit-weighted look-through of household dividend claims without
pretending dividends themselves are employee compensation.
