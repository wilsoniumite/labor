# Employee-compensation timing/routing audit — 2024

This is another correction to the naive idea that:

    employee compensation = current cash wage financing.

BEA's 2024 NIPA summary accounts report approximately:

    employee compensation                      $15,027.1B
      wages and salaries                       $12,387.9B
      supplements                               $ 2,639.1B

The supplements split exactly into:

    employer pension & insurance contributions $ 1,772.7B
    employer government social insurance       $   866.4B

So only about 82% of measured employee compensation is wage-and-salary
disbursement.

## Economic routing

### Wages and salaries
Closest to the current household cash/remuneration branch, though NIPA wages can
include some remuneration in kind and must still pass through taxes/saving.

### Employer pension and profit-sharing contributions
Deferred compensation / financial claims.

These belong in Graph B:
    current production labor compensation
      -> pension contribution
      -> pension asset/entitlement
      -> future benefit or asset claim

They should not be treated as current spendable household cash.

### Private insurance-fund contributions
These are also compensation for labor, but the spending power is mediated through
insurance rather than necessarily handed to the worker as cash.

For health insurance in particular, this is exactly the non-cash-wage consumption
route we have been studying:
    labor compensation
      -> employer insurance premium/contribution
      -> insurer
      -> medical service consumption.

The BEA aggregate `private insurance funds` category is broader than health
insurance, so this pass does not classify the entire amount as health consumption.

### Employer government social-insurance contributions
These are labor-linked at origin but routed through public social insurance rather
than current private cash income.

They therefore belong in the fiscal look-through:
    labor compensation
      -> social-insurance contribution
      -> government fund/claim
      -> benefit entitlement / transfer expenditure.

## Implication for the project

We now need two orthogonal labels for every flow:

1. **economic origin**
   - human effort
   - produced capital
   - scarcity
   - unresolved

2. **timing/intermediation route**
   - current cash/disbursement
   - private insurance/in-kind
   - deferred pension/asset claim
   - public social-insurance claim
   - imputed/accrued
   - transfer
   - debt/intertemporal

A dollar can be 100% labor-origin while simultaneously being 0% current cash.

That is why the original one-dimensional `wage linked` coefficient cannot do all
the work the final graph requires.

## Accounting warning

The NIPA personal-income account later subtracts contributions for government social
insurance. Therefore these employer contributions must be routed consistently in a
full personal-income identity; they cannot be added as spendable resources and then
also leave the tax/contribution subtraction unchanged.

This module is a routing audit, not yet a replacement personal-income identity.
