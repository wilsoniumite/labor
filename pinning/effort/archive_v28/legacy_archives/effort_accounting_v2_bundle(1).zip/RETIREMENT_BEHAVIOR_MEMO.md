# Retirement / labor-market exit proxies — v1

The user correctly pointed out that Social Security growth cannot be labeled
"demographics" without looking at retirement behavior. This module adds three
different objects.

## 1. Stock of retired-worker beneficiaries with an early-retirement reduction

SSA Table 5.B8 reports the percentage of current retired-worker beneficiaries whose
benefit is reduced for early retirement.

This is a STOCK measure. It is slow-moving because it contains many cohorts.

It rises from 11.8% in 1960 to a peak around 73.9% in 2010, then declines to
62.1% in 2024.

It must not be interpreted as the current year's claiming rate.

## 2. New retired-worker awards before full retirement age

SSA Table 6.B5 gives award-age distributions separately for men and women.
For 2010–2025 this module calculates:

    before-FRA share
      = share age 62
        + age 63
        + age 64
        + age 65 through month before FRA

and weights men/women by their award counts.

Result:
- about 70.5% of new award actions were before FRA in 2010;
- about 52.5% in 2025.

An independent 2025 SSA Table 6.B3 check shows 53.2% of all retired-worker awards
were explicitly recorded with an early-retirement reduction, close to the age-based
calculation.

### Policy caveat

FRA changed over this period. SSA notes:
- FRA was 66 for workers attaining 65 in 2008–2019;
- it then rose in two-month steps during 2020–2025;
- it is 67 for workers attaining 65 in 2025 or later.

Thus part of "before FRA" is mechanically policy-defined. The series is still useful,
but it is not a pure labor-demand outcome.

## 3. Labor-force participation, age 65+

BLS CPS:
- 20.8% in 1960
- historical low 10.8% in 1985
- 12.9% in 2000
- 17.4% in 2010
- 20.2% in 2019
- 19.5% in 2024
- 19.1% in 2025

BLS explicitly notes that the post-1985 increase may reflect personal preference
or economic necessity.

## What the aggregate evidence says

The recent aggregate data do **not** show a simple technology -> earlier retirement
story.

Since roughly 2010:
- the share of new retirement awards occurring before FRA falls sharply;
- age-65+ labor-force participation remains much higher than in 2000.

There are at least two very different interpretations compatible with this:

A. **stronger late-career labor demand / better health / policy incentives**
   -> people can and choose to work longer.

B. **weaker affordability of exit**
   -> people need to work longer because housing, health care, and other scarce
      necessities make retirement harder to finance.

Interpretation B is actually compatible with the paper's outside-option channel.

Therefore aggregate retirement timing cannot distinguish the model.

## Discriminating next test

The useful test is conditional:

    retirement/exit outcome
       = f(age, health, FRA/cohort rules, wealth/pension,
           occupation automation exposure,
           local housing/land cost,
           exposure × housing scarcity)

Possible outcomes:
- claiming Social Security before FRA
- transition out of employment between 55–64 / 60–69
- disability entry
- hours reduction
- retirement followed by re-entry

If automation exposure predicts earlier exit where exit is affordable but predicts
continued work where housing/health scarcity makes exit expensive, that would map
very closely to the paper's supply-side mechanism.
