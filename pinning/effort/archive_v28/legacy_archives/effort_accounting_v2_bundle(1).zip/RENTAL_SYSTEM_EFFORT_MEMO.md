# Rental system-effort proxy — first aggregate result

This module is deliberately a **delegation diagnostic**, not yet a decomposition
of rental income.

## Inputs

1. BLS Industry Productivity, Lessors of Real Estate (NAICS 5311):
   annual hours-worked index, 2017=100.
   BLS hours include wage/salary workers, unincorporated self-employed workers,
   and unpaid family workers.

2. Census Housing Vacancies and Homeownership:
   quarterly renter-occupied housing units, annualized here as the four-quarter mean.

3. BLS Industry Productivity, Activities Related to Real Estate (NAICS 5313):
   annual percent change in total hours worked. The published one-decimal growth
   rates are chained into an approximate 2005=100 hours index.

## Results

| year | renter households (m) | lessor hours per renter, 2005=100 | related-services hours per renter, 2005=100 | related-services / lessor hours, 2005=100 |
|---|---:|---:|---:|---:|
| 2005 | 34.1 | 100.0 | 100.0 | 100.0 |
| 2010 | 37.4 | 80.6 | 94.4 | 117.2 |
| 2015 | 42.8 | 72.7 | 98.4 | 135.4 |
| 2020 | 42.0 | 81.6 | 108.4 | 132.8 |
| 2025 | 46.1 | 79.9 | 111.9 | 140.1 |

## Reading

The lessor-side labor-intensity proxy falls materially:
about 100 in 2005 to about 80 in 2025.

But hours in `Activities Related to Real Estate` rise much faster than the rental
housing stock. Their per-renter proxy rises substantially.

That is exactly the pattern we worried about:
**less owner/lessor-side labor does not by itself establish automation.**
A substantial part can be labor delegated into specialized real-estate-service firms.

The relative related-services/lessor-hours index rises strongly, which is direct
aggregate evidence of organizational movement away from the lessor sector toward
specialized service activity.

## Limits

- NAICS 5311 covers all lessors of real estate, not only residential rentals.
- NAICS 5313 includes property managers but also other real-estate support activities;
  it is not a pure rental-management series.
- The 5313 chained index uses published one-decimal annual growth rates, so small
  chaining error is unavoidable.
- Renter households are an activity denominator, not units under professional management.
- These two sector series cannot simply be added as if every 5313 hour serves rental
  housing.

Therefore the result is best labeled:
`delegation / system-effort diagnostic`.

The RHFS microdata module remains the cleaner way to measure the management-channel
share directly. Once RHFS is staged, we can use its owner-vs-management-company
shares to decide how much of 5313 should be attributed to rental management.
