# Rental-effort module: data status

The measurement target is now well specified.

RHFS directly asks:
- who is responsible for day-to-day management (`MNGMNT`):
  1 owner/unpaid agent
  2 directly employed management agent
  3 management company
  4 other
- monthly owner/owner-agent management hours (`HRSMNGMNT`) when owner-managed.

The same core questions appear in Census/HUD documentation going back at least to 2012, so the intended panel is:
2012, 2015, 2018, 2021, 2024.

Important weighting detail:
- property-weighted management shares can be produced in every PUF once the files are staged;
- a topcoded `NUMUNITS_R` recode is explicitly available on the 2015 PUF;
- exact unit-count availability is not assumed for later waves.
The v1 script therefore detects a usable unit variable and creates unit-weighted results only where defensible.

This is preferable to silently mixing property shares and rental-unit shares.

Current blocker:
the official Census CSV endpoints are identified, but the execution container cannot directly fetch www2.census.gov CSV payloads in this session. The analysis script is ready to run as soon as the PUFs are staged locally.
