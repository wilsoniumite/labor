"""
rhfs_management_module_v1.py

Rental-management effort module for the effort-origin accounting project.

Measures two different concepts:

A. OWNER / RECIPIENT EFFORT
   - property share managed by owner or unpaid agent
   - monthly owner management hours among owner-managed properties

B. DELEGATION
   - directly-employed management agent
   - outside management company
   - other arrangements

The RHFS asks the same core management questions in at least 2012, 2015,
2021, and 2024 documentation:
  MNGMNT   Responsible for day-to-day management
  HRSMNGMNT Hours owner spends on day-to-day management

Management codes:
  1 property owner or unpaid agent
  2 management agent directly employed by owner
  3 management company
  4 other

IMPORTANT:
- Base estimates are PROPERTY-weighted using the final PUF weight.
- If a usable PUF `NUMUNITS_R` variable exists in a wave, the script additionally
  creates unit-weighted management shares and owner-hours per rental unit.
- Do not assume `NUMUNITS_R` is public in every wave. The 2015 codebook explicitly
  places a topcoded NUMUNITS_R recode on the PUF; later codebooks restrict many
  detailed unit variables. The script detects rather than assumes availability.

Official PUF directories:
  https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2012/
  https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2015/
  https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2018/
  https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2021/
  https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2024/

Usage:
  python rhfs_management_module_v1.py \
    --wave 2015=/path/file.csv \
    --wave 2018=/path/file.csv \
    --wave 2021=/path/file.csv \
    --wave 2024=/path/file.csv \
    --outdir effort_data/rhfs
"""

from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd

MANAGEMENT_LABELS = {
    1: "owner_or_unpaid_agent",
    2: "directly_employed_agent",
    3: "management_company",
    4: "other",
}

WEIGHT_CANDIDATES = [
    "WEIGHT", "REPWGT0", "FINALWGT", "WGT",
    "weight", "repwgt0", "finalwgt", "wgt",
]

UNIT_CANDIDATES = [
    "NUMUNITS_R", "numunits_r",
    "NUMUNITS", "numunits",
]


def parse_wave_arg(text: str) -> tuple[int, Path]:
    year, path = text.split("=", 1)
    return int(year), Path(path)


def col_ci(df: pd.DataFrame, names: list[str], required: bool = True):
    mp = {str(c).upper(): c for c in df.columns}
    for name in names:
        if name.upper() in mp:
            return mp[name.upper()]
    if required:
        raise KeyError(f"none of {names} found")
    return None


def clean_nonnegative(s: pd.Series) -> pd.Series:
    x = pd.to_numeric(s, errors="coerce")
    return x.where(x >= 0)


def weighted_mean(x: pd.Series, w: pd.Series) -> float:
    ok = x.notna() & w.notna() & np.isfinite(x) & np.isfinite(w) & (w > 0)
    if not ok.any():
        return np.nan
    return float(np.average(x[ok].astype(float), weights=w[ok].astype(float)))


def weighted_quantile(x: pd.Series, w: pd.Series, q: float) -> float:
    ok = x.notna() & w.notna() & np.isfinite(x) & np.isfinite(w) & (w > 0)
    if not ok.any():
        return np.nan
    xx = x[ok].astype(float).to_numpy()
    ww = w[ok].astype(float).to_numpy()
    o = np.argsort(xx)
    xx, ww = xx[o], ww[o]
    cdf = np.cumsum(ww) / ww.sum()
    return float(xx[np.searchsorted(cdf, q, side="left")])


def shares_by_weight(m: pd.Series, w: pd.Series, prefix: str) -> dict:
    valid = m.isin(MANAGEMENT_LABELS) & w.notna() & (w > 0)
    den = float(w[valid].sum())
    out = {}
    for code, label in MANAGEMENT_LABELS.items():
        num = float(w[valid & (m == code)].sum())
        out[f"{prefix}_{label}"] = num / den if den else np.nan
    return out


def analyze_wave(year: int, path: Path) -> dict:
    df = pd.read_csv(path, low_memory=False)

    mcol = col_ci(df, ["MNGMNT"])
    hcol = col_ci(df, ["HRSMNGMNT"])
    wcol = col_ci(df, WEIGHT_CANDIDATES)
    ucol = col_ci(df, UNIT_CANDIDATES, required=False)

    m = clean_nonnegative(df[mcol])
    h = clean_nonnegative(df[hcol])
    pw = clean_nonnegative(df[wcol]).where(lambda x: x > 0)

    row = {
        "year": year,
        "n_records": len(df),
        "property_weight_variable": wcol,
        "unit_variable": ucol or "",
    }
    row.update(shares_by_weight(m, pw, "property_share"))

    own = (m == 1)
    hv = own & h.notna() & pw.notna()
    row["owner_hours_mean_monthly_owner_managed_property_weighted"] = weighted_mean(h[hv], pw[hv])
    row["owner_hours_median_monthly_owner_managed_property_weighted"] = weighted_quantile(h[hv], pw[hv], .5)
    row["owner_hours_p25_monthly_owner_managed_property_weighted"] = weighted_quantile(h[hv], pw[hv], .25)
    row["owner_hours_p75_monthly_owner_managed_property_weighted"] = weighted_quantile(h[hv], pw[hv], .75)
    row["aggregate_owner_property_hours_monthly_weight_units"] = float((h[hv] * pw[hv]).sum())

    # Optional unit-weighted view.
    if ucol:
        units = clean_nonnegative(df[ucol]).where(lambda x: x > 0)
        uw = pw * units
        row.update(shares_by_weight(m, uw, "unit_share"))

        huv = own & h.notna() & uw.notna() & (uw > 0)
        row["owner_hours_mean_monthly_owner_managed_unit_weighted"] = weighted_mean(h[huv], uw[huv])

        # Aggregate owner hours divided by represented rental units.
        represented_units = float(uw[m.isin(MANAGEMENT_LABELS) & uw.notna()].sum())
        owner_property_hours = float((h[huv] * pw[huv]).sum())
        row["owner_management_hours_per_represented_unit_month"] = (
            owner_property_hours / represented_units if represented_units else np.nan
        )
    else:
        for label in MANAGEMENT_LABELS.values():
            row[f"unit_share_{label}"] = np.nan
        row["owner_hours_mean_monthly_owner_managed_unit_weighted"] = np.nan
        row["owner_management_hours_per_represented_unit_month"] = np.nan

    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wave", action="append", required=True, help="YEAR=/path/rhfs.csv")
    ap.add_argument("--outdir", default="effort_data/rhfs")
    args = ap.parse_args()

    rows = []
    for spec in args.wave:
        year, path = parse_wave_arg(spec)
        print(f"reading {year}: {path}")
        rows.append(analyze_wave(year, path))

    out = pd.DataFrame(rows).sort_values("year").set_index("year")

    property_cols = [f"property_share_{x}" for x in MANAGEMENT_LABELS.values()]
    err = (out[property_cols].sum(axis=1) - 1).abs()
    if float(err.max()) > 1e-9:
        raise AssertionError(f"property-share identity failure: {err.max()}")

    for y in out.index:
        unit_cols = [f"unit_share_{x}" for x in MANAGEMENT_LABELS.values()]
        if out.loc[y, unit_cols].notna().all():
            e = abs(float(out.loc[y, unit_cols].sum()) - 1)
            if e > 1e-9:
                raise AssertionError(f"{y}: unit-share identity failure {e}")

    od = Path(args.outdir)
    od.mkdir(parents=True, exist_ok=True)
    out.to_csv(od / "rhfs_management_summary.csv")

    print("\nProperty-weighted management shares (%):")
    print((100*out[property_cols]).round(2).to_string())

    unit_cols = [f"unit_share_{x}" for x in MANAGEMENT_LABELS.values()]
    if out[unit_cols].notna().any().any():
        print("\nUnit-weighted shares where a PUF unit count is available (%):")
        print((100*out[unit_cols]).round(2).to_string())

    print("\nOwner management hours:")
    print(out[[
        "owner_hours_mean_monthly_owner_managed_property_weighted",
        "owner_hours_median_monthly_owner_managed_property_weighted",
        "owner_management_hours_per_represented_unit_month",
    ]].round(3).to_string())


if __name__ == "__main__":
    main()
