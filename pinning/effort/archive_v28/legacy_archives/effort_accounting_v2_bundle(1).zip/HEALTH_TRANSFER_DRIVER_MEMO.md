# Health-transfer driver decomposition — v1

The transfer-composition graph tells us **which programs grew**. This module asks
why Medicare and Medicaid grew.

## Identity

For each program, nominal spending is decomposed multiplicatively as:

    spending
      = enrollment
        × general PCE price level
        × (health-services price / general PCE price)
        × residual real intensity / coverage / mix

The decomposition is exact by construction at every included anchor year.

The `health relative-price` term is important: it isolates the part of health-price
growth that exceeds (or falls short of) economy-wide consumer inflation.

The residual is intentionally NOT called "need." It contains:
- real quantity / utilization per enrollee,
- intensity and treatment mix,
- benefit-package / coverage changes,
- enrollee case mix,
- provider mix,
- administrative/scope differences,
- any mismatch from using broad PCE health-services prices instead of a
  Medicare- or Medicaid-specific provider price index.

## Medicare, 1970–2025

Nominal BEA Medicare social-benefit spending grows by a factor of
168.36.

Endpoint multiplicative factors:
- enrollment: 3.40×
- general PCE price level: 6.42×
- health relative price: 2.03×
- residual real intensity / coverage / mix: 3.79×

Shares of total *log* nominal spending growth:
- enrollment: 23.9%
- general inflation: 36.3%
- health relative-price inflation: 13.9%
- residual real intensity / coverage / mix: 26.0%

Thus demographics/enrollment alone do not explain Medicare's growth. A material
part is the relative price of health services, and another material part survives
even after health-price deflation.

## Medicaid, 1974–2024

MACPAC total Medicaid spending grows by about 86.27×,
while FYE enrollment grows 4.64×.

Shares of total log nominal spending growth:
- enrollment: 34.4%
- general inflation: 36.1%
- health relative-price inflation: 15.9%
- residual real intensity / coverage / mix: 13.6%

Again, enrollment expansion is only one of several large drivers.

## Interpretation for the model

This supports the user's warning against treating Medicare/Medicaid as an
exogenous demographic correction.

A transfer can rise because:
1. more people are eligible / enrolled;
2. the underlying service becomes expensive relative to ordinary consumption;
3. real service intensity / coverage rises.

Channel (2) is especially relevant to the paper. If necessities in locally supplied,
labor/scarcity-heavy sectors rise in relative price while reproducible goods become
cheap, public in-kind transfers can function as a socially accepted supplement to
cash wages.

This module does NOT establish that causal chain. It establishes that a sizable
relative-price component exists and should be tested rather than removed as
"demographics."

## Source-scope caveats

Medicare:
- spending is BEA Medicare social benefits from the existing transfer ledger;
- enrollment is total Medicare beneficiaries from the 2026 Medicare Trustees Report.

Medicaid:
- spending/enrollment are MACPAC total Medicaid spending and full-year-equivalent
  enrollment, including benefits and administration and excluding CHIP/VFC per
  MACPAC notes;
- fiscal-year concepts differ from the BEA calendar-year Medicaid benefit flow.

Price proxy:
- BEA PCE health-care-services chain-type price index is broad, not program-specific.
