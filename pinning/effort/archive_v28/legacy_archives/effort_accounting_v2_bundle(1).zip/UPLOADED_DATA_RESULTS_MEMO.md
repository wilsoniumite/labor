# Uploaded-data pass: BEA distribution + RHFS management microdata

## A. BEA joint DPI/PCE workbook

The supplied workbook covers 2000–2023, not just 2004–2023.

The previous local parser produced empty CSVs because it incorrectly searched for
aggregate totals under a `Ranking=None` row. In the actual workbook, the aggregate
`Total ($ Billions)` rows carry the same ranking label as the decile rows.

That parser bug is now fixed.

### Hard lower bound

For each equivalized-DPI decile d:

    forced intertemporal PCE_d
      = max(0, PCE_d - DPI_d)

This requires no assumption about whether wages, property income, or transfers are
"saved first."

Current-workbook aggregate hard floor:
- 2000: 11.46% of PCE
- 2020: 5.94% of PCE
- 2023: 10.62% of PCE

There is no simple secular rise. The floor is highly cyclical/policy-sensitive:
it falls sharply in 2020 when disposable income is boosted relative to consumption,
then rebounds in 2022–23.

The current workbook also revises the 2017 estimate upward relative to the older
rounded-data pilot: about 9.58%
rather than the earlier 8.08%.

2023 bottom-decile result:
at least 56.3%
of that decile's measured PCE exceeds its entire current DPI.

## B. RHFS: the direct landlord-management test

The four uploaded PUFs contain the exact variables we wanted:
- `MNGMNT`: owner/unpaid agent, directly-employed agent, management company, other;
- `HRSMNGMNT`: monthly owner-management hours when owner-managed;
- `NUMUNITS_R`: public-use unit-count recode;
- final property weights and replicate weights.

Census documentation defines `MNGMNT` as responsibility for day-to-day management
and `HRSMNGMNT` as owner hours spent on day-to-day management.

### Unit-weighted management shares, conditional on reported management

Owner/unpaid-agent management:
- 2015: 52.7%
- 2018: 42.9%
- 2021: 42.0%
- 2024: 35.5%

Management-company management:
- 2015: 24.2%
- 2024: 37.8%

This is the direct outsourcing trend we were hoping to measure.

### Property-weighted result with replicate-weight sampling error

Owner/unpaid-agent share:
- 2015: 78.5%
- 2024: 56.2%

Management-company share:
- 2015: 9.4%
- 2024: 22.7%

The 2015→2024 owner-management decline and management-company increase are large
relative to replicate-weight sampling error.

Formal unit-share MOEs are intentionally NOT reported here. `NUMUNITS_R` is a
public-use recode/topcoded quantity and the 2015 replicate-weight/unit-count
combination does not reproduce Census's published unit-total MOE. Unit shares are
therefore point estimates only.

### Owner hours among the properties that remain owner-managed

Weighted mean monthly owner-management hours:
- 2015: 9.8
- 2018: 9.7
- 2021: 14.7
- 2024: 11.6

This does NOT show a decline.

So the clean reading is:

    fewer rental properties/units are owner-managed,
    but owners who still self-manage do not appear to spend steadily fewer hours.

That is evidence of delegation/outsourcing, not yet evidence of automation within
the self-managed group.

## C. Ownership form changed too

Unit share held by individual investors:
- 2015: 48.5%
- 2024: 31.6%

Unit share held through LLP/LP/LLC:
- 2015: 35.2%
- 2024: 43.0%

So some management outsourcing occurs because ownership moves toward organizational
forms that are more likely to delegate management.

But not all of it.

## D. Shift-share decomposition: composition vs within-form outsourcing

Among units with both ownership form and management arrangement reported:

Owner-managed unit share falls by:
    -16.6 percentage points.

Approximate symmetric shift-share decomposition:
- ownership-form composition: -6.3 pp
- changing management behavior within ownership forms: -10.2 pp

Thus roughly two-thirds of the decline comes from **within-ownership-form changes**,
not merely the move from individuals into LLCs/other entities.

The management-company share rises by:
    12.6 pp

of which:
- ownership mix contributes about 4.3 pp;
- within-entity outsourcing contributes about 8.3 pp.

This is a much stronger result than the earlier NAICS delegation proxy.

## E. Interpretation

What the RHFS evidence supports:

    recipient/owner effort route -> delegation to professional management

What it does NOT yet establish:

    total system human effort -> falling because of automation

For that, the next step is to combine the RHFS management-company share with a
better property-management-sector labor/output denominator.

Still, the direct microdata result is exactly the first half of the distinction we
wanted:
owner effort has been progressively separated from rental ownership itself.
