# Medicare vs Social Security financing look-through — 2025

Source: 2026 Medicare and Social Security Trustees program-operations tables.

Medicare combines two very different financing architectures. Part A (HI) is mainly
payroll-tax financed, while Parts B and D (SMI) are financed mainly by federal
government contributions/general revenues plus beneficiary premiums.

Combining HI and SMI and excluding trust-fund interest, 2025 Medicare financing is
approximately:
- dedicated payroll tax: one third;
- federal + state general revenue: nearly one half;
- beneficiary premiums: around one seventh;
- taxes on Social Security benefits: a few percent.

Social Security OASI+DI is radically different: excluding trust-fund interest,
roughly 96% of current income comes from payroll taxes.

Therefore the final recursive graph should look through each large program
separately. "Age-linked transfer" is not a funding category.

Interest on trust funds belongs to an asset-income/intertemporal branch, and annual
program income need not equal annual expenditure because reserves can rise or fall.
