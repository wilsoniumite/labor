# Transfer and retirement driver pass — current conclusions

## 1. Health-transfer growth is not just enrollment/demographics

Exact multiplicative diagnostic:

    nominal spending
      = enrollment
        × general PCE inflation
        × health relative-price inflation
        × residual real intensity / coverage / mix

### Medicare, 1970–2025
Share of log nominal spending growth:
- enrollment: 23.9%
- general PCE inflation: 36.3%
- health relative-price inflation: 13.9%
- residual real intensity / coverage / mix: 26.0%

### Medicaid, 1974–2024
Share of log nominal spending growth:
- enrollment: 34.4%
- general PCE inflation: 36.1%
- health relative-price inflation: 15.9%
- residual real intensity / coverage / mix: 13.6%

Thus "more people need the program" is only one driver. A meaningful part is the
relative price of health services, and another part is real intensity/coverage/mix.

This makes the user's "socially acceptable non-wage transfer" interpretation
empirically plausible enough to test: publicly financed health consumption may be
absorbing an increasingly expensive essential-service bundle.

The price series is broad PCE health-services pricing, not a Medicare/Medicaid-specific
provider price index; the residual must therefore remain broad.

## 2. Aggregate retirement behavior does not show a simple shift toward earlier exit

SSA stock measure:
- retired-worker beneficiaries with early-retirement reduction:
  73.9% in 2010 -> 62.1% in 2024.

SSA new-award age distribution:
- weighted share of new awards before FRA:
  ~70.5% in 2010 -> ~52.5% in 2025.
- independent 2025 Table 6.B3 check: 53.2% of awards have an early-retirement reduction.

BLS age-65+ labor-force participation:
- 10.8% in 1985
- 12.9% in 2000
- 17.4% in 2010
- 20.2% in 2019
- 19.1% in 2025

Therefore aggregate data since 2010 look more like later claiming / more late-life
work, not a simple forced-early-retirement trend.

But that result is ambiguous between:
- better late-career opportunities / health / policy incentives, and
- erosion of the affordability of exit.

The latter is consistent with the paper's outside-option channel.

The discriminating test must condition on FRA/cohort rules, health, wealth/pensions,
occupation exposure, and local housing/health costs.

## 3. The old direct-wage fiscal trend is carried overwhelmingly through SS/health programs

Mechanical sensitivity using the exact old direct-wage identity:

    d = Wnet / (Wnet + T)

1960 -> 2025:
- original all-benefit direct-wage share: 92.0% -> 72.6%  (-19.4 pp)
- excluding Social Security only:          95.5% -> 79.7%  (-15.8 pp)
- excluding Medicare + Medicaid:           92.0% -> 83.1%  (-8.9 pp)
- excluding SS + Medicare + Medicaid:      95.5% -> 92.5%  (-3.0 pp)

So the vast majority of the original secular accounting decline is mediated through
these three programs.

This does NOT mean it is "explained away":
- Medicare/Medicaid themselves have major relative-price and real-intensity drivers;
- Social Security claiming/participation behavior can respond to labor demand and
  exit affordability.

It means the causal research question has become sharper:

    Why did these particular non-wage claims grow?

rather than:

    Did aggregate transfers grow?

## Next high-value tests

1. Health:
   replace broad PCE-health prices with Medicare/Medicaid-specific provider/payment
   price indices where possible; split real residual by service category.

2. Retirement:
   occupation/industry exposure × age-specific exit/claiming, with FRA/cohort controls;
   interact exposure with housing/health cost of exit.

3. Fiscal graph:
   build a hierarchical version where major transfers are not just colored "transfer"
   but decomposed into:
     enrollment/demography
     relative-price compensation
     real intensity/coverage
     cyclical/emergency support

4. Final consumption graph:
   public in-kind medical consumption should appear as consumption financed outside
   current wage income, then be recursively traced to its tax/debt source.
