"""
parse_bea_joint_distribution_fixed.py

Parses BEA's joint_dist_summary.xlsx after download.

Important correction:
aggregate `Total ($ Billions)` rows use the SAME ranking label as the decile rows;
do not search for Ranking == "None".
"""
from pathlib import Path
import numpy as np
import pandas as pd

XLSX = Path("joint_dist_summary.xlsx")
OUT = Path("bea_joint_distribution_fixed")
OUT.mkdir(exist_ok=True)

DECILES = ["0-10%","10-20%","20-30%","30-40%","40-50%",
           "50-60%","60-70%","70-80%","80-90%","90-100%"]

df = pd.read_excel(XLSX, sheet_name="shares of NIPA totals", engine="openpyxl")
sub = df[df["Series"].isin(
    ["Disposable Personal Income","Personal Consumption Expenditures"]
)]

shares = (
    sub[sub["Quantile or Summary Metric"].isin(DECILES)]
    .pivot_table(index=["Year","Quantile or Summary Metric"],
                 columns="Series", values="Value")
    .reset_index()
    .rename(columns={
        "Quantile or Summary Metric":"decile",
        "Disposable Personal Income":"dpi_share",
        "Personal Consumption Expenditures":"pce_share",
    })
)

totals = (
    sub[sub["Quantile or Summary Metric"]=="Total ($ Billions)"]
    .pivot_table(index="Year", columns="Series", values="Value")
    .reset_index()
    .rename(columns={
        "Disposable Personal Income":"dpi_total_b",
        "Personal Consumption Expenditures":"pce_total_b",
    })
)

p = shares.merge(totals, on="Year")
p["dpi_amount_b"] = p["dpi_share"]*p["dpi_total_b"]
p["pce_amount_b"] = p["pce_share"]*p["pce_total_b"]
p["forced_intertemporal_amount_b"] = np.maximum(
    0, p["pce_amount_b"]-p["dpi_amount_b"]
)
p["forced_intertemporal_share_group_pce"] = (
    p["forced_intertemporal_amount_b"]/p["pce_amount_b"]
)
p["forced_intertemporal_pp_total_pce"] = (
    p["forced_intertemporal_amount_b"]/p["pce_total_b"]
)

a = p.groupby("Year",as_index=False).agg(
    dpi_total_b=("dpi_total_b","first"),
    pce_total_b=("pce_total_b","first"),
    forced_intertemporal_amount_b=("forced_intertemporal_amount_b","sum"),
)
a["forced_intertemporal_share_pce"] = (
    a["forced_intertemporal_amount_b"]/a["pce_total_b"]
)

p.to_csv(OUT/"sharp_bound_decile.csv",index=False)
a.to_csv(OUT/"sharp_bound_aggregate.csv",index=False)
print(a.to_string(index=False))
