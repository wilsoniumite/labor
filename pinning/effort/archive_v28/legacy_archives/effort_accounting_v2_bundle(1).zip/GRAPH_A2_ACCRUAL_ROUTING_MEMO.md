# Graph A2 / AB — accrual-to-current-resource routing, 2024

This is the cleanest accounting correction so far.

## Step 1: separate origin from route

The legal/NIPA personal-income account is an accrual account. It mixes:
- wage disbursements;
- employer-paid insurance;
- employer pension contributions;
- imputed owner-occupied rent;
- imputed pension/insurance interest;
- pension-plan dividend accruals;
- cash transfers and in-kind medical benefits;
- mixed proprietors' income.

Therefore a single `wage linked` or `capital linked` axis cannot tell us whether a
claim is available for current PCE.

This file creates an **exclusive routing classification** of positive claims before
the personal/self-employed portion of government social-insurance contributions is
subtracted.

2024 gross positive claims:
    $25,962.7B

Routing shares:
- Current cash/disbursement: 57.8%
- Insurance / in-kind claim: 12.1%
- Deferred / imputed / accrued: 10.6%
- Timing unresolved: 19.6%

The `current cash/disbursement` bucket is deliberately narrow:
- wages and salaries;
- Social Security + UI;
- monetary interest;
- monetary rental receipts.

The insurance/in-kind bucket contains:
- employer private-insurance contributions;
- Medicare and Medicaid.

Deferred/accrued contains:
- employer pension/profit-sharing contributions;
- imputed interest;
- imputed owner-occupied rent;
- the measured pension-fund dividend floor.

Unresolved timing contains proprietors' income, most dividends, other benefits,
and small reconciliation items.

## Step 2: exact NIPA bridge

Employer government social-insurance contributions are part of gross employee
compensation but are also included in the NIPA subtraction for government social
insurance. To avoid showing the same route twice, this ledger nets the employer
piece out and subtracts only the remaining personal/self-employed contribution:

    total government social contributions       = $1,923.2B
    employer government social contributions    =   $866.4B
    residual personal/self-employed contribution= $1,056.8B

Then:

    gross positive claims                       $25,962.7
    - personal/self-employed social contributions 1,056.8
    = personal income                           24,905.9

    - personal current taxes                    2,988.2
    = disposable personal income                21,917.7

and:

    DPI
    - PCE                                       19,896.0
    - personal interest payments                551.0
    - personal transfer payments                277.4
    = personal saving                           1,193.2

This is an accounting identity, not an allocation of specific income dollars to PCE.

## Source-vintage residual

The detailed interest/rental timing splits come from a 2024 regional-methodology
source that differs slightly from the current 2025 NIPA Annual Update. Rather than
scale them silently, the ledger carries an explicit reconciliation residual of only:

    $5.516B

against roughly $26T of gross positive claims.

## Main conceptual result

There are now two separate questions:

### Economic origin
Did the claim ultimately come from:
- human effort,
- produced capital,
- scarcity,
- unresolved surplus?

### Timing/intermediation route
Is it:
- current cash/disbursement,
- insurance/in-kind,
- deferred/accrued,
- unresolved timing?

The final Graph D needs the first.
The final Graph C needs the second before it can map anything to current PCE.

This graph makes it impossible to confuse "labor-origin" with "current cash":
employer pension contributions and employer health-insurance contributions are
labor-origin compensation but do not arrive as ordinary wage cash.
