# Health-transfer decomposition rebased after program maturation

The earlier health-transfer decomposition used 1970 for Medicare and 1974 for
Medicaid. Those baselines are useful historically, but they are close to the
programs' early development and can make later changes in benefit scope, provider
participation, and service intensity look like a single giant "residual."

This robustness pass repeats the exact same multiplicative identity using:
- 1990 as the baseline;
- 2000 as the baseline.

For each period:

    nominal spending growth
      = enrollment growth
        × general PCE inflation
        × health-relative-price change
        × residual real intensity / coverage / mix.

The identity remains exact by construction.

## Why this matters

The research question is not whether Medicare and Medicaid matured after creation.
It is whether, **after they were already large established programs**, their costs
still rose because the underlying service bundle became relatively expensive or
more intensive.

The mature-period results show that those channels do not disappear.

The combined:

    health-relative-price factor
      × residual real-intensity/coverage/mix factor

remains greater than one in the 1990 and 2000 rebases.

So the earlier conclusion survives in weaker, more credible form:

> enrollment/demography and ordinary inflation explain a large part of mature-program
> spending growth, but not all of it; relative health-service prices and real
> intensity/coverage/mix continue to add materially.

This is the version that should be used in the paper-facing interpretation.

## Caution

The residual is still broad. It must not be renamed "need", "technology", or
"automation mitigation."

It contains utilization, treatment intensity, case mix, coverage, provider mix,
and any mismatch between the broad PCE health-services price index and the
program-specific price actually paid by Medicare/Medicaid.

The Medicare physician and inpatient-hospital modules are the more specific
provider-side follow-ups.
