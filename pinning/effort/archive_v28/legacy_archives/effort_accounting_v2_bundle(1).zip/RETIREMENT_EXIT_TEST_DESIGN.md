# Retirement/exit conditional test — pre-analysis design

## Why aggregate retirement data are insufficient

The aggregate results constructed earlier show:
- new Social Security awards before FRA declined strongly after 2010;
- age-65+ labor-force participation rose over the long run.

Those facts can mean either:
1. labor remains valuable and people choose to work longer; or
2. exit has become harder to afford, forcing continued employment.

The paper specifically predicts a supply-side outside-option mechanism, so the
interaction between labor-demand exposure and the COST OF EXIT is the discriminating
object.

## Preferred longitudinal design

Use matched Basic Monthly CPS / IPUMS CPS.

At baseline:
- worker age 55–69;
- currently employed;
- observe occupation before exit;
- attach precomputed occupation automation exposure.

At 12-month follow-up:
- employed vs no longer employed;
- retirement if source identifies it explicitly;
- earnings/hours among stayers.

This avoids the fatal reverse-timing problem of assigning a retired person the
occupation they no longer hold.

## Main equation

If higher `H` means housing / essential costs make exit more expensive:

    Exit_{i,t+12}
      = alpha
        + beta E_o
        + gamma H_{g,t}
        + delta (E_o × H_{g,t})
        + age/cohort controls
        + education/sex
        + state FE
        + year FE
        + routine control
        + error

Mechanism prediction:

    beta > 0
    delta < 0

Interpretation:
exposure can increase exit where exit remains affordable, but the same labor-demand
shock produces less observed exit where shelter/essential costs force workers to
remain attached.

## Complementary outcomes

Among workers who remain employed:

    Δ log wage
    Δ hours

If high exit costs are binding, exposed workers may show weak exit but larger
earnings/hours deterioration.

That pattern is more informative than retirement rates alone.

## Cost-of-exit variables

Preferred hierarchy:

1. local shelter cost relative to local low/mid wages;
2. HUD FMR / wage or ACS gross-rent burden;
3. local housing-price/rent index;
4. where available, health-insurance / medical-cost burden for ages 55–64.

Use costs measured before the follow-up transition.

## Automation exposure

The shipped registry contains the six existing occupation-exposure variants from
the companion analysis, standardized over `occ1990dd`.

Primary display candidates:
- `human_rating_beta_z`
- `dv_rating_beta_z`

The alpha/beta/gamma variants are a robustness family, not six independent tests.

## Important controls / threats

- FRA changes by birth cohort;
- health shocks;
- pension eligibility / wealth if using HRS rather than CPS;
- occupation-specific secular retirement patterns;
- routine-task content;
- local labor-market shocks;
- occupation coding changes;
- survivor selection among workers still employed at 55+.

With CPS, FRA/cohort can be generated from birth year; health/wealth controls are
limited.

With HRS, health and wealth are much richer but occupational exposure matching is
coarser and sample size smaller.

## Falsifying patterns

The outside-option mechanism is weakened if:
- exposure is unrelated to exit and wages/hours;
- exposure predicts more exit equally in high- and low-cost places;
- high exit costs increase exposed-worker exit rather than suppress it;
- the interaction vanishes with pretrend / occupation controls.

A particularly supportive pattern would be:
- low-cost places: exposure -> exit;
- high-cost places: exposure -> continued employment but falling wages/hours.

That directly distinguishes "no labor-demand effect" from "labor-demand effect with
an unaffordable outside option."
