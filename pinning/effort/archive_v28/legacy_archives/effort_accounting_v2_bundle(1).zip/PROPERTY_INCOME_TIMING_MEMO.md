# Property-income timing and financial intermediation audit

This module changes the interpretation of Graph A and is important enough to treat
as an accounting correction rather than a minor robustness exercise.

## 1. Personal dividend income is not cash dividend income

BEA's NIPA definition explicitly says:

- personal dividend income equals dividend income of persons from all sources;
- pension funds, some insurance reserves, and private trust funds are considered
  property of persons, so dividends received by those institutions are included in
  personal dividend income;
- dividends received by mutual funds generally pass through to their owners and are
  included in personal dividend income.

BEA's current state-personal-income methodology further says the national personal
dividend estimate is allocated for state estimation into:
1. imputed receipt of dividends from pension plans;
2. S-corporation dividend income;
3. other dividend income.

Therefore:

    personal dividend income
        !=
    cash dividend available to households for current PCE.

A meaningful part can accrue inside retirement arrangements.

The exact national 2024 pension-imputation fraction was not found in the public
national table used in this pass, so the timing split remains unresolved rather than
being guessed.

## 2. Personal interest income has an even clearer timing problem

BEA's 2024 County Personal Income methodology reports:

    total personal interest income = $1,921.240B
    imputed interest receipts      = $1,018.361B
    monetary interest receipts     =   $902.879B

So about 53% of personal interest income is imputed rather than monetary.

The methodology says imputed interest includes receipts from:
- finance and insurance companies;
- employee pension plans.

BEA's NIPA handbook explains the timing directly: investment income earned on
behalf of pension/insurance policyholders may not actually be distributed in the
current period, but is recorded as personal income on an accrual basis with an
offsetting reinvestment transaction.

That is exactly the timing layer Graph B needs.

## 3. Rental income also contains a very large imputed component

2024:

    total rental income of persons = $1,078.149B
    imputed rent                   =   $857.039B
    monetary rent                  =   $221.110B

So roughly 80% is imputed.

This agrees with the earlier owner-occupied-housing audit and reinforces that
"rental income of persons" is not landlord cash flow.

## 4. Household claim forms

Selected Federal Reserve Financial Accounts levels show three distinct household
financial claims:
- directly held corporate equities;
- mutual-fund shares;
- pension entitlements.

These are not additive measures of underlying equity exposure:
- mutual funds contain multiple asset classes;
- pension entitlements are claims on diversified pension portfolios and/or sponsors;
- corporate-equity values are market-sensitive.

They are shown to make the **intermediation/timing structure** visible, not to create
an equity-allocation identity.

Mutual-fund shares rose from a negligible share of direct-equity + mutual-fund
claims in 1960 to a substantial claim form by the 1990s–2010s.

Pension entitlements are themselves enormous household claims and create a large
gap between accrued property income and immediately spendable cash.

## Consequence for Graph A

Graph A must now have two variants:

### A-accrual
BEA personal-income concept:
    wages + supplements + proprietors + rent + interest + dividends + transfers

### A-cash/current-resource
Remove or separately route:
    imputed owner-occupied rent
    imputed pension/insurance interest
    pension-plan dividend accruals
    other noncash imputations

through Graph B as:
    accrued/reinvested financial claim
rather than current spendable resources.

The earlier legal-form Graph A remains valid as an accrual-income audit, but it
must not be used directly as the PCE-financing pool.

## Consequence for Graph C

This strengthens the need for the new sharp lower-bound method.

Instead of asking "which income category was saved?", the final bridge should:
1. identify cash/currently disposable receipts;
2. identify automatically accrued/reinvested property income;
3. use distributional DPI/PCE accounting to bound additional dissaving/borrowing;
4. trace pension/mutual-fund claims through financial intermediaries before assigning
   them to current consumption.

This should eliminate another major source of arbitrary financing-order assumptions.
