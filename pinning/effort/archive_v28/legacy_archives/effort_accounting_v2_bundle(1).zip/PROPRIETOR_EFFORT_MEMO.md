# Proprietors' income effort proxy — v1

## Why this object is legitimate

BEA itself describes nonfarm proprietors' income as income of unincorporated
businesses in which the owner's labor/entrepreneurship is not separately reported.
It is therefore a mixed-income object rather than clean "capital income."

This v1 proxy imputes the market value of owner labor using aggregate BLS CPS
class-of-worker data.

For each anchor year:

    employee_value_per_worker
      = aggregate employee wage bill or compensation bill
        / wage-and-salary employment

    imputed owner labor
      = unincorporated self-employed employment
        * employee_value_per_worker
        * (self-employed average hours / employee average hours)

    proprietor effort share
      = imputed owner labor / BEA nonfarm proprietors' income with IVA + CCAdj

Two benchmark definitions are retained:

1. `wage_only`: cash wage-and-salary disbursements.
2. `total_comp`: wages plus employer supplements/benefits.

The band between the two is a specification band, not a confidence interval.

## Result

| year | wage-only effort share | total-comp effort share |
|---|---:|---:|
| 2005 | 43.9% | 54.5% |
| 2010 | 38.4% | 47.7% |
| 2015 | 35.7% | 44.1% |
| 2020 | 33.9% | 41.6% |
| 2025 | 34.6% | 42.0% |

The first-pass estimate therefore falls from roughly 44–55% in 2005 to
roughly 35–42% in 2025.

This is materially below the old {50%, 65%, 80%} fixed grid by the end of the
sample, and it is time-varying in the direction we were looking for.

## What this does NOT establish

- It does not occupation-match self-employed owners to comparable employees.
- It does not industry-match compensation rates.
- It does not distinguish entrepreneurial skill rents from ordinary labor compensation.
- The non-effort residual is NOT automatically reproducible capital; it can include
  capital return, scarcity rent, entrepreneurial rent, monopoly rent, and measurement error.
- 2025 CPS annual averages exclude October because of the federal shutdown and are
  not strictly comparable with earlier annual averages.

The next refinement should use CPS/ASEC microdata or an industry-by-industry match
so the counterfactual wage reflects the actual composition of the self-employed.
