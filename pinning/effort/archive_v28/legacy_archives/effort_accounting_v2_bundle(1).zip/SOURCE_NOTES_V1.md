# Effort accounting v1 — source and interpretation notes

## Graph A: legal-form household resource audit

All annual series are BEA NIPA flows delivered through FRED, in billions of dollars.

- Private wages: A132RC1A027NBEA
- Government wages: B202RC1A027NBEA
- Supplements to wages and salaries: A038RC1A027NBEA
- Proprietors' income with IVA/CCAdj: A041RC1A027NBEA
- Rental income of persons with CCAdj: A048RC1A027NBEA
- Personal interest income: A064RC1A027NBEA
- Personal dividend income: B703RC1A027NBEA
- Government social benefits to persons: A063RC1A027NBEA

`employee_comp` = private wages + government wages + supplements.

`resource_total` is deliberately only the sum of the listed receipt-side flows. This is an audit denominator, not personal income, GDP, or PCE. Transfers are included as receipts even though they recycle primary income and will be looked through later.

No effort/capital/rent reclassification is performed in Graph A v1.

## Graph B: saving/intermediation bridge

- PCE: PCECA, BEA, billions of dollars.
- Personal saving: A071RC1A027NBEA, BEA, billions.
- Household loans; liability, transactions: BOGZ1FA154123005A, Federal Reserve Z.1, millions -> converted to billions.
- Household net lending (+)/borrowing (-), financial-account transactions: BOGZ1FU155000005A, Federal Reserve Z.1, millions -> converted to billions.
- Corporate business undistributed profits excluding IVA/CCAdj, transactions: BOGZ1FA096006401A, Federal Reserve Z.1, millions -> converted to billions.

Ratios to PCE are descriptive normalizations, not accounting identities. NIPA saving and Financial Accounts net lending differ in concepts/adjustments, so they are intentionally shown side by side rather than forced to reconcile.

## Equity effort proxies

- Index mutual funds + index ETFs as share of long-term fund assets, ICI:
  2010 19%, 2015 28%, 2020 40%, 2025 52%.
- Long-term fund total net assets, ICI:
  $9.9T, $14.9T, $24.8T, $36.6T at the same dates.
- Asset-weighted equity mutual-fund expense ratios, ICI:
  active: 1.06%, 0.96%, 0.71%, 0.64% in 2000/2010/2020/2025;
  index: 0.27%, 0.16%, 0.06%, 0.05%.

These are recipient/strategy and cost proxies. They are NOT yet mapped mechanically into an effort share of dividend income.

- BLS NAICS 5239 hours worked is a system-labor proxy.
  Total hours can rise even while effort per dollar managed falls, so an AUM-matched denominator is still needed.

## Credit effort proxy

BLS commercial-banking labor productivity (NAICS 522110), index 2017=100.
The plotted labor-requirement proxy is:
    100 * productivity_1987 / productivity_t

This is interpretable as an inverse output-per-hour index, not as a direct share of interest income attributable to labor.

## Current status

Built:
- receipt-side legal audit
- saving/borrowing/reinvestment bridge
- equity proxy panels
- credit proxy panel

Still intentionally unresolved:
- time-varying proprietor effort share
- rental owner-vs-management-company effort from RHFS
- AUM-matched asset-management hours
- decomposition of interest/dividends/rental into effort / reproducible capital / scarcity rent
- exhaustive 100% PCE financing identity
- recursive ultimate-origin graph
