# Medicare inpatient hospital cost/payment decomposition — v1

Source:
2026 Medicare Trustees Report, Table IV.A1, historical 2016–2025.

The Trustees decompose annual growth in HI inpatient hospital payments into:

1. provider input-price index;
2. update-factor adjustment applied to the prospective payment formula;
3. HI enrollment;
4. managed-care shift;
5. inpatient admission incidence;
6. case mix;
7. other/residual sources.

The annual components add to the reported total growth to rounding tolerance.

## Why this is better than a generic medical CPI

The input-price index is a weighted measure of the prices of inputs hospitals use
to deliver inpatient services.

The update-factor adjustment is an institutional/policy term that moves Medicare's
administered payment update away from the underlying input-cost index. It includes
the statutory economy-wide productivity adjustment and other legislated reductions.

So the pair tells us something conceptually important:

    provider input costs
        !=
    price increase Medicare chooses to reimburse.

## 2016–2025 pattern

Input-price inflation is positive in every year in the table.

The update-factor adjustment is negative in every year.

Therefore Medicare systematically restrains its prospective payment update relative
to measured hospital input-cost inflation.

At the same time, total inpatient spending can still rise because of:
- enrollment,
- case mix,
- admission incidence,
- managed-care migration,
- other residual/legislative factors.

This is the hospital analogue of the physician-services result already built.

## Pandemic warning

2020 is a large compositional shock:
- admission incidence collapses;
- "other" jumps;
- total inpatient payments fall despite positive input-price inflation.

Do not fit a simple secular regression through this period without showing the
component decomposition.

## Interpretation for the non-wage-transfer hypothesis

A public health entitlement can absorb a wedge between:
- the cost of producing an essential service,
- the administered price paid by the program,
- and the quantity/intensity of services beneficiaries receive.

This is more precise than saying "Medicare rose because health care is expensive."

It says the fiscal transfer is sitting on top of a production sector whose input
costs rise persistently, while policy actively suppresses reimbursement growth
relative to those costs and service composition/volume still changes.

That is consistent with a socialized-consumption interpretation, but it is not yet
evidence that the input-cost pressure is specifically caused by automation elsewhere.

## Technical caveat

The cumulative `provider_input_cost_proxy_index` and `administered_price_proxy_index`
are chained from the Trustees' annual component rates. They are display proxies,
not official CMS index levels. The annual component table is the authoritative
object.
