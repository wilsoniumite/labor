"""Download RHFS PUFs and compute owner-vs-company management trends.
Requirements: pip install requests pandas numpy matplotlib
Run: python fetch_and_run_rhfs.py
Send back: rhfs_effort_outputs.zip
"""
from pathlib import Path
from urllib.parse import urljoin
import re, shutil
import numpy as np, pandas as pd, requests
import matplotlib.pyplot as plt
OUT=Path('rhfs_effort_outputs'); RAW=OUT/'raw'
BASE={2015:['https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2015/'],2018:['https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2018/'],2021:['https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2021/'],2024:['https://www2.census.gov/programs-surveys/rhfs/Information/','https://www2.census.gov/programs-surveys/rhfs/data/public-use-files/2024/']}
LAB={1:'owner_or_unpaid_agent',2:'directly_employed_agent',3:'management_company',4:'other'}
def listing(base):
    r=requests.get(base,timeout=45,headers={'User-Agent':'Mozilla/5.0 effort-origin-research/1.0'}); r.raise_for_status(); return sorted(set(re.findall(r'href=["\']([^"\']+\.csv)["\']',r.text,flags=re.I)))
def choose(y):
    logs=[]
    for b in BASE[y]:
        try: xs=listing(b); logs.append(f'{y} {b} -> {xs}')
        except Exception as e: logs.append(f'{y} {b} ERROR {e}'); continue
        cand=[x for x in xs if 'puf' in x.lower() and str(y) in x and 'repwgt' not in x.lower()] or [x for x in xs if 'puf' in x.lower()]
        if cand:
            def key(n): return (int('_v' in n.lower()),tuple(map(int,re.findall(r'\d+',n))),n)
            return urljoin(b,sorted(cand,key=key)[-1]),logs
    raise RuntimeError('\n'.join(logs))
def ci(df,names,required=True):
    m={str(c).upper():c for c in df.columns}
    for n in names:
        if n.upper() in m:return m[n.upper()]
    if required: raise KeyError(f'None of {names} found')
def clean(s): return pd.to_numeric(s,errors='coerce').where(lambda x:x>=0)
def wmean(x,w):
    q=x.notna()&w.notna()&(w>0); return float(np.average(x[q],weights=w[q])) if q.any() else np.nan
def wq(x,w,p):
    q=x.notna()&w.notna()&(w>0)
    if not q.any(): return np.nan
    xx=x[q].to_numpy(float); ww=w[q].to_numpy(float); o=np.argsort(xx); xx=xx[o]; ww=ww[o]; return float(xx[np.searchsorted(np.cumsum(ww)/ww.sum(),p)])
def shares(m,w,prefix):
    q=m.isin(LAB)&w.notna()&(w>0); den=w[q].sum(); return {f'{prefix}_{lab}':float(w[q&(m==code)].sum()/den) for code,lab in LAB.items()}
def analyze(y,p):
    df=pd.read_csv(p,low_memory=False); mc=ci(df,['MNGMNT']); hc=ci(df,['HRSMNGMNT']); wc=ci(df,['WEIGHT','REPWGT0','FINALWGT','WGT']); uc=ci(df,['NUMUNITS_R','NUMUNITS'],False)
    m=clean(df[mc]); h=clean(df[hc]); w=clean(df[wc]).where(lambda x:x>0); row={'year':y,'n_records':len(df),'weight_variable':wc,'unit_variable':uc or ''}; row.update(shares(m,w,'property_share')); own=m==1; q=own&h.notna()&w.notna(); row['owner_hours_mean_monthly_owner_managed_property_weighted']=wmean(h[q],w[q]); row['owner_hours_median_monthly_owner_managed_property_weighted']=wq(h[q],w[q],.5)
    if uc:
        u=clean(df[uc]).where(lambda x:x>0); uw=w*u; row.update(shares(m,uw,'unit_share')); q=own&h.notna()&uw.notna()&(uw>0); row['owner_hours_mean_monthly_owner_managed_unit_weighted']=wmean(h[q],uw[q]); den=uw[m.isin(LAB)&uw.notna()].sum(); row['owner_management_hours_per_represented_unit_month']=float((h[q]*w[q]).sum()/den) if den else np.nan
    else:
        for lab in LAB.values(): row[f'unit_share_{lab}']=np.nan
        row['owner_hours_mean_monthly_owner_managed_unit_weighted']=np.nan; row['owner_management_hours_per_represented_unit_month']=np.nan
    return row

def main():
    RAW.mkdir(parents=True,exist_ok=True); rows=[]; logs=[]
    for y in BASE:
        try:
            url,l=choose(y); logs+=l; p=RAW/Path(url).name
            if not p.exists():
                r=requests.get(url,timeout=120,headers={'User-Agent':'Mozilla/5.0 effort-origin-research/1.0'}); r.raise_for_status(); p.write_bytes(r.content)
            row=analyze(y,p); row['source_url']=url; rows.append(row)
        except Exception as e: logs.append(f'{y} ANALYSIS ERROR {type(e).__name__}: {e}'); print(y,'ERROR',e)
    (OUT/'download_log.txt').write_text('\n'.join(logs))
    if not rows: raise RuntimeError('No wave succeeded')
    s=pd.DataFrame(rows).sort_values('year').set_index('year'); cols=[f'property_share_{x}' for x in LAB.values()]; assert ((s[cols].sum(axis=1)-1).abs()<1e-8).all(); s.to_csv(OUT/'rhfs_management_summary.csv')
    x=np.arange(len(s)); bot=np.zeros(len(s)); plt.figure(figsize=(9.5,5.6))
    for c in cols:
        v=100*s[c].to_numpy(); plt.bar(x,v,bottom=bot,label=c.replace('property_share_','')); bot+=v
    plt.xticks(x,s.index.astype(str)); plt.ylabel('Property-weighted share (%)'); plt.xlabel('RHFS wave'); plt.title('Who manages U.S. rental properties?'); plt.legend(fontsize=8); plt.tight_layout(); plt.savefig(OUT/'graph_rhfs_management_shares.png',dpi=180); plt.close()
    plt.figure(figsize=(9,5.3)); plt.plot(s.index,s.owner_hours_mean_monthly_owner_managed_property_weighted,marker='o',label='Weighted mean'); plt.plot(s.index,s.owner_hours_median_monthly_owner_managed_property_weighted,marker='o',label='Weighted median'); plt.ylabel('Reported owner management hours / month'); plt.xlabel('RHFS wave'); plt.title('Owner effort among owner-managed rental properties'); plt.legend(); plt.tight_layout(); plt.savefig(OUT/'graph_rhfs_owner_hours.png',dpi=180); plt.close()
    zp=shutil.make_archive('rhfs_effort_outputs','zip',root_dir=OUT); print((100*s[cols]).round(2).to_string()); print('\nCreated',zp)
if __name__=='__main__': main()
