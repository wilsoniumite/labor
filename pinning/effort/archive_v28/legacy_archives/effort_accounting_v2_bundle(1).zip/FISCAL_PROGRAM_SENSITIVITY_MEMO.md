# Fiscal direct-wage-share sensitivity to transfer-program composition

This is an accounting sensitivity exercise, NOT a causal adjustment.

The old four-way graph's direct-wage component satisfies:

    d_t = Wnet_t / (Wnet_t + T_t)

where `T_t` is total government social benefits.

Because `d_t` and `T_t` are observed in the existing project outputs, this module
recovers the median-spec implied direct labor resource flow exactly:

    Wnet_t = d_t * T_t / (1 - d_t)

It then asks what the same Wnet series would look like if selected transfer programs
were left out of the denominator.

This is deliberately mechanical:
- it does NOT say Social Security is purely demographic;
- it does NOT say Medicare/Medicaid are exogenous;
- it does NOT remove their taxes from Wnet;
- it does NOT create a true working-age household measure.

It only answers:
**which program families carry the accounting decline in the original direct-wage share?**

The variants are:
1. original all-benefit denominator
2. exclude Social Security
3. exclude Medicare + Medicaid
4. exclude Social Security + Medicare + Medicaid
5. additionally exclude UI, leaving residual 'other' benefits only

The last two are particularly useful for seeing whether the smooth secular trend
survives once the three largest structural programs are mechanically removed.

Interpretation should be paired with `HEALTH_TRANSFER_DRIVER_MEMO.md`:
health programs themselves contain enrollment, relative-price, and real-intensity
drivers, so removing them is a sensitivity calculation rather than "explaining
away" the underlying mechanism.
