"""
rhfs_management_module_v0.py

Rental-management effort module for the effort-origin accounting project.

Purpose
-------
Measure two distinct objects from Census/HUD Rental Housing Finance Survey PUFs:

1) Recipient/owner effort:
   - share of rental properties managed by owner/unpaid agent
   - mean/median monthly owner management hours among owner-managed properties
   - aggregate owner-management property-hours

2) Delegation:
   - share managed by directly-employed agents
   - share managed by outside management companies
   - share managed by other arrangements

IMPORTANT
---------
These are PROPERTY-weighted estimates from the public-use file. Do not label them
unit-weighted. Exact NUMUNITS is not reliably available on the current PUF for the
purpose required here. A unit-weighted series should come from Census Table Creator
or another explicitly documented size measure.

Expected core variables (recent waves):
    MNGMNT
      1 owner or unpaid agent
      2 management agent directly employed by owner
      3 management company
      4 other

    HRSMNGMNT
      monthly owner/owner-agent hours; universe MNGMNT == 1

    WEIGHT
      final property weight in recent PUFs

The script detects common alternate weight names and ignores negative missing codes.

Usage
-----
python rhfs_management_module_v0.py \
    --wave 2018=/path/rhfspuf2018_v2.csv \
    --wave 2021=/path/rhfspuf2021_v1_1.csv \
    --wave 2024=/path/rhfspuf2024.csv \
    --outdir effort_data/rhfs

Add 2015 once the current version's file is staged locally.

This file does not download data itself. Official PUF pages:
2024:
https://www.census.gov/programs-surveys/rhfs/data/puf/2024/microdata.html
2021:
https://www.census.gov/programs-surveys/rhfs/data/puf/2021/microdata.html
2018:
https://www.census.gov/programs-surveys/rhfs/data/puf/2018/microdata.html
2015:
https://www.census.gov/programs-surveys/rhfs/data/puf/2015/microdata.html
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


MANAGEMENT_LABELS = {
    1: "owner_or_unpaid_agent",
    2: "directly_employed_agent",
    3: "management_company",
    4: "other",
}

WEIGHT_CANDIDATES = [
    "WEIGHT", "weight", "REPWGT0", "repwgt0", "FINALWGT", "finalwgt", "WGT", "wgt"
]


def parse_wave_arg(text: str) -> tuple[int, Path]:
    year, path = text.split("=", 1)
    return int(year), Path(path)


def find_col(df: pd.DataFrame, wanted: str) -> str:
    by_upper = {str(c).upper(): c for c in df.columns}
    if wanted.upper() not in by_upper:
        raise KeyError(f"missing required variable {wanted}; first columns: {list(df.columns[:30])}")
    return by_upper[wanted.upper()]


def find_weight(df: pd.DataFrame) -> str:
    for c in WEIGHT_CANDIDATES:
        if c in df.columns:
            return c
    by_upper = {str(c).upper(): c for c in df.columns}
    for c in WEIGHT_CANDIDATES:
        if c.upper() in by_upper:
            return by_upper[c.upper()]
    raise KeyError(
        "Could not identify final property weight. "
        "Expected WEIGHT/REPWGT0 or a documented equivalent."
    )


def weighted_mean(x: pd.Series, w: pd.Series) -> float:
    ok = x.notna() & w.notna() & np.isfinite(x) & np.isfinite(w) & (w > 0)
    if not ok.any():
        return np.nan
    return float(np.average(x[ok].astype(float), weights=w[ok].astype(float)))


def weighted_quantile(x: pd.Series, w: pd.Series, q: float) -> float:
    ok = x.notna() & w.notna() & np.isfinite(x) & np.isfinite(w) & (w > 0)
    if not ok.any():
        return np.nan
    xx = x[ok].astype(float).to_numpy()
    ww = w[ok].astype(float).to_numpy()
    order = np.argsort(xx)
    xx, ww = xx[order], ww[order]
    cdf = np.cumsum(ww) / ww.sum()
    return float(xx[np.searchsorted(cdf, q, side="left")])


def clean_codes(s: pd.Series) -> pd.Series:
    # RHFS negative codes denote not reported / not applicable.
    x = pd.to_numeric(s, errors="coerce")
    return x.where(x >= 0)


def analyze_wave(year: int, path: Path) -> tuple[dict, pd.DataFrame]:
    df = pd.read_csv(path, low_memory=False)

    m_col = find_col(df, "MNGMNT")
    h_col = find_col(df, "HRSMNGMNT")
    w_col = find_weight(df)

    m = clean_codes(df[m_col])
    h = clean_codes(df[h_col])
    w = pd.to_numeric(df[w_col], errors="coerce").where(lambda s: s > 0)

    valid_m = m.isin(MANAGEMENT_LABELS) & w.notna()
    denom_w = float(w[valid_m].sum())

    row = {
        "year": year,
        "n_records": int(len(df)),
        "n_valid_management": int(valid_m.sum()),
        "weighted_properties_thousands_or_source_units": denom_w,
        "weight_variable": w_col,
    }

    long_rows = []
    for code, label in MANAGEMENT_LABELS.items():
        num_w = float(w[valid_m & (m == code)].sum())
        share = num_w / denom_w if denom_w > 0 else np.nan
        row[f"share_{label}"] = share
        long_rows.append({
            "year": year,
            "management_code": code,
            "management_type": label,
            "property_weight_share": share,
            "weighted_property_count_source_units": num_w,
        })

    own = (m == 1) & w.notna()
    valid_h = own & h.notna()
    row["owner_hours_mean_monthly_owner_managed"] = weighted_mean(h[valid_h], w[valid_h])
    row["owner_hours_median_monthly_owner_managed"] = weighted_quantile(
        h[valid_h], w[valid_h], 0.5
    )
    row["owner_hours_p25_monthly_owner_managed"] = weighted_quantile(
        h[valid_h], w[valid_h], 0.25
    )
    row["owner_hours_p75_monthly_owner_managed"] = weighted_quantile(
        h[valid_h], w[valid_h], 0.75
    )

    # Aggregate monthly owner-management property-hours in the PUF weight's units.
    # This is a valid weighted total of the reported property-level labor input.
    row["aggregate_owner_management_hours_monthly_weight_units"] = float(
        (h[valid_h] * w[valid_h]).sum()
    )

    row["owner_hours_reporting_share_of_owner_managed_weight"] = (
        float(w[valid_h].sum()) / float(w[own].sum())
        if float(w[own].sum()) > 0 else np.nan
    )

    return row, pd.DataFrame(long_rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--wave", action="append", required=True,
        help="YEAR=/path/to/rhfs.csv; repeat for each wave"
    )
    ap.add_argument("--outdir", default="effort_data/rhfs")
    args = ap.parse_args()

    waves = [parse_wave_arg(x) for x in args.wave]
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    summary_rows = []
    long = []
    for year, path in sorted(waves):
        print(f"reading {year}: {path}")
        row, lng = analyze_wave(year, path)
        summary_rows.append(row)
        long.append(lng)

    summary = pd.DataFrame(summary_rows).sort_values("year")
    long_df = pd.concat(long, ignore_index=True)

    # Identity check: management shares should sum to one in every wave.
    share_cols = [f"share_{v}" for v in MANAGEMENT_LABELS.values()]
    err = (summary[share_cols].sum(axis=1) - 1).abs()
    if float(err.max()) > 1e-10:
        raise AssertionError(f"management shares fail identity; max error {err.max()}")

    summary.to_csv(outdir / "rhfs_management_summary.csv", index=False)
    long_df.to_csv(outdir / "rhfs_management_long.csv", index=False)

    print("\nProperty-weighted management shares:")
    print(
        summary.set_index("year")[share_cols]
        .mul(100).round(2).to_string()
    )
    print("\nOwner monthly hours among owner-managed properties:")
    print(
        summary.set_index("year")[
            [
                "owner_hours_mean_monthly_owner_managed",
                "owner_hours_median_monthly_owner_managed",
                "owner_hours_p25_monthly_owner_managed",
                "owner_hours_p75_monthly_owner_managed",
            ]
        ].round(2).to_string()
    )
    print(
        "\nNOTE: these are property-weighted, not unit-weighted. "
        "Do not relabel them as effort per rental unit."
    )


if __name__ == "__main__":
    main()
