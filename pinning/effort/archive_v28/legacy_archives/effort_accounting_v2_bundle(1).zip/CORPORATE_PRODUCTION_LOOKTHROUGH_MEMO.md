# Corporate production look-through — v1

## Accounting identity

BEA corporate business accounts give:

    gross value added
      = consumption of fixed capital
      + net value added

and:

    net value added
      = employee compensation
      + taxes on production/imports less subsidies
      + net operating surplus.

Therefore:

    corporate GVA
      = current employee compensation
      + fixed-capital consumption
      + production-tax wedge
      + net operating surplus.

The shipped CSV verifies these identities to rounding tolerance.

## Interpretation discipline

### Employee compensation
Classified as current human effort at this layer.

### Consumption of fixed capital
This is NOT a profit return.
It is the current cost of replacing/depreciating produced fixed capital.
For the eventual recursive graph it belongs in a `produced-capital reproduction`
branch that must itself be looked through into the machine/construction supply chain.

### Taxes on production and imports less subsidies
A fiscal/institutional wedge. It should later be looked through to government uses
or treated separately, rather than called labor/capital/rent.

### Net operating surplus
Still unresolved economically. It includes corporate profits, net interest and
miscellaneous payments, and business current transfers.

BEA identity within NOS is reconstructed as:

    NOS
      = corporate profits with IVA + CCAdj
      + net interest & miscellaneous payments
      + business current transfers.

The last item is computed as the exact residual and matches the independently
published BEA business-transfer concept in current endpoints.

## Headline movement

Selected gross-value-added shares:

| year | employee comp | fixed-capital consumption | production taxes | net operating surplus |
|---|---:|---:|---:|---:|
| 1960 | 63.6% | 9.5% | 9.3% | 17.6% |
| 1970 | 65.0% | 10.1% | 9.3% | 15.6% |
| 1980 | 64.7% | 12.5% | 7.6% | 15.3% |
| 1990 | 64.5% | 13.1% | 8.2% | 14.2% |
| 2000 | 64.5% | 13.5% | 7.7% | 14.3% |
| 2010 | 57.1% | 15.4% | 8.3% | 19.2% |
| 2020 | 59.3% | 16.3% | 4.8% | 19.7% |
| 2025 | 55.3% | 15.3% | 7.9% | 21.5% |

This is useful for the dividend problem:
a household dividend is a distribution of a claim on the corporate surplus, but
the corporation's contemporaneous production simultaneously pays a much larger
employee-compensation bill and replaces produced capital.

Therefore passive ownership cannot be interpreted as passive *production*.

## Next step

The difficult remaining object is the economic decomposition of corporate profits/NOS:

    produced-capital return
    + site/resource/scarcity rent
    + monopoly/intangible rent
    + entrepreneurial/organizational rent
    + unresolved.

The next practical pass should use BEA industry accounts:
- compensation / value added by industry,
- gross operating surplus by industry,
- fixed assets by industry,
and then overlay measurable land/resource-heavy sectors rather than imposing one
aggregate profit coefficient.
