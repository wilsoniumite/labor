# Graph A1 — conservative effort-origin decomposition

This is the first economic-origin version of Graph A, but it is intentionally
incomplete.

At the five years for which the first proprietor-effort proxy has been built:

### Classified as effort
- all employee compensation;
- only the imputed labor component of proprietors' income.

### Kept unresolved
- the non-effort residual of proprietors' income;
- rental income;
- interest income;
- dividend income.

### Kept separate
- government social benefits / transfers.

The three displayed categories sum to exactly 100% of the same receipt-side
resource denominator used in Graph A.

The point is NOT that unresolved primary income is "capital."
It is explicitly the set of claims whose production/effort origin still has to be
looked through.

This gives us an honest stopping point:
the final graph can now improve by *shrinking the unresolved block* module by module.

The proprietor-specification band affects only the imputed proprietor component;
it is not a statistical confidence interval.
