# Transfer composition — aging/health alternative

This module directly tests the most obvious non-technology interpretation of the
old fiscal-financing graph.

Government social benefits are decomposed into:
- Social Security
- Medicare
- Medicaid
- unemployment insurance
- residual "other"

The components are BEA NIPA social-benefit flows. Medicare and Medicaid begin in
1966 and are zero before program inception in this accounting display.

## Main finding

The long-run transfer rise is overwhelmingly structural retirement/health spending,
not unemployment insurance.

By 2025, Social Security + Medicare + Medicaid account for most government social
benefits. Unemployment insurance is tiny outside crisis years, but produces the
large 2009–10 and especially 2020–21 spikes.

This means the earlier "smooth secular decline in direct wage financing plus crisis
shocks" has two separable pieces:

1. **smooth baseline:** heavily associated with the maturation/growth of Social
   Security, Medicare, and Medicaid;
2. **crisis excursions:** strongly associated with unemployment insurance and other
   emergency transfer programs.

That substantially strengthens the demographic/institutional alternative
explanation for the old Figure 7.

It does NOT prove technology is irrelevant:
- wage financing may still be pressured by labor-market changes,
- benefit systems may be the institutional response to those changes,
- health costs themselves have their own technology/scarcity dynamics.

But the transfer-side trend cannot be treated as an automation proxy without
conditioning on age/health-program growth.

## Next empirical implication

The cleaner technology-facing object should remove or separately display:
- old-age/retirement transfers,
- health-benefit transfers,
- cyclical unemployment/emergency transfers.

A working-age / non-health version of the consumption-financing graph would be a
much sharper test than the original aggregate line.
