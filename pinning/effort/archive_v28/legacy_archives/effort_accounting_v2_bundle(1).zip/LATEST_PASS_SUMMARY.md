# Latest pass — health socialization, Medicare provider costs, retirement test design

## Health financing increasingly occurs outside direct household payment

Using CMS National Health Expenditure historical Personal Health Care (PHC) payer
tables on one consistent denominator:

1970:
- out of pocket: 39.6%
- private health insurance: 22.2%
- Medicare + Medicaid: 19.5%
- all third-party financing: 60.4%

2014:
- out of pocket: 12.9%
- private health insurance: 33.9%
- Medicare + Medicaid: 40.0%
- all third-party financing: 87.1%

This directly supports studying health care as a major non-cash-wage consumption
channel. It does not imply all third-party finance is redistribution; employer and
household-funded private insurance must later be looked through.

Current CMS 2024 total-NHE statistics remain consistent with the broad phenomenon
(out-of-pocket is only about 11% of total NHE), but the denominator is not identical,
so the 2024 point is not spliced into the historical PHC series.

## Medicare physician services: provider costs vs administered payment vs quantity/mix

From Medicare Trustees historical decomposition, 2003–2012, cumulative display
indices (end-2002=100):

- physician input-cost MEI: ~121
- administered Medicare payment-update path: ~111
- allowed charges per enrollee: ~151

So Medicare held administered price updates below provider input-cost growth while
allowed charges per enrollee still rose much more, through volume/intensity/mix.

## Medicare inpatient hospitals: same mechanism, current through 2025

2026 Trustees Table IV.A1, historical 2016–2025, decomposes inpatient-payment growth
into:
- provider input prices
- payment update adjustment
- enrollment
- Medicare Advantage / managed-care shift
- admission incidence
- case mix
- other/residual

Provider input-price inflation is positive every year.
The payment-update adjustment is negative every year.

Illustrative chained display paths, 2015=100, by 2025:
- provider input-cost proxy: ~134
- administered-price proxy after update adjustments: ~126
- total HI inpatient payments: ~116

The annual component table, not the chained display proxy, is authoritative.

This is useful for the "socially acceptable non-wage transfer" interpretation:
public health purchasing power sits between rising production input costs,
administered reimbursement rules, and changing service volume/intensity.

## Retirement conditional test is now executable in design

Added:
- `retirement_test_occupation_exposure_registry.csv`
- `retirement_exit_test_v0.py`
- `RETIREMENT_EXIT_TEST_DESIGN.md`

Preferred longitudinal design:
- observe workers age 55–69 while employed
- attach occupation automation exposure before exit
- observe employment exit 12 months later
- interact exposure with pre-period local cost of exit

Main sign test, if higher H means exit is more expensive:

    Exit = alpha + beta Exposure + gamma H + delta Exposure*H + controls

Joint mechanism predicts:
    beta > 0
    delta < 0

A particularly discriminating pattern:
- low-cost places: exposure -> employment exit
- high-cost places: exposure -> workers stay, but earnings/hours deteriorate

That would distinguish an absent labor-demand shock from a labor-demand shock whose
outside option is unaffordable.

The existing exposure registry contains 319 occ1990dd occupations. The two main
beta exposure measures correlate about 0.90, so they should be treated as robustness
variants rather than independent tests.
