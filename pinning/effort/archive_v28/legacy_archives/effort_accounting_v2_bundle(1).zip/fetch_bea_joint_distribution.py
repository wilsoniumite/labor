"""Download BEA/BLS joint DPI-PCE workbook and compute hard intertemporal PCE bounds.

Requirements: pip install requests pandas openpyxl matplotlib
Run: python fetch_bea_joint_distribution.py
Send back: bea_joint_distribution_outputs.zip
"""
from pathlib import Path
import re, shutil
import numpy as np, pandas as pd, requests
import matplotlib.pyplot as plt
URL='https://www.bea.gov/sites/default/files/2026-05/joint_dist_summary.xlsx'
OUT=Path('bea_joint_distribution'); RAW=OUT/'raw'; XLSX=RAW/'joint_dist_summary.xlsx'
DECILES=['0-10%','10-20%','20-30%','30-40%','40-50%','50-60%','60-70%','70-80%','80-90%','90-100%']
def norm(x):
    s='' if pd.isna(x) else str(x); s=s.replace('–','-').replace('—','-').replace('−','-'); return re.sub(r'\s+',' ',s).strip()
def fcol(cols,*needles):
    for c in cols:
        if all(n.lower() in norm(c).lower() for n in needles): return c

def main():
    RAW.mkdir(parents=True,exist_ok=True)
    r=requests.get(URL,timeout=90,headers={'User-Agent':'Mozilla/5.0 effort-origin-research/1.0'}); r.raise_for_status()
    if not r.content.startswith(b'PK'): raise RuntimeError('Payload is not XLSX: '+r.text[:300])
    XLSX.write_bytes(r.content)
    xl=pd.ExcelFile(XLSX,engine='openpyxl'); (OUT/'workbook_schema.txt').write_text('\n'.join(xl.sheet_names))
    sheet=next(s for s in xl.sheet_names if 'shares of nipa totals' in s.lower())
    d=pd.read_excel(XLSX,sheet_name=sheet,engine='openpyxl'); d.columns=[norm(c) for c in d.columns]
    yc=fcol(d.columns,'year'); rc=fcol(d.columns,'ranking'); sc=fcol(d.columns,'series'); qc=fcol(d.columns,'quantile') or fcol(d.columns,'summary'); vc=fcol(d.columns,'value')
    if any(x is None for x in [yc,rc,sc,qc,vc]): raise RuntimeError(f'Unexpected columns: {list(d.columns)}')
    for c in [rc,sc,qc]: d[c]=d[c].map(norm)
    rank=d[rc].str.contains('equivalized disposable personal income',case=False,na=False)
    dpi=d[sc].str.contains('Disposable Personal Income',case=False,na=False)
    pce=d[sc].str.contains('Personal Consumption Expenditures',case=False,na=False)
    def dec(mask,name):
        x=d[rank&mask].copy(); x['decile']=x[qc].map(norm); x=x[x.decile.isin(DECILES)]; x['year']=pd.to_numeric(x[yc],errors='coerce'); x[name]=pd.to_numeric(x[vc],errors='coerce'); return x[['year','decile',name]].dropna().assign(year=lambda z:z.year.astype(int))
    panel=dec(dpi,'dpi_share').merge(dec(pce,'pce_share'),on=['year','decile'],validate='one_to_one')
    none=d[rc].str.fullmatch('None',case=False,na=False)
    def total(mask,name):
        x=d[none&mask].copy(); x['_q']=x[qc].map(norm); q=x._q.str.contains('aggregate|total',case=False,regex=True,na=False); x=x[q] if q.any() else x; x['year']=pd.to_numeric(x[yc],errors='coerce'); x[name]=pd.to_numeric(x[vc],errors='coerce'); x=x[['year',name]].dropna(); x['year']=x.year.astype(int); return x.sort_values(['year',name]).groupby('year',as_index=False).tail(1)
    totals=total(dpi,'dpi_total').merge(total(pce,'pce_total'),on='year',validate='one_to_one')
    panel=panel.merge(totals,on='year',validate='many_to_one').sort_values(['year','decile'])
    panel['dpi_amount']=panel.dpi_share*panel.dpi_total; panel['pce_amount']=panel.pce_share*panel.pce_total
    panel['forced_intertemporal_amount']=np.maximum(0,panel.pce_amount-panel.dpi_amount)
    panel['forced_intertemporal_share_group_pce']=panel.forced_intertemporal_amount/panel.pce_amount
    panel['forced_intertemporal_pp_total_pce']=panel.forced_intertemporal_amount/panel.pce_total
    panel.to_csv(OUT/'sharp_intertemporal_bound_decile_2004_2023.csv',index=False)
    panel[['year','decile','dpi_share','pce_share']].to_csv(OUT/'dpi_pce_decile_shares_2004_2023.csv',index=False)
    agg=panel.groupby('year',as_index=False).agg(dpi_total=('dpi_total','first'),pce_total=('pce_total','first'),forced_intertemporal_amount=('forced_intertemporal_amount','sum'))
    agg['forced_intertemporal_share_pce']=agg.forced_intertemporal_amount/agg.pce_total; agg['could_be_current_dpi_financed_share_pce']=1-agg.forced_intertemporal_share_pce
    agg.to_csv(OUT/'sharp_intertemporal_bound_aggregate_2004_2023.csv',index=False)
    plt.figure(figsize=(9.5,5.4)); plt.plot(agg.year,100*agg.forced_intertemporal_share_pce,marker='o'); plt.ylabel('Hard lower bound (% of total PCE)'); plt.xlabel('Year'); plt.title('PCE necessarily exceeding current DPI of the consuming income decile'); plt.tight_layout(); plt.savefig(OUT/'graph_sharp_intertemporal_bound_aggregate.png',dpi=180); plt.close()
    wide=panel.pivot(index='year',columns='decile',values='forced_intertemporal_share_group_pce'); plt.figure(figsize=(10.5,6));
    for c in DECILES:
        if c in wide: plt.plot(wide.index,100*wide[c],marker='o',label=c)
    plt.ylabel('Hard lower bound (% of that decile\'s PCE)'); plt.xlabel('Year'); plt.title('Distributional lower bound on intertemporal PCE financing'); plt.legend(ncol=2,fontsize=8); plt.tight_layout(); plt.savefig(OUT/'graph_sharp_intertemporal_bound_by_decile.png',dpi=180); plt.close()
    zp=shutil.make_archive('bea_joint_distribution_outputs','zip',root_dir=OUT); print(agg[['year','forced_intertemporal_share_pce']].assign(forced_intertemporal_share_pce=lambda x:100*x.forced_intertemporal_share_pce).round(2).to_string(index=False)); print('\nCreated',zp)
if __name__=='__main__': main()
