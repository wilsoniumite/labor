# Public medical consumption: first recursive Graph D look-through

## 1. Direct consumption channel

BEA Medicare + Medicaid social-benefit flows are approximately 10.26% of total PCE in 2024.
This is a directly identified in-kind/non-wage consumption route; no saving-order assumption is required to put it on the PCE denominator.

## 2. One-layer funding look-through

For Medicare, use the 2026 Trustees Report's 2024 shares of non-interest program income.
For Medicaid, use MACPAC FY2024 federal/state benefit-spending shares.

Applied mechanically to the 2024 benefit-flow scale, the combined public medical channel is approximately funded through:

- Federal general revenue: 53.8% of the public-medical channel = 5.52 percentage points of total PCE.
- Dedicated payroll taxes: 19.1% = 1.96 pp of total PCE.
- State/local revenue: 17.1% = 1.75 pp of total PCE.
- Beneficiary premiums: 8.0% = 0.82 pp of total PCE.
- Tax on Social Security benefits: 1.9% = 0.19 pp of total PCE.
- Other program revenue: 0.1% = 0.01 pp of total PCE.

This is the first useful recursive branch of Graph D:

    PCE
      -> public medical consumption
         -> payroll tax
         -> federal general revenue
         -> state/local revenue
         -> beneficiary premium
         -> tax on prior transfer income

## 3. Why this is only an approximation

Program income does not have to equal program expenditure in the same year because trust-fund reserves can change. Medicare's Trustees funding shares are calendar-year non-interest income; Medicaid's federal/state split is fiscal-year benefit spending. The allocation therefore describes the current funding architecture surrounding the benefit flow rather than exact dollar incidence for every 2024 service.

The next recursive layer is the hard one: general revenue itself must be decomposed across labor-linked taxes, ownership/scarcity taxes, consumption taxes, and government borrowing. The old aggregate tax-linkage grid can be reused provisionally here, but only after program-specific funding routes have been separated.

## 4. Historical funding architecture

The 2026 Medicare Trustees historical table shows a large structural change in non-interest financing:

- payroll-tax share: 61.8% in 1970 -> 33.3% in 2025;
- federal government-contribution share: 24.6% -> 47.3%;
- beneficiary-premium share: 13.7% -> 14.2%.

Social Security is very different: selected 2026 OASDI Trustees data imply payroll taxes remain roughly 96% of current non-interest income in 2025 and were about 99% in 1970.

So the historical shift toward non-wage public consumption claims is not only a rise in benefit size. Medicare itself has moved away from a predominantly dedicated-payroll-tax funding architecture toward one in which general revenues are the largest source.
