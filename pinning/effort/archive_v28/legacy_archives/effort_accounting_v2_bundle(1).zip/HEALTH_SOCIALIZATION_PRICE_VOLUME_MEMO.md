# Health financing and Medicare price/volume refinement

## A. Health consumption financing shifted away from direct payment

CMS NHEA Table 6 selected-year Personal Health Care (PHC) data are used with one
consistent denominator.

1970:
- out of pocket: 39.6%
- private health insurance: 22.2%
- Medicare + Medicaid: 19.5%
- all third-party financing: 60.4%

2014:
- out of pocket: 12.9%
- private health insurance: 33.9%
- Medicare + Medicaid: 40.0%
- all third-party financing: 87.1%

This is much broader than "the welfare state grew." The U.S. health system as a whole
moved from direct household purchase toward claims mediated through insurance and
public programs.

That makes health care a particularly plausible place to look for non-wage
consumption support:
the household increasingly consumes the service without paying its full current
price out of its current cash wage at the point of use.

Do NOT interpret all third-party finance as redistribution:
private insurance includes compensation-linked premiums, household premiums, and
risk pooling. The final consumption-origin graph must look through those funding
sources separately.

## B. Medicare-specific provider price versus spending

The broad PCE health price index used in the earlier decomposition is not a Medicare
payment index.

For physician services, the 2013 Medicare Trustees Report Table IV.B1 supplies an
especially useful historical decomposition of allowed charges per FFS enrollee.

It distinguishes:
- MEI: physician input-cost / wage inflation index;
- modified physician payment update: administered Medicare price changes including
  legislative impacts;
- residual factors: volume/intensity, service mix/coding and measurement residuals;
- total allowed-charge growth per enrollee.

From 2003–2012, cumulative indices (end-2002 = 100) are approximately:
- physician input costs (MEI): see CSV;
- administered payment updates: see CSV;
- allowed charges per enrollee: see CSV.

The important phenomenon is that Medicare can restrain the administered unit-price
path while spending per enrollee still rises through volume/intensity/mix.

So "health spending rose because prices rose" is too simple, but so is
"health spending rose because utilization rose."
The program sits on top of both provider input costs and endogenous service intensity.

## Interpretation for the project

A public health transfer can be doing several jobs simultaneously:

1. insure an idiosyncratic medical risk;
2. spread the cost of an essential service whose input costs rise;
3. absorb growth in service intensity / technology / treatment mix;
4. substitute public or insured purchasing power for direct household cash payment.

This is precisely why the final consumption graph should treat Medicare/Medicaid
as a consumption-financing route first, then separately decompose the economic
drivers of the underlying service cost.

## Data caveats

- PHC selected-year data stop at 2014 in the historical table used here. Current 2024
  NHE data continue to show out-of-pocket payment as a small share of total NHE, but
  the denominator is not identical, so it is not spliced into this series.
- Physician Table IV.B1 is Medicare FFS carrier/physician-service specific and does
  not represent hospital, drug, skilled nursing, home-health, or managed-care pricing.
- "Residual factors" are not a pure physical quantity index.
