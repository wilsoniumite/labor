# Personal dividend income — measured pension-intermediation floor, 2024

BEA's NIPA treatment says pension plans are pass-through institutions that hold
assets on behalf of households. Dividend income earned inside those plans is recorded
as personal dividend income even though it is not necessarily distributed to the
household as spendable cash in that year.

The Federal Reserve/BEA Integrated Macroeconomic Accounts report:

    pension funds; dividends received, 2024
        = $203.975B

The current NIPA summary reports:

    personal dividend income, 2024
        = about $2,218.7B

Their ratio is:

    9.19%

## Interpretation

This is a useful **measured floor** on dividend-income intermediation.

At least roughly 9% of the personal-dividend-income scale is visibly passing through
pension funds in 2024.

Do not interpret the remaining ~91% as current cash:
- mutual-fund dividends are generally passed through in the NIPAs;
- direct/indirect financial holdings remain mixed;
- S-corporation and other dividend forms have different timing;
- nonprofits are included in the broader `persons` concept;
- NIPA and IMA sector/accounting concepts are closely related but not identical
  enough to claim a literal subtraction identity without reconciliation.

So:

    pension dividends / personal dividend income

is a diagnostic ratio, not an exact partition of NIPA personal dividend income.

## Public retirement plans

BEA separately reports about:

    $46.333B

of dividends received by publicly administered government employee retirement plans.

That figure provides a useful subset/context check but should not be added to the
aggregate pension-fund IMA amount; doing so would risk double counting.

## Why this matters

The original fiscal/effort graph treated personal dividend income as a current
ownership resource.

The corrected architecture is:

    underlying corporate production
      -> corporate dividend
      -> direct holding / mutual fund / pension fund / other intermediary
      -> accrued household property income
      -> reinvested/deferred or distributed
      -> current PCE financing only if actually made available for current spending.

The production-origin and timing/intermediation problems are therefore separable.

This is exactly what Graph B is supposed to resolve.
