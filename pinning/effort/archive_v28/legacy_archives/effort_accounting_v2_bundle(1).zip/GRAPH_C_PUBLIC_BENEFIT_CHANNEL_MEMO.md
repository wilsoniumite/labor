# Graph C4/C5 — directly identified public-benefit consumption channels

This is the first time-series piece that can sit directly on the final
`100% of PCE` canvas without using the old wages-first/capital-first allocation.

## Construction

Denominator:
    total personal consumption expenditures (PCE).

Numerators:
    Medicare social-benefit flow
    Medicaid social-benefit flow
    Social Security
    unemployment insurance
    total government social benefits.

The key series is:

    (Medicare + Medicaid) / PCE.

Medicare and Medicaid are especially useful because they are predominantly
benefits/purchases on behalf of persons for medical consumption. They therefore
represent a directly observed route by which current consumption is financed
outside an ordinary cash wage.

## Result

Public medical benefit flow as a share of all PCE:

    1970: 1.97%
    2024: 10.26%
    2025: 10.65%

This is an enormous structural change in the financing route of consumption.

It is NOT yet an "ultimate origin" statistic.

The benefits themselves are financed through:
- payroll/social-insurance contributions,
- personal/corporate/production taxes,
- government borrowing,
- premiums and other receipts.

Those sources must be recursively looked through in Graph D.

## Why this is stronger than the old transfer share

The old fiscal graph normalized transfers by:
    Wnet + transfers.

This graph normalizes the public medical claim by:
    ALL PCE.

So it answers a much cleaner consumption question:

> How large is the public medical-benefit flow relative to the entire amount of
> personal consumption occurring in the economy?

No assumption is made about which private income source was saved.

## Important conceptual point

A growing Medicare/Medicaid/PCE share can reflect multiple mechanisms already
documented in the project:
- enrollment/population;
- health service relative prices;
- real service intensity/coverage/mix;
- deliberate socialization/insurance of an essential service.

Therefore this series is a financing-route fact, not an automation causal estimate.

## Next step

The final 100% PCE graph should contain a hierarchy:

    PCE
      ├── public in-kind medical route (directly identified)
      │     └── tax / contribution / debt look-through
      ├── other publicly financed consumption claims
      ├── current private cash-resource route
      ├── private insurance/in-kind route
      ├── intertemporal/dissaving lower bound
      └── unresolved financing

The categories must be constructed to avoid overlap. Medicare/Medicaid should not
also appear as generic transfer-financed PCE once they occupy the explicit medical
route.
