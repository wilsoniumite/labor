# Equity system-effort module — first result

The recipient-effort and system-effort indicators now point in the same direction.

Observed anchors:

| year | index share of long-term fund assets | NAICS 5239 hours (m) | long-term fund assets ($T) | hours/$ proxy, 2010=100 |
|---|---:|---:|---:|---:|
| 2010 | 19% | 882.5 | 9.9 | 100.0 |
| 2015 | 28% | 1006.5 | 14.9 | 75.8 |
| 2020 | 40% | 1112.7 | 24.8 | 50.3 |
| 2025 | 52% | 1286.9 | 36.6 | 39.4 |

Interpretation:

- Index/passive share rises sharply: recipient discretionary security-selection effort is falling.
- Total NAICS 5239 human hours rise in absolute terms.
- But the relevant asset pool grows much faster than human hours.
- The sparse ratio therefore shows a large fall in human investment-intermediation hours per dollar of long-term fund assets.

This is stronger than the passive-share result alone because it addresses the outsourcing objection:
the financial-management sector still uses more human hours in total, but far fewer human hours relative to the amount of assets being intermediated.

Caveat:
the numerator and denominator do not have identical scopes. NAICS 5239 covers Other Financial Investment Activities, while the denominator is ICI long-term mutual funds + ETFs. This should be treated as a directional system-effort proxy, not an exact productivity measure. A later pass should construct an AUM denominator closer to the NAICS industry boundary.
