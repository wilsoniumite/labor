# Corporate payout / retention bridge

This graph belongs between income generation and household consumption.

For domestic corporate business, BEA publishes:
- corporate profits after tax with IVA and CCAdj;
- net dividends.

The implied undistributed/retained component is:

    retained_t = profits_after_tax_t - net_dividends_t

and therefore exactly:

    profits_after_tax = net_dividends + retained profits.

This is a much cleaner treatment than imagining that all corporate earnings appear
as current household dividend income.

## Why this matters for the effort-origin project

A dollar of corporate profit can take two paths:

    current production
      -> dividend / other distribution
      -> potentially current household resources

or

    current production
      -> retained profit
      -> corporate saving / reinvestment
      -> future productive assets / future claims

So the household-income graph and the production-origin graph must not be equated.

## Critical dividend distinction

There are also TWO kinds of "effort around dividends":

1. `claim-selection/intermediation effort`
   - researching securities
   - active portfolio management
   - fund administration
   - captured partially by passive-index shares, expense ratios, and asset-management hours

2. `underlying cash-flow production effort`
   - labor inside the corporations producing the profits
   - plus produced capital and scarcity rents inside those firms

The index-fund proxy measures (1), not (2).

Therefore it must NEVER be used to say:
    "52% passive funds => 52% of dividends are non-effort income."

The eventual recursive graph must first look through the corporation's production
accounts. Claim-selection skill can only add/subtract an incremental alpha/management
component; it cannot be credited with producing the corporation's full dividend.
