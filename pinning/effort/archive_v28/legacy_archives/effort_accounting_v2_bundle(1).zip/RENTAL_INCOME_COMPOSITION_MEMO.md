# Rental income of persons — composition audit

This audit changes how the RHFS management proxy should be used.

BEA defines `rental income of persons` as NET income from current production.
It includes:
- tenant-occupied housing rented by persons;
- imputed net rental income on owner-occupied housing;
- some other rental/royalty income.

It excludes tenant-occupied property owned through corporations (corporate profits)
and partnerships / sole proprietorships whose rental activity belongs in proprietors'
income.

BEA calculates tenant rental income as housing-service output less expenses such as
depreciation, maintenance/repairs, property taxes, and mortgage interest. Owner-occupied
housing is treated as if the homeowner operates a rental business renting the dwelling
to herself.

## Crucial empirical fact

In the modern data, `rental income of persons` is overwhelmingly an owner-occupied
housing imputation.

2024:
- total rental income of persons: about $1.078T
- owner-occupied nonfarm housing: about $842B (~78%)
- tenant-occupied housing: about $163B (~15%)
- remaining other/residual: ~7%

Therefore:

**RHFS landlord-management hours must NOT be applied to the full A048 rental-income
series.**

The RHFS proxy is relevant to the tenant-rental production channel, and even there
the legal-form mapping spans several NIPA categories depending on whether the property
is held personally, through a sole proprietorship/partnership, or a corporation.

This is a major reason to keep:
    legal income form
separate from:
    production/effort origin.

## Historical oddity that is real, not a coding error

BEA's imputed net rental income on owner-occupied housing becomes negative in parts of
the 1980s. Because the NIPA imputation subtracts mortgage interest, property taxes,
depreciation and other expenses from imputed housing-service rent, high financing
costs can drive the net operating-income measure below zero.

So the rental-income series is not simply "landlord cash rent" and should never be
used as a direct land-rent series.

## Next decomposition

For owner-occupied housing, the eventual economic split should be built from the
housing production account:

    gross imputed housing services
      - maintenance / management labor and intermediate inputs
      - depreciation / structure services
      - taxes / interest financing flows
      = net operating surplus

and then separate the surviving return into:
    structure return
    site / scarcity rent
    unresolved.

For tenant housing, RHFS helps estimate owner-management labor while BLS 5311/5313
helps track delegated system labor.
