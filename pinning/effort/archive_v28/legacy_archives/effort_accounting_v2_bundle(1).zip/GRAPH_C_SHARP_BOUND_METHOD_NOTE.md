# Graph C — sharp accounting lower bound, 2017

This replaces the earlier proportional-within-outlays pilot with a stricter result
that needs **no assumption about which current income source is saved first** and
no assumption about whether dissaving finances PCE versus another outlay.

For income decile d, observe:

    DPI_d = decile share of national DPI × national DPI
    PCE_d = decile share of national PCE × national PCE

Then:

    minimum intertemporal PCE_d = max(0, PCE_d - DPI_d)

Why this is a hard lower bound:

Even under the extreme assumption that the household group allocates every dollar
of current DPI to PCE before paying any personal interest or current transfer
payments, PCE above DPI cannot be current-income financed.

The remaining PCE is labelled:

    "could be current-DPI financed"

NOT:

    "is current-DPI financed."

That distinction is essential.

## Source

BLS Working Paper 575, 2017:
- Table A2a: DPI shares by equivalized-DPI decile.
- Table A4: PCE shares by equivalized-DPI decile.
- published aggregate DPI = $14,614B
- published aggregate PCE = $13,291B

Published decile shares are rounded to 0.1 percentage point, so aggregate
reconciliation is approximate at the small rounding level.

## Result

At least **8.08% of total 2017 PCE** cannot be financed by
the current DPI of the income decile doing the consuming.

This minimum is concentrated in the lower part of the income distribution.

The bound is deliberately conservative:
- personal interest payments and current transfer payments also use current DPI,
  so the true current-DPI shortfall for PCE can be larger;
- the calculation does not identify whether the intertemporal source is debt,
  deposit drawdown, asset sale, family transfers, or measurement residual.

## Why this is better than the old financing-order grid

The old model asked whether the economy "saves wages first" or "capital first."

This bound asks something observable:

    Is the entire current DPI of this income group even large enough to finance
    its measured PCE?

Where the answer is no, the intertemporal component is forced by accounting rather
than by a behavioral allocation rule.

## Next step

For the latest 2004–2023 joint-distribution workbook, apply the same sharp bound in
every year. The official workbook URL has been identified, but binary download is
blocked in the current runtime. The parser should retain both:
1. this assumption-free lower bound;
2. the narrower proportional-within-outlays central bridge as an optional estimate.

The final graph should show the lower bound as a hard floor, not a confidence band.
