"""
retirement_exit_test_v0.py

Longitudinal test of the paper's outside-option mechanism.

Core question
-------------
Conditional on age/cohort and baseline labor-market status, does occupation-level
automation exposure predict exit from employment? And is that response attenuated
where housing / essential-service costs make exit expensive?

The design intentionally separates two hypotheses:

H1. Demand/exit channel:
    automation exposure -> higher probability of employment exit.

H2. Outside-option constraint:
    high cost of exit weakens that employment-exit response because workers cannot
    afford to leave even when labor demand deteriorates.

If `exit_cost` is coded so higher = more expensive to stop working:

    Exit_{i,t+1}
       = alpha
         + beta * Exposure_o
         + gamma * ExitCost_g
         + delta * Exposure_o * ExitCost_g
         + controls + FE + eps

Predictions under the joint mechanism:
    beta > 0
    delta < 0

A complementary outcome among workers who remain employed is earnings/hours loss:
workers in high-exit-cost places may remain attached but accept worse labor-market
outcomes.

Data requirement
----------------
Preferred: matched Basic Monthly CPS / IPUMS CPS using CPSIDP and the 4-8-4 rotation.

Input person file should contain, at minimum:
    person_id
    base_year
    age_base
    sex
    education
    state
    occ1990dd_base
    employed_base            {0,1}
    employed_followup        {0,1}
    nilf_followup            {0,1}, optional
    retired_followup         {0,1}, optional if source supports
    wage_base, wage_followup  optional
    hours_base, hours_followup optional
    weight

Input local-cost file:
    state
    base_year
    exit_cost

`exit_cost` should preferably be measured BEFORE the follow-up outcome:
examples:
    pre-period rent / housing-cost index
    HUD FMR relative to local wages
    shelter-price burden
    local essential-service price index

Do not use a contemporaneous post-exit housing outcome as the regressor.

Occupation exposure
-------------------
The shipped registry is derived from the existing companion `demolition_order.csv`.
Primary exposure candidates:
    human_rating_beta_z
    dv_rating_beta_z

Run all six alpha/beta/gamma exposure definitions as a robustness family rather
than treating them as independent replications.

Important: the documentation-density D variables are NOT the treatment in this test.

Estimation
----------
Default implementation below uses weighted linear probability models with
heteroskedastic-robust SEs. When state/year cells are numerous, add state and
base-year fixed effects.

For publication, cluster at the occupation level at minimum; two-way clustering by
occupation and state would be preferable if the estimator supports it.

This script is a scaffold: it will run once the person-level matched CPS/SIPP/HRS
file is staged.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf


EXPOSURE_COLS = [
    "dv_rating_alpha_z",
    "dv_rating_beta_z",
    "dv_rating_gamma_z",
    "human_rating_alpha_z",
    "human_rating_beta_z",
    "human_rating_gamma_z",
]


def validate_person_file(df: pd.DataFrame) -> None:
    required = {
        "person_id", "base_year", "age_base", "sex", "education", "state",
        "occ1990dd_base", "employed_base", "employed_followup", "weight"
    }
    missing = required - set(df.columns)
    if missing:
        raise KeyError(f"person file missing: {sorted(missing)}")


def build_analysis(
    person: pd.DataFrame,
    exposure: pd.DataFrame,
    local_cost: pd.DataFrame,
) -> pd.DataFrame:
    validate_person_file(person)

    d = person.copy()

    # Baseline sample: older workers who are actually employed before treatment/outcome.
    d = d[
        (d["age_base"].between(55, 69))
        & (d["employed_base"] == 1)
        & d["occ1990dd_base"].notna()
    ].copy()

    d["exit_employment"] = 1 - d["employed_followup"].astype(float)

    # Do not infer "retirement" from NILF unless the source explicitly identifies it.
    if "retired_followup" in d:
        d["retirement_exit"] = d["retired_followup"].astype(float)

    exposure = exposure.rename(columns={"occ1990dd": "occ1990dd_base"})
    d = d.merge(exposure, on="occ1990dd_base", how="left", validate="many_to_one")

    required_cost = {"state", "base_year", "exit_cost"}
    missing = required_cost - set(local_cost.columns)
    if missing:
        raise KeyError(f"local-cost file missing: {sorted(missing)}")
    d = d.merge(
        local_cost[["state", "base_year", "exit_cost"]],
        on=["state", "base_year"],
        how="left",
        validate="many_to_one",
    )

    # Standardize cost within the analysis sample.
    d["exit_cost_z"] = (
        d["exit_cost"] - d["exit_cost"].mean()
    ) / d["exit_cost"].std(ddof=0)

    # Optional secondary outcomes.
    if {"wage_base", "wage_followup"}.issubset(d.columns):
        ok = (d["wage_base"] > 0) & (d["wage_followup"] > 0)
        d["d_log_wage"] = np.nan
        d.loc[ok, "d_log_wage"] = (
            np.log(d.loc[ok, "wage_followup"])
            - np.log(d.loc[ok, "wage_base"])
        )

    if {"hours_base", "hours_followup"}.issubset(d.columns):
        d["d_hours"] = d["hours_followup"] - d["hours_base"]

    return d


def fit_one(d: pd.DataFrame, exposure: str, outcome: str = "exit_employment"):
    # Age is flexibly controlled; C() creates fixed effects for year/state/education.
    formula = (
        f"{outcome} ~ {exposure} * exit_cost_z"
        " + age_base + I(age_base**2)"
        " + C(sex) + C(education) + C(state) + C(base_year)"
        " + task_routine_z"
    )
    x = d.dropna(
        subset=[outcome, exposure, "exit_cost_z", "age_base",
                "sex", "education", "state", "base_year", "weight", "task_routine_z"]
    ).copy()

    model = smf.wls(formula, data=x, weights=x["weight"]).fit(cov_type="HC1")

    key = [
        exposure,
        "exit_cost_z",
        f"{exposure}:exit_cost_z",
    ]
    out = []
    for term in key:
        out.append({
            "exposure": exposure,
            "outcome": outcome,
            "term": term,
            "coef": model.params.get(term, np.nan),
            "se_hc1": model.bse.get(term, np.nan),
            "pvalue": model.pvalues.get(term, np.nan),
            "n": int(model.nobs),
        })
    return pd.DataFrame(out), model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--person", required=True)
    ap.add_argument("--exposure", required=True)
    ap.add_argument("--local-cost", required=True)
    ap.add_argument("--outdir", default="effort_data/retirement_exit")
    args = ap.parse_args()

    person = pd.read_csv(args.person, low_memory=False)
    exposure = pd.read_csv(args.exposure)
    local = pd.read_csv(args.local_cost)

    d = build_analysis(person, exposure, local)

    rows = []
    for e in EXPOSURE_COLS:
        if e not in d.columns:
            continue
        res, _ = fit_one(d, e, "exit_employment")
        rows.append(res)

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    results = pd.concat(rows, ignore_index=True)
    results.to_csv(outdir / "retirement_exit_exposure_results.csv", index=False)
    d.to_csv(outdir / "retirement_exit_analysis_sample.csv", index=False)

    print(results.to_string(index=False))
    print("\nPrimary outside-option sign test:")
    print("  exposure main effect beta > 0")
    print("  exposure × exit-cost interaction delta < 0")


if __name__ == "__main__":
    main()
