# Rebuild instructions
# Inputs:
#   Section2All_main.xlsx  - US-BEA GitHub Section2All snapshot
#   Section2All_xls.xlsx   - current BEA Underlying Section2All release
#
# The generated CSVs use Table 2.3.5:
# 1950-1958 from T20305-A in the snapshot;
# 1959-2025 from U20305-A in the current Underlying release.
#
# This bundle contains the outputs and source-join audit. The exact build logic is
# preserved in MAJOR_PRODUCT_DECOMPOSITION_MEMO.md and the project conversation.
