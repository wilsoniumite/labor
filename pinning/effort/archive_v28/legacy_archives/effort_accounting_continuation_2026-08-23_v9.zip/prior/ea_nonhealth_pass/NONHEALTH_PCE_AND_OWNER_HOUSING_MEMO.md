# Non-health PCE route pass: housing, implicit finance, and NPISH

Date: 2026-08-21

## Main result

The large non-health residual in Graph C contains several exact NIPA components that are **not ordinary household cash purchases** and can be carved out without behavioral assumptions.

Three long-run components are now explicit:

1. **Imputed rental of owner-occupied nonfarm housing** — the rental value of housing services homeowners provide to themselves.
2. **Financial services furnished without payment** — implicit financial-intermediation services recorded in PCE even though no explicit fee is paid.
3. **Final consumption expenditures of NPISHs** — nonprofit output supplied to households net of the nonprofits' sales to households.

Together these exact components are:
- 8.40% of PCE in 1950,
- 17.42% in 2023,
- 17.77% in 2025.

This is a product-side diagnostic. NPISH crosses functional categories, including health, so total NPISH cannot simply be added to a health payer decomposition.

## 2023 master-ledger integration

For the mutually exclusive 2023 Graph C route ledger:

- use the existing health payer decomposition;
- add owner-occupied nonfarm imputed rent;
- add financial services furnished without payment;
- add **non-health NPISH only**, defined as total NPISH final consumption less the exact health NPISH adjustment.

That raises the portion of PCE explicitly carved into named immediate-route/special-form cells to **37.25%**.
The remaining unresolved route/source residual falls to **62.75%**.

This does **not** mean the identified share has been traced to ultimate economic origin. It means we now know much more about how the consumption is recorded/delivered before the origin look-through.

## Owner-occupied housing: bridge toward Graph D

Owner housing is especially important because it is large and closely tied to the paper's scarcity story.

In 2022, gross imputed owner-occupied nonfarm housing services were $2028.7B.

The production-account bridge is approximately:
- intermediate inputs: $252.8B
- taxes on production/imports: $219.5B
- net interest: $304.3B
- consumption of fixed capital: $592.5B
- net rental income with capital consumption adjustment: $657.5B
- small remaining subsidies/transfers/rounding residual: $2.1B

Two cautions matter:

1. **Net rental income is not land rent.** It is the residual property income after the listed costs and still mixes the return to structures with the return to land/site scarcity.
2. **Intermediate inputs are not labor.** They include purchased maintenance, management and other goods/services. The RHFS/BLS rental modules are useful later for splitting the effort component.

So D0 is a bridge, not the final origin decomposition.

## Long-run result

The ratio of net owner-housing rental income to gross imputed housing services is very unstable historically and can go negative in high-interest periods. This confirms the earlier rental memo's warning: neither gross imputed rent nor rental income of persons should be treated as a direct land-rent series.

## Next target

The most valuable next decomposition is now the owner-housing residual itself:

`net rental income -> structure return + site/scarcity rent + unresolved`

with intermediate inputs separately split into purchased effort/management versus other inputs where data support it.
