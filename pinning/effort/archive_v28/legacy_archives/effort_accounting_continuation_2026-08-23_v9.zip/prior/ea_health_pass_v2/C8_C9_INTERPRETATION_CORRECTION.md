# C8/C9 interpretation correction

The earlier C8/C9 presentation treated the direct public-medical route and the same-decile PCE>DPI shortfall as additive pieces of one 100%-of-PCE partition.

That is too strong as a presentation rule.

The BEA/BLS harmonization is valuable because it prevents mismatched health allocations from *mechanically creating* the shortfall. But it does not turn a payer-route classification and a current-income-sufficiency classification into the same accounting dimension.

From this pass onward:

- **Graph C route ledger** is a mutually exclusive 100%-of-PCE partition by immediate delivery/financing route.
- **Graph C timing panel** is a separate 100%-of-PCE partition by current-DPI sufficiency.
- The 10.62% 2023 shortfall remains a valid hard lower bound in the timing panel.
- It should **not** be added to health payer shares to claim a larger route-identified fraction.

C8/C9 remain useful diagnostics, but their combined 20.72% should no longer be described as a mutually exclusive financing-route share.
