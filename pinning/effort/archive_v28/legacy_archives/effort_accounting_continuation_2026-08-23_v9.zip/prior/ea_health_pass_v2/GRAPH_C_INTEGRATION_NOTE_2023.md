# Graph C integration note — 2023 route ledger

The health module is now integrated into a mutually exclusive immediate-route view of 100% of 2023 PCE.

- Service-specific payer-attributed health PCE: 17.89% of total PCE.
- Health-related PCE still not assigned to a final payer bucket: 2.22%.
- Non-health PCE whose immediate route remains unresolved: 79.88%.
- Total: 100%.

Separately, the same-decile current-DPI insufficiency lower bound remains 10.62% of PCE.

The schema now records these as two dimensions rather than allowing them to be accidentally added together.
