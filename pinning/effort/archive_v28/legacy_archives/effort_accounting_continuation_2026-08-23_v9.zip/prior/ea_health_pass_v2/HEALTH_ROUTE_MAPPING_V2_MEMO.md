# Health route mapping v2: long-run NIPA scale + current-vintage payer detail

Date: 2026-08-21

## What changed

This pass moves the health branch from a scale diagnostic toward an actual Graph C subledger.

### 1. Exact NIPA health-consumption subledger, 1959–2023

The BEA workbook *BEA Data Applying NHEA Framework 1959–2023* gives an internally additive health-related PCE total.

For every year:

`health-related PCE = direct health-care services + (net health insurance + NPISH health adjustment) + health nondurable goods + therapeutic durables`

The extracted identity residual is numerical zero apart from floating-point noise.

Using total annual PCE as denominator:
- 1959: $20.312B = 6.40% of PCE.
- 2023: $3788.365B = 20.12% of PCE.

### 2. Current-vintage long-run payer shift

CMS Table 3 source-of-funds shares of health consumption expenditures:
- Out of pocket: 52.0% in 1960 -> 11.0% in 2024.
- Private health insurance: 22.8% -> 32.6%.
- Medicare + Medicaid: 0.0% -> 40.7%.

This is HCE, not PCE, so it is route evidence rather than an additive PCE cell.

### 3. Exact PHI medical-benefit / insurance-service split

CMS Table 20 supersedes our earlier approximate calculation.

2023:
- PHI total: $1511.2B
- medical benefits / personal health care: $1342.1B
- non-medical insurance expenditures: $169.1B

2024:
- PHI total: $1644.6B
- medical benefits / personal health care: $1468.1B
- non-medical insurance expenditures: $176.5B

The 2024 PHI split is 89.3% medical benefits and 10.7% non-medical insurance expenditure.

### 4. Exact modern service × payer matrix

CMS Table 4 gives source of funds by service for 2017–2024. It has been extracted to tidy form.

This lets Graph C use NIPA PCE dollars as the scale and NHEA payer shares to allocate those dollars by route, service by service.

### 5. First conservative NIPA-scaled payer prototype

For 2023, only close transparent service crosswalks are mapped:
- hospitals
- dental
- home health
- nursing homes
- prescription drugs
- therapeutic durables / DME
- physician + medical laboratories -> physician and clinical services
- other professional medical services -> other professional services

Those NIPA components total $3370.0B, or 89.0% of health-related PCE and 17.9% of all PCE.

Two pieces stay outside payer buckets:
- medical categories whose crosswalk is not yet tight enough;
- the exact NIPA net-insurance + NPISH service margin.

That is deliberate. The aim is a complete accounting only when the classifications are defensible.

## Long-axis implication

The detailed late-starting payer matrix improves modern resolution; it does not set the final graph's x-axis. The health dollar backbone itself is annual from 1959, and payer-route history reaches 1960.

