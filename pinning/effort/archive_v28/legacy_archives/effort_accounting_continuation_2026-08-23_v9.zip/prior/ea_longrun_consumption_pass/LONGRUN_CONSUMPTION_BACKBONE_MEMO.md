# Long-run consumption backbone pass

Date: 2026-08-21

## Main result

The consumption-side project now has a genuinely continuous **1950–2025** backbone using current-vintage NIPA functional data.

### C23 — exact product/function spine

Three mutually exclusive categories sum to 100% of PCE every year:

- housing & utilities;
- health;
- all other PCE.

The result is large:

- 1950: housing/utilities 13.06% + health 4.43% = **17.49% of PCE**.
- 1970: combined = **25.71%**.
- 1990: combined = **33.61%**.
- 2010: combined = **39.24%**.
- 2025: housing/utilities 18.14% + health 20.90% = **39.04% of PCE**.

This is not an origin decomposition. It is the exact consumption-product spine on which the route and ultimate-origin layers can sit.

### C24/C25 — hard immediate-form route backbone

A second annual ledger uses only routes/forms that are directly identified without deciding which income source financed ordinary fungible purchases:

- owner-occupied imputed housing;
- tenant nonfarm rent paid directly by households;
- household utilities paid directly by households;
- implicit financial services;
- NPISH final consumption;
- Medicare + Medicaid public-medical benefit flow;
- residual other PCE.

The **named immediate-form share** rises from **14.14% of PCE in 1950**
to **34.46% in 2025**.

The residual therefore falls from 85.86% to 65.54% even before the private-health, employer-insurance, and other direct-purchase branches are fully resolved.

The word *named* matters: this is not a claim that the residual has no known economic character. It means we have not yet separated it into the final mutually exclusive payer/delivery routes required for Graph C.

### Health-concept / vintage audit

The previous health pass used BEA's 2024-vintage workbook that **maps a broader set of health-related NIPA components into the NHEA framework** through 2023. C23 instead uses the current 2026-vintage Table 2.5.5 `Health` **function**, which extends from 1929 to 2025.

These are close but not identical concepts, so the comparison should not be described as a pure revision-vintage test.

Historically, the current functional series is typically below the broader mapped-health total by roughly 5–8%. The largest gap in the overlap is 8.51% in 2000. By 2023 the difference is only -0.080%.

Therefore:
- use current Table 2.5.5 `Health` for the **1950–2025 functional/product spine**;
- keep the NHEA-mapped health workbook for the **payer/service reconciliation work**;
- do not silently splice their dollar levels as though they were the same series.

The qualitative long-run result survives: health takes a much larger share of PCE. But the two health concepts remain explicitly labeled.

## Interpretation

This pass answers the x-axis concern directly.

The final consumption figure no longer needs to choose between:
- detailed recent measurement, or
- a 1950–2025 historical question.

It can use:
1. the exact long-run product spine as the full-width background;
2. hard route cells over the same 1950–2025 period;
3. finer payer/origin detail only where later data genuinely support it.

Resolution can improve over time without shrinking the axis.

## Sources

Current health function:
https://fred.stlouisfed.org/series/DHLTRC1A027NBEA

PCE, housing/utilities, owner-imputed housing, tenant rent, utilities, implicit financial services and NPISH:
current BEA/FRED NIPA series already carried in the project.

Public medical route:
project series `public_benefit_channels_share_of_pce_1960_2025.csv`, built from NIPA Medicare and Medicaid benefit flows.
