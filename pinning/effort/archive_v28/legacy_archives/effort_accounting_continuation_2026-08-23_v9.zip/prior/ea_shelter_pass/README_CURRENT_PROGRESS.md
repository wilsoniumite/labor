# Effort accounting — current progress

## Built and audited

### A. Legal-form household resource audit
1960–2025:
- employee compensation
- proprietors' income
- rental income
- interest
- dividends
- government social benefits

### A1. Conservative economic-origin graph
Measured anchor years 2005/2010/2015/2020/2025:
- employee compensation -> effort
- imputed proprietor labor -> effort
- all other primary claims -> unresolved
- transfers remain separate

Central classified/imputed effort share:
- 2005: 66.2%
- 2010: 62.3%
- 2015: 61.6%
- 2020: 58.0%
- 2025: 59.0%

This is deliberately a lower-layer estimate, not the final origin decomposition.

### Proprietors
BEA proprietors' income is mixed income.
First aggregate labor-value proxy:

| year | wage-only effort | total-comp effort |
|---|---:|---:|
| 2005 | 43.9% | 54.5% |
| 2010 | 38.4% | 47.7% |
| 2015 | 35.7% | 44.1% |
| 2020 | 33.9% | 41.6% |
| 2025 | 34.6% | 42.0% |

Residual remains unresolved, not automatically capital.

### B0. Disposable-income disposition identity
DPI = PCE + personal saving + personal interest payments + personal transfers.

### B1/B2. Saving and financial bridge
- personal saving
- household loan incurrence
- household net lending
- corporate retained earnings

### B3. Corporate payout / retention
Exact identity:
profits after tax = net dividends + undistributed profits.

This prevents corporate earnings generated today from being confused with household
income distributed today.

### Equity claim-management effort
- index/passive share rises sharply
- asset-management hours per ICI long-term-fund dollar proxy falls strongly

Important:
this measures claim-selection/intermediation effort, NOT the production effort inside
the corporations generating dividends.

### Credit
Commercial-banking inverse labor productivity provides a system-effort proxy.

### Rental system effort
Two aggregate diagnostics:
- NAICS 5311 lessor hours per renter household falls
- NAICS 5313 related-real-estate-service hours per renter household rises

Interpretation: substantial delegation/outsourcing; lessor-side labor decline alone
cannot be called automation.

### Rental-income composition
BEA rental income of persons is not synonymous with cash landlord rent.

By 2024 approximately:
- 78% owner-occupied nonfarm housing imputation
- 15% tenant-occupied housing
- 7% other/residual

Thus RHFS landlord-management effort cannot be applied to the entire rental-income
series.

## Still open

1. Stage and run RHFS public-use microdata.
2. Industry/occupation-matched proprietor labor imputation.
3. Housing production-account split:
   management/intermediate labor vs structure return vs site rent.
4. Corporate production look-through:
   labor / produced-capital / scarcity content of profits.
5. Interest look-through by borrower / intermediary.
6. After-tax origin decomposition.
7. Sharp accounting bounds for which income sources finance PCE versus saving/outlays.
8. Final 100%-of-PCE immediate-financing graph.
9. Recursive ultimate-origin graph.


---

## New pass: corporate production look-through

Added `corporate_production_lookthrough_1960_2025.csv`.

Exact BEA identities:

    gross corporate value added
      = employee compensation
      + consumption of fixed capital
      + production taxes less subsidies
      + net operating surplus

and:

    net operating surplus
      = corporate profits with IVA + CCAdj
      + net interest & miscellaneous payments
      + business current transfers.

2025 gross corporate value-added shares:
- employee compensation: 55.3%
- consumption of fixed capital: 15.3%
- production taxes less subsidies: 7.9%
- net operating surplus: 21.5%

This is the correct first look-through for dividends:
passive ownership says little about the human labor involved in producing the
corporate cash flow.

---

## New pass: transfer composition

Added `transfer_composition_1960_2025.csv`.

The aggregate social-benefit line is now split into:
- Social Security
- Medicare
- Medicaid
- unemployment insurance
- other

2025:
- Social Security: 32.5%
- Medicare: 25.2%
- Medicaid: 20.9%
- unemployment insurance: 0.8%
- other: 20.7%

Social Security + Medicare + Medicaid = 78.5% of benefits in 2025.

Of the nominal increase in total social benefits from 1965 to 2025:
- Social Security accounts for ~32.3%
- Medicare ~25.4%
- Medicaid ~21.0%
- UI only ~0.7%
- other ~20.6%

Thus ~78.7% of the long-run nominal transfer increase is accounted for by
Social Security + Medicare + Medicaid.

Interpretation:
the smooth secular transfer expansion in the old fiscal graph has a powerful
aging/health-program explanation; unemployment insurance mainly generates crisis
excursions.

Next sharp test:
construct a working-age/non-health financing view rather than reading the aggregate
transfer trend as a technology proxy.


---

## New pass: health-transfer and retirement drivers

See `TRANSFER_RETIREMENT_DRIVER_SUMMARY.md`.

Main update: health-transfer growth has material relative-price and real-intensity components; recent aggregate retirement data show later rather than earlier claiming; and mechanically excluding SS+Medicare+Medicaid reduces the old 1960–2025 direct-wage share decline from about 19.4pp to about 3.0pp. These programs therefore carry the accounting trend, but their own causal drivers remain the object to explain.


---

## Latest pass: health financing socialization and conditional retirement test

See `LATEST_PASS_SUMMARY.md`, `HEALTH_SOCIALIZATION_PRICE_VOLUME_MEMO.md`, `MEDICARE_HOSPITAL_DECOMPOSITION_MEMO.md`, and `RETIREMENT_EXIT_TEST_DESIGN.md`.


---

## New pass: sharp PCE financing bound and dividend-weighted industry look-through

Graph C now has a 2017 assumption-free hard lower bound: at least 8.08% of total PCE exceeds the current DPI of the income decile doing the consuming. The first dividend-weighted production look-through covers 58.8% of 2024 domestic net corporate dividends across six sectors and keeps the remainder explicitly unresolved.


---

## New pass: property-income timing correction

BEA personal property income is an accrual concept: in 2024 about 53% of personal interest income and about 80% of rental income are imputed rather than monetary, while personal dividends include pension-plan dividends and mutual-fund pass-throughs. Graph A therefore needs separate accrual-income and cash/current-resource versions before it can feed Graph C.


---

## New pass: employee-compensation timing split

2024 employee compensation is about 82% wage/salary disbursements, 11.8% employer pension/insurance contributions, and 5.8% employer government-social-insurance contributions. Labor origin and current-cash availability must therefore be separate dimensions in Graphs A–C.


---

## New pass: measured pension floor inside personal dividends

2024 IMA pension funds receive about $204B of dividends, roughly 9.2% of the scale of NIPA personal dividend income. This is a measured lower bound on the importance of pension intermediation; the remainder is not assumed to be current cash because mutual-fund and other pass-through routes remain.


---

## New pass: exact 2024 accrual-to-route bridge

A 2024 route ledger now separates current disbursements, insurance/in-kind claims, deferred/imputed accruals, and timing-unresolved claims before walking exactly through social contributions, personal taxes, DPI, PCE, other outlays, and personal saving. Economic origin and cash timing are now formally separate dimensions.


---

## New pass: public medical benefits directly on the PCE denominator

Medicare+Medicaid benefit flows now have a direct PCE-normalized series: 2.0% of PCE in 1970 versus 10.3% in 2024. This is a directly identified non-wage/in-kind consumption route, not a causal origin estimate.


---

## New pass: program-specific Medicare/Social Security funding look-through

2025 Social Security non-interest income is overwhelmingly payroll-tax financed, while combined Medicare is only about one-third dedicated payroll tax and nearly one-half federal/state general revenue, with beneficiary premiums also material. A single transfer-linkage coefficient is inappropriate.

---

## New pass: master PCE ledger v0 (Graph C8/C9)

Using the latest BEA/BLS joint DPI-PCE year (2023), the 100%-of-PCE canvas now has a
strictly conservative partition before any wages-first/capital-first allocation:

- direct public medical route (Medicare + Medicaid): **10.10% of PCE**;
- additional hard same-decile current-DPI shortfall: **10.62%**;
- residual that *could* be current-DPI financed: **79.28%**.

The first two sum to a **20.72% hard-identified floor** outside the unresolved
current-DPI-capable residual.  This additivity is supported by the BEA/BLS joint
saving methodology, which harmonizes overlapping health (and owner-occupied housing)
items before computing saving, so the PCE>DPI shortfall is not mechanically created
by different allocations of the same health item.

Added:
- `graph_C8_master_pce_ledger_2023.csv`
- `graph_C8_hard_identified_pce_routes_2023.png`
- `graph_C9_identified_pce_routes_2000_2023.csv`
- `graph_C9_hard_identified_pce_routes_timeseries.png`
- `GRAPH_C8_MASTER_LEDGER_MEMO.md`
- `build_graph_C_master_ledger_v0.py`

Next target: carve the 79.28% residual using current private health-insurance payer
flows and other directly identified in-kind routes before attempting any behavioral
allocation of cash income.

---

## New pass: private health route and two-dimensional Graph C schema (C10–C12)

The next C8 residual carve-out exposed an important accounting distinction rather than
an immediately additive slice.

Using the current CMS NHEA 2024 vintage:

- 2023 private health insurance expenditures are **$1,511.2B = 8.02% of PCE**;
- 2023 out-of-pocket health spending is **$525.4B = 2.79% of PCE**;
- the direct NIPA Medicare+Medicaid route remains **$1,903.006B = 10.10% of PCE**.

CMS Medicare+Medicaid in 2023 is $1,911.0B, only $7.994B (0.42%) above the direct
NIPA public-medical route, which is a strong cross-account scale check.

Crucially, PHI/OOP **cannot simply be added** to C8's 20.72% hard-identified floor.
They identify payer/intermediation route, while C8's 10.62% PCE>DPI term identifies
current-income insufficiency. Their overlap is not observed. Graph C therefore needs
two orthogonal layers/panels: immediate payer/delivery route and timing/current-DPI
sufficiency.

The 2024 CMS sponsor facts also pin down a large PHI branch. A literal conservative
reading of “more than three-quarters” of $967.4B private-business health spending,
combined with the reported 72/28 employer/household ESI sponsor split, implies:

- **>$1,007.7B** private-sector ESI premium spending (>61.3% of all PHI);
- **>$725.6B** private-employer contribution;
- **>$282.2B** household contribution inside that private-sector ESI branch.

These are nested bounds, not additive categories. The federal-sponsored share of all
PHI is 10.7% ($176.0B); Marketplace spending is $149.5B, with $116.6B federally
financed.

Added:
- `GRAPH_C10_PRIVATE_HEALTH_ROUTE_MEMO.md`
- `cms_nhe_current_vintage_2018_2024.csv`
- `graph_C10_health_payment_routes_scale_2018_2024.csv`
- `graph_C10_health_payment_routes_scale_2018_2024.png`
- `graph_C11_public_medical_cross_account_2018_2024.csv`
- `graph_C11_public_medical_cross_account_2018_2024.png`
- `private_health_sponsor_known_bounds_2024.csv`
- `graph_C12_private_health_sponsor_bounds_2024.png`
- `graph_C_master_ledger_schema_v1.csv`
- `build_graph_C_private_health_v1.py`

Next target: reconcile CMS PHI benefits and insurer non-medical expenditures to the
NIPA PCE health concepts, so private insurance can become an exact additive Graph-C
cell; then repeat for remaining public in-kind consumption.

---

## 2026-08-21 — health route mapping v2

- Exact additive BEA health-related PCE subledger extracted for 1959–2023.
- Health-related PCE rises from 6.40% of PCE in 1959 to 20.12% in 2023.
- Current-vintage CMS payer anchors show out-of-pocket HCE falling from 52.0% in 1960 to 11.0% in 2024, while Medicare+Medicaid rise from zero to 40.7%.
- CMS Table 20 gives the exact PHI split. Earlier approximate values are superseded: 2024 = $1,468.1B medical benefits + $176.5B non-medical insurance expenditures.
- CMS Table 4 source-of-funds × service matrix for 2017–2024 is now tidy and usable.
- Conservative 2023 NIPA-scaled payer prototype maps 89.0% of health-related PCE by service-specific payer shares while leaving weak crosswalks and the insurance/NPISH service margin unresolved.
- Design rule reaffirmed: late detailed data improve resolution; they do not set the final x-axis.


### Important correction to C8/C9

The project now treats the PCE route ledger and the current-DPI sufficiency bound as **orthogonal dimensions**. The prior C8/C9 combined 20.72% is retained only as a diagnostic juxtaposition, not as a mutually exclusive financing-route partition. The 10.62% shortfall itself remains valid; what changes is the way it is presented and added.


---

## 2026-08-21 — non-health route carve-out + owner-housing bridge

- Added exact 1950–2025 NIPA series for owner-occupied nonfarm imputed rent, implicit financial services, and NPISH final consumption.
- Those three special PCE components together rise from 8.40% of PCE in 1950 to 17.77% in 2025.
- Integrated them into the 2023 Graph C ledger without double counting health: non-health NPISH is total NPISH less the health NPISH adjustment.
- Named/special-route cells now cover 37.25% of 2023 PCE; the residual falls to 62.75%.
- Built a 2022 owner-occupied-housing production-account bridge from gross imputed services through intermediate inputs, taxes, interest, depreciation and net rental income.
- Reaffirmed: net rental income is not site rent; the next Graph D task is separating structure return from site/scarcity rent.


---

## 2026-08-21 — matched owner-housing site-value residual

The owner-housing branch now has a matched stock decomposition from Federal Reserve series:
owner-occupied real estate at market value minus household owner-occupied residential structures at current cost.

2025:
- real estate market value: $45.993T
- matched structures: $28.952T
- site/land residual: $17.041T
- residual share of property value: about 37.1%

This materially strengthens the scarcity side of Graph D while preserving a key distinction: the land residual is a stock, not a rent flow. No capitalization rate has been imposed in the main ledger yet.


---

## 2026-08-21 — shelter and utilities long-run pass

- Added exact annual 1950–2025 housing/utilities anatomy.
- Housing & utilities rises from 13.06% of PCE in 1950 to 18.14% in 2025.
- Owner + tenant shelter rises from 10.13% to 15.64%.
- Graph C v4 now identifies tenant rent and household utilities as direct household market-purchase routes.
- 2023 fully route-classified PCE = 40.99%; named/product-identified but route unresolved = 2.38%; fully unresolved = 56.63%.
- Added D5 cross-account diagnostic linking the long-run PCE weight of housing/utilities to the matched owner-housing site-value residual share. It is diagnostic only, not a rent-flow identity.
