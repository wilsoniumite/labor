# Shelter and utilities pass

Date: 2026-08-21

## Why this pass matters

The project needs a 1950–2025 consumption-side backbone. Housing and utilities are unusually useful because the national accounts provide annual current-dollar series across the full target window, while the branch is also central to the paper's scarcity mechanism.

The exact NIPA branch is decomposed as:

`housing & utilities = owner-occupied imputed housing + tenant-occupied nonfarm rent + other housing services + household utilities`

where `other housing services` is the exact residual inside the published housing total.

The identities close to floating-point zero.

## Long-run result

Housing and utilities rise from **13.06% of PCE in 1950**
to **17.92% in 2023**
and **18.14% in 2025**.

Owner + tenant shelter alone rises from **10.13%**
to **15.64%** of PCE.

The 2025 branch is:
- owner-occupied imputed housing: 11.93% of PCE
- tenant-occupied nonfarm rent: 3.71%
- other housing services: 0.16%
- household utilities: 2.34%

## Graph C integration

Tenant nonfarm rent and household utilities are household consumption expenditures, so their immediate route is directly purchased market consumption even though their **ultimate financing origin** remains open.

Adding those two exact direct-payment cells to the 2023 master ledger:
- fully route-classified share of PCE: **40.99%**
- named/product-identified but route unresolved: **2.38%**
- fully unresolved residual: **56.63%**

This is an improvement over v3 without pretending that a cash-market purchase tells us whether the underlying resource originated in wages, capital income, transfers, borrowing, or asset drawdown.

## Graph D diagnostic

D5 places two long-run percentages on the same axis:
- housing & utilities as a share of PCE;
- the owner-occupied site-value residual as a share of owner-occupied property value.

They are not the same accounting object, and no causal identity is claimed. The point is diagnostic: both the consumption weight of shelter/utility services and the balance-sheet value that cannot be explained by replacement-cost structures rise strongly over the long run.

This is useful supporting evidence for the paper, but the site-value stock must still be converted to a rent flow with a sensitivity band before it can enter the ultimate-origin accounting.

## Sources

- Tenant-occupied nonfarm housing: https://fred.stlouisfed.org/series/DTENRC1A027NBEA
- Housing: https://fred.stlouisfed.org/series/DHSGRC1A027NBEA
- Household utilities: https://fred.stlouisfed.org/series/DUTLRC1A027NBEA
- Housing and utilities: https://fred.stlouisfed.org/series/DHUTRC1A027NBEA
